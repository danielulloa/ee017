%	ELIABAN  Es un programa para el proyecto de
%                FILTROS EL�PTICOS PASABANDA ACTIVOS
% 	ingresando: 
%       1) La frecuencia central fo de la banda de paso
%       2) El ancho de banda de 3 dB relativo (f2-f1)/fo
%       3) La frecuencia de la banda de atenuacion fa
% 	4) La atenuaci�n m�xima en la  banda de paso
% 	5) La atenuaci�n m�nima en la banda de atenuaci�n 

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

% 1.- Introduccion de los datos y conversi�n de los mismos a datos para el pasabajos equivalente


fprintf('--------    PROYECTO DE FILTROS EL�PTICOS PASABANDA    --------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')



% Puesta a cero de los vectores

A3=[];
N=[];
D=[];
Qpolo=[];
Wpolo=[];
Wcero=[];
Wpolo3dB=[];
Wcero3dB=[];
A1=[];
A0=[];
A03dB=[];
A13dB=[];
Qpolo1=[];
Wpolo1=[];
Wcero1=[];
Qpolo2=[];
Wpolo2=[];
Wcero2=[];
fpreal=[];
Qpreal=[];

% Ingreso de los valores de frecuencia y de atenuaci�n

f0=input('Ingresar la frecuencia central de la banda de paso fo en kHz: ');
B=input('Ingresar el ancho de banda de 3 dB relativo (f2-f1)/fo en % : ');
fa=input('Ingresar la frecuencia de la banda de atenuacion fa en kHz: ');
Amax=input('Ingresar la Atenuaci�n m�xima en la banda de paso Am�x en dB : ');
Amin=input('Ingresar la Atenuaci�n m�nima en la banda de atenuacion Am�n en dB: ');
fprintf(' \n\n')
f3dB=1;
% Adecuaci�n de los datos ingresados

f0=f0*1000;
w0=1;
fa=fa*1000;
B=B/100;
Ba=B*f0;
fabaj=abs((fa^2-f0^2)/Ba/fa); % Frecuencia de atenuaci�n del pasabajos equivalente

% Determinaci�n del orden del filtro el�ptico

epsilon = sqrt(10 .^ (0.1*Amax)-1);
k1 = epsilon./sqrt(10 .^ (0.1*Amin)-1);
k = 1/fabaj;
capk = ellipke([k.^2 1-k.^2]);
capk1 = ellipke([(k1 .^2) 1-(k1 .^2)]);
orden = ceil(capk(1)*capk1(2)/(capk(2)*capk1(1)));
n=orden;

fprintf('          * 2) Orden del filtro el�ptico pasabanda:'),exi(2*n),fprintf(' \n\n')

% C�lculo de los polos del filtro el�ptico pasabajos equivalente
fprintf('                             Calculando fp,fz y Q. Tarda un poco .... '),fprintf(' \n')
fprintf(' \n')

[z,p,k]=ellipap(n,Amax,Amin);

% Ac� se normalizan los polinomios del filtro eliptico 
% Las variables se hacen globales para que puedan ser accedidas 
% por la funcion elicomp
global KNUME PNUME PDENE

KNUME=k;
PNUME=poly(z);
PDENE=poly(p);


W3dB=fzero('elicomp',1); % Encuentra la frecuencia a la cual el modulo es igual a 1/raiz de 2


% Ac� se calculan los ceros
z;
z=cplxpair(z);
nz=length(z);

for i=1:2:nz

   acero(i)=1/(abs(z(i)))^2;
   Wcero(i)=abs(z(i));
   Wcero3dB(i)=Wcero(i)/W3dB;

end

Wcero=elicero(Wcero);

% De los polos agrupados en funciones de 2 orden,
% se obtiene el Qp y las fp y con ellos se calculan los
% coeficientes del los factores bicuadraticos

if rem(n,2)~=0   % Si el orden es impar
np=length(p)-1;

  for i=1:2:np
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    %Wpolo3dB(i)=Wpolo(i)/W3dB*f3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));

% Coeficientes de los factores bicuadraticos  
    A0(i)=Wpolo(i)^2;
    A1(i)=sqrt(A0(i))/Qpolo(i);
    A03dB(i)=A0(i)/W3dB^2;
    A13dB(i)=A1(i)/W3dB;    


   end
% C�lculo del polo real. Se lo extrae como �ltimo polo del vector de polos

poloreal=p(length(p));

else

np=length(p);     % Si el orden es par
  for i=1:2:np
    
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    %Wpolo3dB(i)=Wpolo(i)/W3dB*f3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
  
    
    A0(i)=Wpolo(i)^2;
    A1(i)=sqrt(A0(i))/Qpolo(i);
    A03dB(i)=A0(i)/W3dB^2;
    A13dB(i)=A1(i)/W3dB;


end

poloreal=[];

end

% Se eliminan los ceros de los vectores anteriormente generados

A1=elicn(A1);   
A0=elicn(A0);
A13dB=elicn(A13dB);
A03dB=elicn(A03dB);

%fpreal=abs(poloreal)/W3dB*f3dB; 


% Fin del Equivalente de Filtros Elipticos Pasabajos    ----------

% Coeficientes del numerador de la Transf. Pasabanda

if rem(n,2)~=0   % Si el orden del pasabajos equivalente es impar
                 % Calcula los valores de f y Q del polo real 
  ao=abs(poloreal);
  pol=[1 ao*B w0^2];
  pe=roots(pol);
  fpreal=sqrt(real(pe(1))^2+imag(pe(1))^2);
  Qpreal=fpreal/2/abs(real(pe(1)));
  fpreal=fpreal*f0;
else
 
end

% Numero de factores bicuadr�ticos  

for j=1:length(A0)

% Coeficientes del numerador del pasabanda

Bb2=Wcero(j)^2*B^2+2*w0^2;
Bb0=w0^2*w0^2;
N=[1 0 Bb2 0 Bb0];

% Coeficientes del denominador de la Transf. Pasabanda

Ab3=A1(j)*B;
Ab2=2*w0^2+A0(j)*B^2;
Ab1=A1(j)*w0^2*B;
Ab0=w0^2*w0^2;
D=[1 Ab3 Ab2 Ab1 Ab0];

pd=roots(D);
pd=cplxpair(pd);
zn=roots(N);
zn=cplxpair(zn);

Wpolo1(j)=abs(pd(1));
Wpolo2(j)=abs(pd(3));
Qpolo1(j)=Wpolo1(1)/2/abs(real(pd(1)));
Qpolo2(j)=Wpolo2(1)/2/abs(real(pd(3)));
Wcero1(j)=abs(zn(1));
Wcero2(j)=abs(zn(3));

end

Wpolo1=elicero(Wpolo1)*f0;
Qpolo1=elicero(Qpolo1);
Wpolo2=elicero(Wpolo2)*f0;
Qpolo2=elicero(Qpolo2);
Wcero1=elicero(Wcero1)*f0;
Wcero2=elicero(Wcero2)*f0;

% Presentaci�n de los resultados
fprintf('          * 3) fp, fz y Q de cada etapa:'),fprintf(' \n')
fprintf(' \n\n')

fprintf('Cantidad de etapas: '),exi(n),fprintf(''),fprintf(' \n\n')

for i=1:length(Wpolo1)
fprintf('Etapa Pasabajo con ranura n�mero '),exi(i),fprintf(''),fprintf(' \n\n')
fprintf('fp'),exi(Wpolo1(i)),fprintf('Hz'),fprintf('    fz'),exi(Wcero1(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo1(i))
fprintf(' \n\n')
fprintf('Etapa Pasaalto con ranura n�mero '),exi(i),fprintf(''),fprintf(' \n\n')
fprintf('fp'),exi(Wpolo2(i)),fprintf('Hz'),fprintf('    fz'),exi(Wcero2(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo2(i))
fprintf(' \n\n')

end

if rem(n,2)~=0
fprintf('Etapa Pasabanda : '),fprintf(' \n\n')
 fprintf('fp '),exi(fpreal),fprintf('Hz'),fprintf('    Qp '),exi(Qpreal),fprintf(''),fprintf(' \n\n')
 %fprintf(' \n\n')
else
end

% C�lculo de la ganancia a la frecuencia central f0

for i=1:length(Wpolo1)
N1(i)=1-(f0/Wcero1(i))^2;
D1(i)=sqrt(   (1-(f0/Wpolo1(i))^2)^2 + (f0/Wpolo1(i))^2/Qpolo1(i)^2  );

N2(i)=1-(f0/Wcero2(i))^2;
D2(i)=sqrt((1-(f0/Wpolo2(i))^2)^2 + (f0/Wpolo2(i))^2/Qpolo2(i)^2  );

H(i)=N1(i)*N2(i)/D1(i)/D2(i);

end

H=prod(H);
HdBenf0=20*log10(abs(H));
fprintf('Ganancia resonante del filtro: H(fo) '),exi(HdBenf0),fprintf('dB'),fprintf(' \n\n')
fprintf('-------    Fin del c�lculo de fp, fz y Q del Filtro El�ptico Pasabanda    -------------------------------------------------------'),fprintf('\n')
