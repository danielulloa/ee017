% KRCK2 es una funcion que proporciona los valores de:
%          Las Resistencias R2 y R1 de una etapa activa
%          KRC de 2 orden CON CAPACITORES IGUALES Y RA=RB (K=2)
% cuando se le ingresa:                         (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa y 
%                      3) El valor del capacitor en nF
%                  
%                                  | | C     
%                    +-------- ----| |---------------+
%                    |             | |               |   
%                    |                               |   
%             R1     |     R2               |`.      |   
%    V1 o---/\/\/\---*---/\/\/\---*---------|+ `.    |       
%                                 |         |    >---*---o V2
%                               __|__   +---|- ,'    |       
%                            C  _____   |   |,'      |       
%                                 |     |            |       
%                                _|_    *---/\/\/\---+       
%                                 -     |     RB     
%                                       /        
%                                       \ RA       
%                                       /          
%                                      _|_        
%  Ejemplo:                             -
%
%  1) Datos:  Si fp= 1000 Hz, Q= 2 y el valor del capacitor C= 1.2 nF
%
%  2) Se ingresa:  krck2(1,2,1.2) 
%
%  3) Se obtiene:   R1 = 267 kohm  R2 = 66.5 kohm 
%
%  Ver tambien BICUA, KRCI, PBDA, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     krck2(fp,Q,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   8 de Octubre de 2002. Version 1.2

function y=krck2(fp,Q,C)

fp=fp*1000;
C=C*1e-9;

% Calculo R2
R2=1/(2*pi*fp*Q*C);
R2=rnor(R2,1);
% Calculo R1
R1=Q^2*R2;
R1=rnor(R1,1);

% Presentaci�n de los resultados
fprintf('  * Filtro KRC con ganancia 2 * \n\n')
fprintf('  Datos: \n')
fprintf('  fp'),exi(fp),fprintf('Hz'),fprintf('  Q'),exi(Q),fprintf(''),...
fprintf('  C'),exi(C),fprintf('F'),fprintf('\n')
fprintf('  Resultados del proyecto: \n')
fprintf('  R1'),exi(R1),fprintf('ohm'),fprintf('\n')
fprintf('  R2'),exi(R2),fprintf('ohm'),fprintf('\n')
fprintf('  El valor de RA=RB se elige \n')
fprintf('\r')                      


