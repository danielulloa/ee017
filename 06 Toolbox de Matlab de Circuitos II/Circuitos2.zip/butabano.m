%	BUTABANO  Es un programa para el proyecto de: 
%                   FILTROS BUTTERWORH ACTIVOS PASABANDA 
% 	ingresando: 
%       1) La frecuencia central fo de la banda de paso
%       2) El Orden del filtro
%       3) La Ganancia del filtro a la frecuencia central


% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


% 1.- Introduccion de los datos y conversion de los mismos a datos para el pasabajos equivalente


fprintf('--------    PROYECTO DE FILTROS BUTTERWORTH ACTIVOS PASABANDA    --------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')

% Puesta a cero de los vectores
Qpolo1=[];
Wpolo1=[];
Qpolo2=[];
Wpolo2=[];
pb1=[];
pb2=[];
A1=[];
A2=[];

% Ingreso de los valores de frecuencia y de atenuacion

f0=input('Ingresar la frecuencia central de la banda de paso fo en KHz:   ');
dosn=input('Ingresar el orden del filtro pasabanda :   ');
AgdB=input('Ingresar la ganancia del filtro a la frecuencia central H(fo) en dB:   ');
fprintf(' \n\n')

% Adecuacion de los datos ingresados

f0=f0*1000;
w0=1;
if rem(dosn,2) ==1
dosn=dosn+1;
else
end

% Determinacion del orden del filtro Butterworth Pasabajos equivalente

n=dosn/2;


% Calculo de los polos del filtro de Butterworth pasabajos

z = [];
p = exp(sqrt(-1)*(pi*(1:2:2*n-1)/(2*n) + pi/2));
p=cplxpair(p);
k = real(prod(-p));

% Transformaci�n de los polos del filtro pasabajos a pasabanda

for h=1:length(p)
pb1(h)=(p(h)*B+sqrt((p(h)*B)^2-4*w0^2))/2;
pb2(h)=(p(h)*B-sqrt((p(h)*B)^2-4*w0^2))/2;
end

% De los polos agrupados en funciones de 2 orden,
% se obtiene el Qp y las fp y con ellos se calculan los
% coeficientes del los factores bicuadraticos

  for i=1:2:length(p)
    Wpolo1(i)=abs(pb1(i));
    Qpolo1(i)=Wpolo1(i)/2/abs(real(pb1(i)));
  end
  for i=1:2:length(p)
    Wpolo2(i)=abs(pb2(i));
    Qpolo2(i)=Wpolo2(i)/2/abs(real(pb2(i)));

 end

 
Wpolo1=elicero(Wpolo1)*f0;
Qpolo1=elicero(Qpolo1);
Wpolo2=elicero(Wpolo2)*f0;
Qpolo2=elicero(Qpolo2);

fprintf('          * 2) fp, Qp y Hp de cada etapa:'),fprintf(' \n')
fprintf(' \n\n')
fprintf('Cantidad de etapas pasabanda: '),exi(n),fprintf(''),fprintf(' \n\n')

AcedB=AgdB/n;         % La ganancia global en dB se reparte igualmente en cada etapa
Ace=10^(AcedB/20);    % Ganancia de cada etapa en la frecuencia central del filtro

% Calculo de la Ganancia en la frecuencia de resonancia de cada etapa, es decir
% en su polo correspondiente, para poder proyectar la misma

if rem(n,2)==0

for i=1:length(Wpolo1)
 A1(i)=Ace*sqrt( 1 + Qpolo1(i)^2*( f0/Wpolo1(i) - Wpolo1(i)/f0 )^2  );
end

for i=1:length(Wpolo2)
 A2(i)=Ace*sqrt( 1 + Qpolo2(i)^2*( f0/Wpolo2(i) - Wpolo2(i)/f0 )^2  );
end

else

for i=1:length(Wpolo1)
 A1(i)=Ace*sqrt( 1 + Qpolo1(i)^2*( f0/Wpolo1(i) - Wpolo1(i)/f0 )^2  );
end

for i=1:length(Wpolo2)-1
 A2(i)=Ace*sqrt( 1 + Qpolo2(i)^2*( f0/Wpolo2(i) - Wpolo2(i)/f0 )^2  );
end

end

if rem(n,2)==0

fprintf('\n')
fprintf('----------  Frecuencia, Q y Ganancia de cada etapa ---------------------------------------'),fprintf('\n')
fprintf('\n')

for i=1:length(Wpolo1)

fprintf('fp'),exi(Wpolo1(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo1(i)),fprintf('    Hp'),exi(A1(i))
fprintf(' \n\n')

end

for i=1:length(Wpolo2)

fprintf('fp'),exi(Wpolo2(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo2(i)),fprintf('    Hp'),exi(A2(i))
fprintf(' \n\n')

end



else
fprintf('\n')
fprintf('----------  Frecuencia, Q y Ganancia de cada etapa ---------------------------------------'),fprintf('\n')
fprintf('\n')

for i=1:length(Wpolo1)

fprintf('fp'),exi(Wpolo1(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo1(i)),fprintf('    Hp'),exi(A1(i))
fprintf(' \n\n')

end

for i=1:length(Wpolo2)-1

fprintf('fp'),exi(Wpolo2(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo2(i)),fprintf('    Hp'),exi(A2(i))
fprintf(' \n\n')

end



end
% Calculo de la ganancia a la frecuencia central fo del 
% filtro pasabandas Normalizado. Sacar el signo de porcentaje
% si interesa la ganancia del filtro normalizado 

%for i=1:length(Wpolo1)

%N1(i)=f0/Wpolo1(i)/Qpolo1(i);
%D1(i)=sqrt(   (1-(f0/Wpolo1(i))^2)^2 + (f0/Wpolo1(i))^2/Qpolo1(i)^2  );

%N2(i)=f0/Wpolo2(i)/Qpolo2(i);
%D2(i)=sqrt((1-(f0/Wpolo2(i))^2)^2 + (f0/Wpolo2(i))^2/Qpolo2(i)^2  );

%H(i)=N1(i)*N2(i)/D1(i)/D2(i);


%end

%H=prod(H);
%HdBenf0=20*log10(abs(H))


fprintf('-------    Fin del c�lculo de fp, Qp y Hp del Filtro Butterworth Pasabanda    -------------------------------------------------------'),fprintf('\n')
