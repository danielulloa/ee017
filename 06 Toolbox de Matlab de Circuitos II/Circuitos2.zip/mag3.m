% MAG3 es una funci�n que proporciona los valores de:
% los flujos en cada rama de un circuito magn�tico de tres ramas |1| |2| |3|
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La Fmm F=N*I de la rama en A*vueltas con el sentido 
%                         positivo en el terminal superior del arrollamiento.
%                      2) La reluctancia R en el hierro de la rama en kH^-1
%                      3) La reluctancia Re del entrehierro de la rama en kH^-1
%
% en el siguiente orden: primero estas tres magnitudes para la primera rama,
% a continuaci�n las de la segunda rama y en tercer lugar las de la tercera rama.
%
% Como se trata de un circuito de 3 ramas nunca pueden ser nulas las reluctancias
% en el hierro de las ramas, pero si las del entrehierro. Asimismo como m�ximo
% pueder ser nulas dos de las Fmm de las ramas.
%
% Los sentidos positivos de los flujos en las ramas son considerados hacia 
% arriba en cada columna de la rama e indicados con ^ en el resultado. 
% Si este da negativo el sentido es hacia abajo.
%
%  Ejemplo:                                                             
%  
%  1) Datos:  Si para la rama 1 es:
%                F1=2000*1.175 Av, R1=270.56 kH^-1, R1e= 0 kH^-1
%                para la rama 2 es:
%                F2=0; R2=101.86kH^-1; R2e = 9.5493 MH^-1 
%                para la rama 3 es:
%                F3=2000*1.175 Av, R3 = 270.56 kH^-1; R3e = 0 kH^-1;
%
%  2) Se ingresa:  mag3(2000*1.175,270.56,0,0,101.86,9549.3,2000*1.175,270.56,0) 
%  3) Se obtiene:  
%               * Circuito magn�tico de tres ramas  |1| |2| |3| 
%                  los sentidos positivos en las ramas son indicados con ^ 
%                  Flujo1 ^ = 0.120064 mWb
%                  Flujo2 ^ = -240.128 �Wb  * Aqu� el sentido del flujo es hacia abajo
%                  Flujo3 ^ = 0.120064 mWb
%
%  Introducir     mag3(F1,R1,R1e,F2,R2,R2e,F3,R3,R3e)

% � Copyright 2019. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   30 de diciembre de 2018. Version 1.0

function y=mag3(F1,R1,R1e,F2,R2,R2e,F3,R3,R3e)

% Para indicar qu� hay que hacer cuando se introduce solo
% el nombre de la funci�n y evitar el mensaje de error
if nargin==0,
  disp('     Uso:  mag3(F1,R1,R1e,F2,R2,R2e,F3,R3,R3e)')
  disp('     Tipear ''help mag3'' para m�s ayuda.')
  disp('     C�tedra de Teor�a de Circuitos II.')
  disp(' ')
  return
end 


% Adecuaci�n de los datos
R1=R1*1000;
R1e=R1e*1000;
R2=R2*1000;
R2e=R2e*1000;
R3=R3*1000;
R3e=R3e*1000;

% Soluci�n del circuito de tres ramas caso general
delta=(R1*R2 + R1e*R2 + R1*R2e + R1e*R2e + R1*R3 + R1e*R3 + R2*R3 + R2e*R3 + R1*R3e + R1e*R3e + R2*R3e + R2e*R3e); 	 
flujo1 = (F1*R2 - F3*R2 + F1*R2e - F3*R2e + F1*R3 - F2*R3 + F1*R3e - F2*R3e)/delta;
flujo2 = -(-F2*R1 + F3*R1 - F2*R1e + F3*R1e + F1*R3 - F2*R3 + F1*R3e -F2*R3e)/delta;
flujo3 = (-F2*R1 + F3*R1 - F2*R1e + F3*R1e - F1*R2 + F3*R2 - F1*R2e +F3*R2e)/delta;
	 
% Presentaci�n de los resultados
fprintf('\n')

cprintf([1,0,0.1], '* Circuito magn�tico de tres ramas |1| |2| |3| \n');
cprintf([1,0.5,0.1], '  los sentidos positivos en las ramas son indicados con ^  \n');
cprintf('blue','  Flujo1 ^'),exi(flujo1),fprintf('Wb'),fprintf('\n')
cprintf('blue','  Flujo2 ^'),exi(flujo2),fprintf('Wb'),fprintf('\n')
cprintf('blue','  Flujo3 ^'),exi(flujo3),fprintf('Wb'),fprintf('\n')
fprintf('\r')