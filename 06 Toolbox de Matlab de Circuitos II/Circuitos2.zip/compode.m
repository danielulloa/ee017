% COMPODE es una funci�n que proporciona los valores de:
% las resistencias R2=R3=R4 de un COMPONENTE D
% cuando se le ingresa en este orden:    (Mucho Ojo con las Unidades)
%  1) El valor de D en fF.s (FEMTO (10E-15) F.s)
%  2) Un valor adoptado de C1=C5 en nF
%	                     o              	
%		                 | 	     	      	 
%    	                 *-----+          
%	 	               __|__   |               
%	 	            C1 _____   |               
%	                     |     |   |`.         
%	  +------------------*     +---|+ `.       
%	  |                  |         |    >---+  
%	  |                  >     +---|- ,'    |  
%	  |               R2 <	   |   |,'      |  
%	  |                  |     |    	    |  
%	  |            +-----*-----+            |  
%	  |            |     |	                |  
%	  |            |     > R3               |  
%	  |      .�|   |     <	                |  
%	  |    .� -|---+     |                  |  
%	  +---<    |         *------------------+  
%	       `. +|---+     |      		   
%  	         `.|   |     > R4    		
%	               |     <	    	    	
%	               |     |      	    	
%	               +-----*                     
%	    	           __|__            
%	    	           _____ C5
% 		       	        _|_     
% Ejemplo:	             -   
%  
%  1)  Datos D= 3.183E-12 F.s ,  C=10 nF 
%  2)  Se introduce: compode(3183,10)
%  3)  Se obtiene:        
%           Componente D 
%
%  R2=R3=R4= 31.6 kohm  C1=C5= 10 nF
%
%  Ver tambi�n BICUA, COMPODEA, KRCKI, KRCIK2, LSIMUL, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKALTO, VAEI y VAENOI
%
%  Introducir     compode(D,C)   D en fF.s , C en nF    

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function y=compode(D,C)

D=D*1e-15;

C=cnor(C);
C=C*1e-9;

R2=D/C^2;

% Valor normalizado m�s cercano

R2n=lnor(R2);

% Presentaci�n de los resultados
fprintf('\n')

fprintf('             Componente D '),fprintf('\n\n')
fprintf('  R2=R3=R4'),exi(R2n),fprintf('ohm'),fprintf('  C1=C5'),exi(C),fprintf('F'),fprintf('\n')
fprintf('\r')


 


