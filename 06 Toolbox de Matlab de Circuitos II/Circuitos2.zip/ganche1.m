% GANCHE1 Caracter�sticas de GANancia de filtros CHEbyshev I.
% Los filtros Chebyshev Tipo I tienen respuesta de igual ondulaci�n
% en la Banda de Paso.
% Esta es una funci�n que por omisi�n representa las respuestas de
% amplitud de filtros de orden 1 al 6 con una Am�x= 1dB.
%
% Se pueden ingresar adem�s:
%                      1)El orden N del filtro
%                      2)La atenuaci�n Am�x en la banda de paso
%                      3)Si es un pasalto agregar: 'pa'
% Ejemplos: 
% ganche1              Respuesta de filtros de orden N=2 a 7
% ganche1(4)           Respuesta de un filtro de orden 4 y Am�x=1dB
% ganche1(5,2)         Respuesta de un filtro de orden 5 y Am�x=2dB
% ganche1(8,0.5,'pa')  Respuesta de un filtro de orden 8, Am�x=0.5
%                      y pasaaltos
%
% Ingresar: ganche1(orden,Am�x[dB],'pa')
 
% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   7 de Julio de 2002. Version 1.0

function []=ganche1(orden,Amax,tipo)

%Si se ingresa el orden, verificar que no supere 16
% por que los dibuja mal.
if nargin==1 
if orden > 16
fprintf(' � El orden del filtro debe ser menor que 16 !.   '),fprintf('\n')
return %break
end
end

figure; clf;% % Se prepara y establece la presentaci�n de la figura
figure(gcf)
set(gcf, 'defaultaxesfontsize', 14)
set(gcf, 'defaulttextfontsize', 14)
set(gcf, 'defaultlinelinewidth', 1.5)
set(gcf, 'defaultlinemarkersize', 10)

% Frecuencia normalizada
fc=1;
wc=fc*2*pi; % pulsaci�n 
% Tipo de Filtroif nargin~=3 
	tipo='low';
end

if nargin==3 
	if tipo=='pj';
	tipo='low';	else
	tipo=='pa';
	tipo='high';
	end
end

% Para dibujar las lineas en colores
colormap(lines);
color_map=colormap;
colormap('default');
leyenda=' ';

% Atenuaci�n m�xima en la Banda de Paso del filtro Chebyshev I
if nargin<2 
Amax=3;
end

% Se genera el barrido de frecuencia que 
% produce un gr�fico que se inicia dos d�cadas antes
% y termina dos d�cadas despues de la frecuencia de corte.
inicio=floor(log10(fc/100));final=ceil(log10(fc*100));indice=[inicio:.01:final];w=2*pi*(10.^indice);
% Selecci�n en funci�n del argumento de entrada
% Se dibujan varias o una sola dependiendo de si se ingres� el orden
if nargin<1        % Sin argumentos se dibujan 6 curvas  
Nmin=2; Nmax=7;
else
Nmin=orden;Nmax=orden;  % Se dibuja s�lo la curva del orden pedido
end

% Se grafican las curvas de respuesta en frecuencia de orden N
for n=Nmin:Nmax	[b,a]=cheby1(n,Amax,wc,tipo,'s');	[hf,w]=freqs(b,a,w);
	%semilogx(w/(2*pi),20*log10(abs(hf))); % En azul	semilogx(w/(2*pi),20*log10(abs(hf)),'color',color_map(n,:)); % En varios colores
	hold on; grid on; zoom on; drawnow;	leyenda=strcat(leyenda,sprintf('N=%g',n)');
end;

% Titulos de la figura

% T�tulo global en la figura
title('Caracter�sticas de Amplitud de Filtros Chebyshev I');

% T�tulos de los ejes de la figura
xlabel('fn'); ylabel('Amplitud [dB]');

% Recuadro de la leyenda
if nargin<1             % Todas la curvas: en la esquina abajo a la izquierda 
legend(leyenda',3);
else
legend(leyenda',1); % Una sola: en la esquina de arriba a la derecha
end

% Subt�tulos de Teor�a de Circuitos II y la fecha
titulos





   
