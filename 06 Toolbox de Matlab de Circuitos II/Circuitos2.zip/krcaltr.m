% KRCALTR es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% KRC pasaALTtos con Ranura de 2� orden 
% cuando se le ingresa:                         (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) La frecuencia del cero fz en kHz
%                      3) El Q de la etapa
%                      4) La ganancia de alta frecuencia Haf en dB
%                      5) Un valor del capacitor C en nF 
%                      6) Un valor de la resistencia R0 en kohm
%
% Este circuito no puede suministrar una ganancia de alta frecuencia
% superior a Haf = -0.198719 dB. Si se supera esta especificaci�n
% se indica en los resultados el valor de Haf de la etapa.
% 
%  Ejemplo 1:
%  1) Datos: Si fp= 907.077 Hz, fz= 761.508Hz  kHz, el Q= 21.97, 
%            la ganancia de alta frec = 0 dB,
%            el C elegido es = 10 nF y la resistencia R0=10 kohm
%  
%  2) Se introduce:   krcaltr(0.907077,0.761508,22.1057,0,10,10)
%
%  3) Se obtiene:
%                Etapa KRC PasaAltos con ranura
%                R = 17.4 kohm   R/a = 19.6 kohm   R/(1-a) = 165 kohm
%                R0/c = 17.4 kohm   R0(K-1) = 34 kohm  ** Haf = -0.198719 dB **
%                C = 10 nF  bC = 10 nF  (1-b)C = 75 pF
%
%  Ejemplo 2:
%  A veces se tiene como dato la ganancia de continua Ho. En ese caso
%  se puede calcular la ganancia Haf en funci�n de la ganancia Ho 
%  con la expresi�n: Haf=Ho/(fz/fp)^2 y se ingresa este resultado en dB.
%
%  1) Datos: Si fp= 907.077 Hz, fz= 761.508Hz  kHz, el Q= 21.97, 
%            la ganancia de continua es = 0.363498,
%            el C elegido es = 10 nF y la resistencia R0=10 kohm
%
%  2) Se calcula: Haf= Ho/(fz/fp)^2 = 0.363498/(761.508/907.077)^2
%                 db(Haf)=-5.7512
%
%  3) Se introduce:   krcaltr(0.907077,0.761508,22.1057,-5.7512,10,10)
%
%  4) Se obtiene:
%                Etapa KRC PasaAltos con ranura
%                R = 17.4 kohm   R/a = 37.4 kohm   R/(1-a) = 33.2 kohm
%                R0/c = 19.1 kohm   R0(K-1) = 19.6 kohm  R0/(1-c) = 21 kohm
%                C = 10 nF  bC = 5.1 nF  (1-b)C = 4.7 nF
%
%                                     | |
%                    +----------------| |-----------------------+
%                    |                | | C                     |
%                    |                                          |
%  V1        R/a     |       R                         |`.      |
%  o---*---/\/\/\----*----/\/\/\----*------------------|+ `.    |
%      |             |              |                  |    >---*---o V2
%      |	         |    bC | |    |              +---|- ,'    |            
%      *---------------------| |----*              |   |,'      |           
%      |	         |       | |    |              |            |      
%      |		     |              |              | 	   	    |	         
%      | 	R0/c     |              |              |   R0(K-1)  |         
%      +---/\/\/\----------------------------------*---/\/\/\---+             
%  		             /            __|__            |   
%  	                 \ R/(1-a)    _____ (1-b)C     \ 
%  		             /              |              / R0/(1-c)			                                               
%  		            _|_            _|_             \			                                   
%  		             -              -             _|_			                                   
%  			                                       -                         
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     krcaltr(fp,fz,Q,Haf,C,R0)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1. �����

function y=krcaltr(fp,fz,Q,Haf,C,R0)

% Se adecuan los datos:

Haf=10^(Haf/20);
K=3-1/Q;
coefc=2*Haf/(K-1);
if coefc>1 
Haf=0.5*(K-1);
c=1; % Se fija el valor de c como el m�ximo posible
HafdB=20*log10(Haf);
else
c=coefc;
Haf=0.5*c*(K-1);    
end
Ho=Haf*(fz/fp)^2;
d=(1+0.5*(fz/fp)^2);
fp=fp*1000;
fz=fz*1000;
C=C*1e-9;
C=cnor(C);

% Se calculan a, b, y c ya fue calculado o fijado
a=-(Ho/K)*(d/(1-d));
b=(3/2)*(a-Ho/K);

% Se calcula R
R=1/(2*pi*fp*C);
% Se calcula R/a
Rsa=R/a;
Rsa=rnor(Rsa,1);
% Se calcula R/a
Rs1ma=R/(1-a);
Rs1ma=rnor(Rs1ma,1);
% Se calcula R0/c
R0=R0*1e3;
R0sc=R0/c;
R0sc=rnor(R0sc,1);
% Se calcula R0(K-1)
R0Km1=R0*(K-1);
R0Km1=rnor(R0Km1,1);
% Se calcula R0/(1-c)
if c~=1 
R0s1mc=R0/(1-c);
R0s1mc=rnor(R0s1mc,1);
end
% Se calcular bC
bC=b*C;
bC=cnor(bC);
% Se calcula (1-b)C;
mbC=(1-b)*C;
mbC=cnor(mbC);
% Se normaliza R
R=rnor(R,1);


% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa KRC PasaAltos con ranura'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   R/a'),exi(Rsa),fprintf('ohm')
fprintf('   R/(1-a)'),exi(Rs1ma),fprintf('ohm'),fprintf('\n')
fprintf('   R0/c'),exi(R0sc),fprintf('ohm'),
fprintf('   R0(K-1)'),exi(R0Km1),fprintf('ohm'),
if c~=1 
fprintf('  R0/(1-c)'),exi(R0s1mc),fprintf('ohm'),fprintf('\n')
else
fprintf('  ** Haf'),exi(HafdB),fprintf('dB **'),fprintf('\n')
end
fprintf('   C'),exi(C),fprintf('F'),  
fprintf('  bC'),exi(bC),fprintf('F'),        
fprintf('  (1-b)C'),exi(mbC),fprintf('F'),fprintf('\n'),fprintf('\n')



