function [ax,h]=tituloglobal(texto)
%
% TITULOGLOBAL Pone un t�tulo global centrado sobre un grupo de subgr�ficos.
% Proporciona un "handle" al titulo y un handle al eje.
% [ax,h]=tituloglobal(texto) proporciona handles tanto del ejes y de el titulo.
% ax=tituloglobal(texto) proporciona un "handle" solo al eje.

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   5 de Julio de 2002. Version 1.0

ax=axes('Units','Normal','Position',[.075 .075 .85 .85],'Visible','off');
set(get(ax,'Title'),'Visible','on');
title(texto);
if (nargout < 2)
  return;
end
h=get(ax,'Title');
