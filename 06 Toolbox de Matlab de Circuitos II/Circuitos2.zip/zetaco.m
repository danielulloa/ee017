% Funcion que acomoda los componentes de z

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


function [y] = zetaco (z)
w=zeros(size(z));
w(1)=z(1);
w(2)=z(2);
for i=3:length(z)-2
 w(i)=z(i+2);
end
w(length(z)-1)=z(3);
w(length(z))=z(4);

y=w;
