% COMPODEA es una funci�n que proporciona 
% los valores de las resistencias R2=R4=R5
% de un COMPONENTE D (Configuraci�n Alternativa)
% 		 o          	   cuando se le ingresa en este orden:
% 		 |    |	| C1       (Mucho Ojo con las Unidades)
% 		 *----| |-----+	   1) El valor de D  en fF.s (FEMTO (10E-15) F.s)
% 		 |    | |     |	   2) Un valor adoptado de C1=C2 en nF 
% 		 |	          | 	  
% 		 |   |`.      |    Ejemplo:
% 		 +---|- `.    |	           1) Datos D= 1,281E-14 F.s ,  C=1 nF      
% 		     | A1 >---* 	       2) Se introduce: compodea(12.81,1)                                      
%   +--------|+ ,'    | 	       3) Se obtiene:                            
%   |        |,'      |               Componente D Realizaci�n Alternativa:                                 
%   |           R2    |             	                                 
%   |	 +---/\/\/\---+		       R2=R4=R5= 12.7 kohm  C1=C3 = 1 nF         	   
%   |	 |	      			                     
%   |	 |    | | C3   		  %  Ver tambi�n BICUA, COMPODE, KRCKI, KRCIK2, LSIMUL,    
%   |	 *----| |-----+		  %  POLOSKRC, PRIMOR, PRIMORK,RANDTA, RANDTP,        
%   |	 |    | |     |		  %   RANSL, RM, SK, SKALTO, VAEI y VAENOI
%   |	 |            |		       
%   |    |   |`.      |   	        
%   |	 +---|- `.    |       	       
%   |	     | A2 >---*			           
%   +----*---|+ ,'    |       		                       
%        |   |,'      |       		                       
% 		 |            |       
% 		 *---/\/\/\---+       
%		 |     R4     
%		 /        
%		 \ R5       
%		 /          
%		_|_        
%		 -
%  Introducir     compodea(D,C)   D en fF.s , C en nF    

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   12 de Julio de 2002. Version 1.1

function y=compodea(D,C)

D=D*1e-15;

C=cnor(C);
C=C*1e-9;

R2=D/C^2;

% Valor normalizado m�s cercano

R2n=lnor(R2);

% Presentaci�n de los resultados
fprintf('\n')

fprintf('             Componente D Realizaci�n Alternativa:'),fprintf('\n\n')
fprintf('  R2=R4=R5'),exi(R2n),fprintf('ohm'),fprintf('  C1=C3'),exi(C),fprintf('F'),fprintf('\n')
fprintf('\r')



 


