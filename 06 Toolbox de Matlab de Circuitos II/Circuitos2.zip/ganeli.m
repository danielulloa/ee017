% GANELI Caracter�sticas de GANancia de filtros ELIpticos.
% Los filtros El�pticos tienen ondulaci�n tanto en la Banda
% de Paso como en la Banda de Ondulaci�n
% es una funci�n que por omisi�n representa las respuestas
% de amplitud de filtros de orden 1 al 6 con una Am�x= 3dB 
% y una Am�n=60 dB.
% Se pueden ingresar adem�s:
%                      1)El orden N del filtro
%                      2)La atenuaci�n Am�x en la banda de paso
%                      3)La atenuaci�n Am�n en la banda de atenuaci�n
%                      4)Si es un pasalto agregar: 'pa'
% Ejemplos: 
% ganeli                  Respuestas de filtros de orden 2 a 7
% ganeli(6)               Respuesta de un filtro de orden 7,
%                         Am�x=3dB y Am�n= 60dB
% ganeli(3,2)             Respuesta de un filtro de orden 3,
%                         y Am�x=2dB, Am�n= 60dB
% ganeli(5,2,50)          Respuesta de un filtro de orden 5, 
%                         Am�x=2dB y Am�n=50dB
% ganeli(8,0.5,60,'pa')   Respuesta de un filtro de orden 8,
%                         Am�x=0.5, Am�n=50dB y pasaaltos
%
% Ingresar: ganeli(orden,Am�x[dB],Am�n[dB],'pa')
 
% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   7 de Julio de 2002. Version 1.0

function []=ganeli(orden,Amax,Amin,tipo)

%Si se ingresa el orden, verificar que no supere 16
% por ya los dibuja mal.
if nargin==1 
if orden > 16
fprintf(' � El orden del filtro debe ser menor que 16 !.   '),fprintf('\n')
break
end
end

figure; clf;% % Se prepara y establece la presentaci�n de la figura
figure(gcf)
set(gcf, 'defaultaxesfontsize', 14)
set(gcf, 'defaulttextfontsize', 14)
set(gcf, 'defaultlinelinewidth', 1.5)
set(gcf, 'defaultlinemarkersize', 10)

% Frecuencia normalizada
fc=1;
wc=fc*2*pi; % pulsaci�n 
% Tipo de Filtroif nargin~=4 
	tipo='low';
end

if nargin==4 
	if tipo=='pj';
	tipo='low';	else
	tipo=='pa';
	tipo='high';
	end
end

% Para dibujar las lineas en colores
colormap(lines);
color_map=colormap;
colormap('default');
leyenda=' ';

% Atenuaci�n m�xima en la Banda de Paso del filtro El�ptico
if nargin<3 
Amax=3; Amin=60;
end

% Se genera el barrido de frecuencia que 
% produce un gr�fico que se inicia dos d�cadas antes
% y termina dos d�cadas despues de la frecuencia de corte.
inicio=floor(log10(fc/100));final=ceil(log10(fc*100));indice=[inicio:.01:final];w=2*pi*(10.^indice);
% Selecci�n en funci�n del argumento de entrada
% Se dibujan varias o una sola dependiendo de si se ingres� el orden
if nargin<1        % Sin argumentos se dibujan 6 curvas  
Nmin=2; Nmax=7;
else
Nmin=orden;Nmax=orden;  % Se dibuja s�lo la curva del orden pedido
end

% Se grafican las curvas de respuesta en frecuencia de orden N
for n=Nmin:Nmax	[b,a]=ellip(n,Amax,Amin,wc,'s');
	[hf,w]=freqs(b,a,w);;
	%semilogx(w/(2*pi),20*log10(abs(hf))); % En azul	semilogx(w/(2*pi),20*log10(abs(hf)),'color',color_map(n,:)); % En varios colores
	hold on; grid on; zoom on; drawnow;	leyenda=strcat(leyenda,sprintf('N=%g',n)');
end;
% Titulos de la figura

% T�tulo global en la figura
title('Caracter�sticas de Amplitud de Filtros El�pticos');

% T�tulos de los ejes de la figura
xlabel('fn'); ylabel('Amplitud [dB]');

% Recuadro de la leyenda
if nargin<1             % Todas la curvas: en la esquina abajo a la izquierda 
legend(leyenda',3);
else
legend(leyenda',3); % Una sola: en la esquina de arriba a la derecha
end

% T�tulos de Teor�a de Circuitos II y la fecha
titulos




   
