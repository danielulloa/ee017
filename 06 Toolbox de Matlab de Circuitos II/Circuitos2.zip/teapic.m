% TEAPIC realiza la CONVERSI�N DE T A PI para CAPACITORES
%          y proporciona los valores de las 
% Capacidades Ca, Cb y Cc del equivalente Pi de una red T de capacitores
% cuando se le ingresa en este orden:          (Ojo con las Unidades)
%      1) C1 de la red T en nF 
%      2) C2 de la red T en nF 
%      3) C3 de la red T en nF 
%  Se puede usar esta conversi�n para obtener valores m�s pr�cticos
%  de los capacitores pues en general disminuye el valor de los mismos.
%                   
%                                             
%          C1           C3                          Cb              
%         | |          | |         	               | |             	
%   o-----| |----*-----| |-----o 	   o----*------| |------*----o 	
%         | |    |     | |      	        |      | |      |      	
%              __|__           	    	  __|__           __|__     
%              _____ C2          ===>	  _____ Ca        _____ Cc  
%                |             	    	    |               |       
%                |             		        |               |       
%                o             		        +-------*-------+       
%							                        |
%						                            |
%  Ejemplo:						                    o
%  1)  Datos C1= 138.4nF, C2=875.4nF, C3=226.4nF
%  2)  Se introduce: teapic(138.4,875.4,226.4)
%  3)  Se obtiene:        
%                 Entre par�ntesis se indican 
%                 los valores normalizados al 5 por ciento.  
%                 Ca  = 97.6902 nF   (Can = 100 nF)
%                 Cb  = 25.2651 nF   (Cbn = 24 nF)
%                 Cc  = 0.159805 �F   (Ccn = 0.16 �F)
%
%  Ver tambi�n BICUA, COMPODE, COMPODEA, KRCKI, KRCIK2, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKALTO, TEAPIR, VAEI y VAENOI 
%
%  Introducir     teapic(C1,C2,C3)   C en nF    

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   12 de Julio de 2002. Version 1.1

function y=teapic(C1,C2,C3)

% Adecuaci�n de los valores ingresados
C1=C1*1e-9;
C2=C2*1e-9;
C3=C3*1e-9;

% C�lculo de los componentes de la transformacion de T a Pi
sumaC=C1+C2+C3;
Ca=C1*C2/sumaC;
Cb=C1*C3/sumaC;
Cc=C2*C3/sumaC;

% Valor normalizado m�s cercano

Can=cnor(Ca);
Cbn=cnor(Cb);
Ccn=cnor(Cc);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('  Entre par�ntesis se indican'),fprintf('\n')
fprintf('  los valores normalizados al 5 %. '),fprintf('\n')
fprintf('  Ca '),exi(Ca),fprintf('F'),fprintf('   (Can'),exi(Can),fprintf('F)'),fprintf('\n')
fprintf('  Cb '),exi(Cb),fprintf('F'),fprintf('   (Cbn'),exi(Cbn),fprintf('F)'),fprintf('\n')
fprintf('  Cc '),exi(Cc),fprintf('F'),fprintf('   (Ccn'),exi(Ccn),fprintf('F)'),fprintf('\n')
fprintf('\r')

 


