% La funcion NEGATIVO proporciona dado el polinomio P(s) el polinomio P(-s).

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0



function [y] = negativo(x)   
L=length(x);
for i=1:L,
  y(i) = [ x(i) * (-1)^(L-i)];
end

