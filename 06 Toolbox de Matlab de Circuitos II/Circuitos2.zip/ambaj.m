% AMBAJ es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% Akerberg-Mossberg pasaBajos de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa
%                      3) El valor de la ganancia de continua Ho en dB
%                      4) Un valor del capacitor C en nF 
%  Ejemplo:
%  1) Datos: Si fp= 1000 Hz, el Q= 10, 
%            la ganancia de continua = 0 dB, 
%            y el C elegido es = 10nF 
%  
%  2) Se ingresa:   ambaj(1,10,0,10)
%
%  3) Se obtiene:
%                Etapa AM Pasabajos 
%                R = 15.8 kohm   R/c = 15.8 kohm   QR = 158 kohm
%                C = 10 nF
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
% 	           +------------------------/\/\/\------------------------------+    
% 	           | 		                   R             R                  |    
% 	           |     QR                            +---/\/\/\---+   	    |	
% 	           *---/\/\/\----+	                   |            |	        |	
% 	           |	         |	              C    |      .�|   |	   R    |
% 	           |     | | C   |	             | |   |    .� -|---*---/\/\/\--* 
% 	           *-----| |-----*           +---| |---*---<    |      	        |   
% 	           |     | |     |	         |   | |        `. +|---+	        |	
% 	           |	         |	         |                `.|   |   	    |	
%              |    |`.      |	         |                     _|_	        |	
%              *----|- `.    |	   R     |   |`.                - 	        |    
%  	                |    >---*--/\/\/\---*---|+ `.     		        	    |  
%  	     	   +----|+ ,'    |	        /    |    >-------------------------+
% 	           |    |,'  	 |	       /  +--|- ,'        		             
% 	          _|_     		 o V2     /   |  |,'      		
% 	           -      		         /   _|_         		
% 	   V1		       R/c          /     -  
%       o------------/\/\/\--------+
%
%  Introducir     ambaj(fp,Q,Ho,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=ambajr(fp,Q,Ho,C)

% Se calcula c
Ho=10^(Ho/20);
c=Ho;

% Se adecuan los datos:
fp=fp*1000;
C=C*1e-9;
C=cnor(C);

% Se calcula R
R=1/(2*pi*fp*C);

% Se calcula QR
QR=Q*R;
QR=rnor(QR,1);

% Se calcula R/c
Rsc=R/c;
Rsc=rnor(Rsc,1);

% Se normaliza R
R=rnor(R,1);

% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa AM Pasabajos '),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   R/c'),exi(Rsc),fprintf('ohm')
fprintf('   QR'),exi(QR),fprintf('ohm'),fprintf('\n')
fprintf('   C'),exi(C),fprintf('F'),fprintf('\n\n')       




