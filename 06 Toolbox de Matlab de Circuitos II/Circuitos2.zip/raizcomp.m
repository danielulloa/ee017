% Selecciona las raices complejas de un polinomio 

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   05 de Noviembre de 2000. Version 1.0


function [Y] = raizcomp(X);

L=length(X);
Y=[];
for i=1:L
  
 if abs(imag(X(i)))>1e-12
     Y=[Y X(i)];
 end 

end
