% CGIBAJ es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% CGI pasaBAJos de 2� orden 
% cuando se le ingresa:                         (Ojo con las unidades                             (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa
%                      3) El valor de la ganancia de continua Ho en dB
%                      4) Un valor del capacitor C en nF 
%  Ejemplo:
%  1) Datos: Si la fp= 890 Hz, el Q= 0.707, la ganancia de continua = 0 dB
%  y el capacitor elegido es = 20 nF
%
%  2) Se ingresa:   cgibaj(0.89,0.707,0,20)
%
%  3) Se obtiene:
%                Etapa CGI Pasabajos
%                R = 8.87 kOhm  QR/b = 12.7 kOhm  QR/(1-b) = 12.7 kOhm
%                R/c = 8.87 kOhm  C = 20 nF  aC = 10 nF  (1-a)C = 10 nF
%
%      +---------------------------/\/\/\----------------------------------------+
%      |                             R/c                   |`.      	         |  
%      |	   aC         +--------------------------------|+ `.     	         |
%      |	   | |        |                                |    >---*---o V2     |    
%      *-------| |--------*                            +---|- ,'    |            |
%      |	   | |	      |                            |   |,'      |            |
%      |		          |                  	C      | 	   	    |	         |
% V1   | 	QR/b          |        R           | |     |     R      |      R     |
%    o-*---/\/\/\----*----*----/\/\/\----*-----| |-----*---/\/\/\---*---/\/\/\---*---+
%                    |    |              |     | |     |          	             |   |             
%  		             /	__|__            |      	   | 	 		             |   /
%  	        QR/(1-b) \  _____ (1-a)C     |      .�|    |	                     |   \ R/(1-c)
%  		             /    |              |    .� -|----+                         |   /			                                               
%  		            _|_  _|_             +---<    |                              |   |			                                   
%  		             -    -                   `. +|------------------------------+  _|_			                                   
%  			                                    `.|                     			 -                         
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     cgibaj(fp,Q,Ho,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=cgibaj(fp,Q,Ho,C)

% Se adecuan los datos:

ce=10^(Ho/20);

if ce>1 
fprintf(' La ganancia de continua no puede ser mayor de 0 dB  '),fprintf('\n')
break
end

a=ce/2;
b=ce/2;
fp=fp*1000;
C=C*1e-9;
C=cnor(C);
% Se calcula R
R=1/(2*pi*fp*C);
% Se calcula R/c
Rsc=R/ce;
Rsc=rnor(Rsc,1);
% Se calcula QR/b
QRsb=Q*R/b;
QRsb=rnor(QRsb,1);
% Se calcula QR/(1-b)
QRs1mb=Q*R/(1-b);
QRs1mb=rnor(QRs1mb,1);
% Se calcular aC
aC=a*C;
aC=cnor(aC);
% Se calcula (1-a)C;
maC=(1-a)*C;
maC=cnor(maC);
% Se normaliza R
R=rnor(R,1);

% Se calcula R/(1-c)
if ce~=1 
Rs1mc=R/(1-ce);
Rs1mc=rnor(Rs1mc,1);
end


% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa CGI Pasabajos'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('  QR/b'),exi(QRsb),fprintf('ohm')
fprintf('  QR/(1-b)'),exi(QRs1mb),fprintf('ohm'),fprintf('\n')
fprintf('   R/c'),exi(Rsc),fprintf('ohm'),
if ce~=1 
fprintf('  R/(1-c)'),exi(Rs1mc),fprintf('ohm'),fprintf('\n')
end
fprintf('   C'),exi(C),fprintf('F'),  
fprintf('  aC'),exi(aC),fprintf('F'),        
fprintf('  (1-a)C'),exi(maC),fprintf('F'),fprintf('\n'),fprintf('\n')





