% ATENBUT Representaci�n de las funciones de Atenuaci�n
% de la aproximaxi�n Butterworth

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   8 de Julio de 2002. Version 1.0

% % Se prepara y establece la presentaci�n de la figura
figure(1); clf;
figure(gcf)
set(gcf, 'defaultaxesfontsize', 14)
set(gcf, 'defaulttextfontsize', 14)
set(gcf, 'defaultlinelinewidth', 1.5)
set(gcf, 'defaultlinemarkersize', 10)

subplot(1,2,1);
w=linspace(0,1.1);
axis([0 1.1 0 7]);grid on;hold on
for n=1:10,
   a=10*log10(1+w.^(2*n));
   plot(w,a);
  end;
xlabel('\omega/\omega0');
ylabel('Atenuaci�n en la banda de Paso [dB]');
% title('Figura 1'); % T�tulo de la figura 1
hold off;

subplot(1,2,2);
w=linspace(0,10);
axis([0 10 0 140]);grid on;hold on;
for n=1:10,
   a=10*log10(1+w.^(2*n));
   plot(w,a);
   text(8-0.4*n,10*log10(1+(8-0.4*n).^(2*n)),num2str(n));
  end;
xlabel('\omega/\omega0');
ylabel('Atenuaci�n en la banda de Atenuaci�n [dB]');
% title('Fig. 2');% T�tulo de la figura 2

subplot(111);
set(gcf, 'defaultlinelinewidth', 1.5)

% T�tulos

% T�tulo global en la figura
tituloglobal('Gr�ficos de Atenuaci�n de los filtros Butteworth');

% Subt�tulos de Teor�a de Circuitos II y la fecha
titulos


