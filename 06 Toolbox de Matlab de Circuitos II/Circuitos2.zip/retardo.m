% Funci�n retardo de un filtro Chebyshev 
% Esta es la funci�n retado

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


clear
ret='(0.732329 + 0.543761* w^2  - 1.17775* w^4  + 1.45117* w^6)/(0.279326 - 0.250016* w^2  + 1.25001* w ^4 - 2.* w ^6 + w^8)'
%ezplot(ret);axis([0 1 0 13])
hold on
der=diff(ret);
der=simple(der)
ezplot(der) ; axis([0 1 0 13])