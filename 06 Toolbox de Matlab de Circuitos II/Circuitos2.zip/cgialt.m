% CGIALT es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% CGI pasaALTos de 2� orden 
% cuando se le ingresa:                         (Ojo con las unidades)                           (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa
%                      3) El valor de la ganancia de alta frecuencia en dB
%                      4) Un valor del capacitor C en nF 
%                                                          |`.      	           
%       	   aC         +--------------------------------|+ `.     	         
%  V1     	   | |        |                                |    >---*---o V2         
%    o---------| |--------*                            +---|- ,'    |            
%       	   | |	      |                            |   |,'      |            
%       		          |                  	C      | 	   	    |	         
%      	                  |        R           | |     |     R      |      R     
%                    *----*----/\/\/\----*-----| |-----*---/\/\/\---*---/\/\/\---*---+
%                    |    |              |     | |     |          	             |   |             
%  		             /	__|__            |      	   | 	 		             |   \
%  	             QR  \  _____ (1-a)C     |      .�|    |	                     |   / R
%  		             /    |              |    .� -|----+                         |   \			                                               
%  		            _|_  _|_             +---<    |                              |   |			                                   
%  		             -    -                   `. +|------------------------------+  _|_			                                   
%  			                                    `.|                     			 -                                
%  			                                     
%  Ejemplo: 
%  1) Datos: Si la fp= 890 Hz, el Q= 10, la ganancia de alta frecuencia = 0 dB
%  y el capacitor elegido es = 20 nF
%
%  2) Se ingresa: cgialt(0.89,10,0,20)
%
%  3) Se obtiene:
%                 Etapa CGI Pasaaltos
%                 R = 8.87 kohm  QR = 88.7 kohm
%                 C = 20 nF  aC = 10 nF  (1-a)C = 10 nF
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR, BGPJ
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     cgialt(fp,Q,Haf,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=cgialt(fp,Q,Haf,C)

% Se adecuan los datos:

a=(10^(Haf/20))/2;

if a>1 
fprintf(' La ganancia de continua no puede ser mayor de 0 dB  '),fprintf('\n')
break
end

fp=fp*1000;
C=C*1e-9;
C=cnor(C);
% Se calcula R
R=1/(2*pi*fp*C);
% Se calcula QR
QR=Q*R;
QR=rnor(QR,1);

% Se calcular aC
aC=a*C;
aC=cnor(aC);
% Se calcula (1-a)C;
maC=(1-a)*C;
maC=cnor(maC);
% Se normaliza R
R=rnor(R,1);


% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('    Etapa CGI Pasaaltos'),fprintf('\n')
fprintf('    R'),exi(R),fprintf('ohm')
fprintf('  QR'),exi(QR),fprintf('ohm'),fprintf('\n')  
fprintf('    C'),exi(C),fprintf('F'),  
fprintf('  aC'),exi(aC),fprintf('F'),  
fprintf('  (1-a)C'),exi(maC),fprintf('F'),fprintf('\n'),fprintf('\n')        




