% RESTAPOL sirve para restar dos polinomios de distinta longitud restando
% seg�n los coeficientes de la respectivas potencias

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


function [Y] = RESTAPOL (X1,X2)

LX1=length(X1);   
LX2=length(X2);
if LX2>LX1
NR=zeros(size(X2));      % 

	for i=1+LX2-LX1:LX2

		NR(i)=X1(i-(LX2-LX1));

	end

Y=X2-NR ;  % Ac� hago la RESTA
Y=-Y

else
NR=zeros(size(X1));
	
	for i=1+LX1-LX2:LX1

		NR(i)=X2(i-(LX1-LX2));

	end
Y=X1-NR;   % Ac� hago la RESTA
end