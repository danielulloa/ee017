% RANDTA es una funci�n que proporciona los valores de:
% la resistencias R1 y R2 del divisor de tensi�n,
% las resistencias  R, R/2 y los capacitores C y 2C de la red doble T
% de un filtro  RANURA DOBLE T ACTIVA
% cuando se le ingresa en este orden:           (Ojo con las Unidades)
%                       1) La frecuencia de ranura en KHz
%                       2) El Q de la etapa
%                       3) La Resistencia R1 del divisor en kohm 
%                       4) Un valor de la Capacidad C de la red en nF
%                                                                
%                    	                  +------------+ 	  
%                                         |  |`.       |	  
%                                         +--|- `.     | 	  
%              R               R             |    >----*---o V2  
%       +---/\/\/\-----*----/\/\/\---*-------|+ ,'     |         
%       |              |             |       |,'       |   
%       |            __|__           |                 /        
%       |            _____ 2C        |  +----------+   \ R2      
%       |              |             |  |     .�|  |   /       
%   V1  |              |             |  |   .� -|--+   | 
%   o---*              *-------------|--*--<    |      | 
%       |              |	         |      `. +|------* 
%       |              /	         |	      `.|      | 
%       |              \ R/2	     |     	           /
%       |  	           /	         |	               \ R1
%       |     | |      |     | |     |                 /
%       +-----| |------*-----| |-----+		           | 
%	          | | C          | | C     	              _|_
%       					                           -       
%  Ejemplo:
%  1)  Datos fp= 50 Hz, Q=25, R1=10 kohm y se adopta C=100 nF 
%  2)  Se introduce: randta(.05,25,10,100)
%  3)  Se obtiene:        
%  Filtro  Ranura Doble T Activo
%  R1 = 10 kohm  R2 = 102 ohm  (Resistencias del divisor de tensi�n)
%  R = 31.6 kohm  R/2 = 15.8 kohm  C = 100 nF  2C = 0.2 �F
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,
%              PRIMORK, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     randta(fp,Q,R1,C)       

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   11 de Julio de 2002. Version 1.2

function y=randta(fp,Q,R1,C)

fp=fp*1000;
R1=R1*1000;
C=C*1e-9;

K=1-1/(4*Q);
R2=R1*(1/K-1);
R=1/(2*pi*fp*C);
Rd2=R/2;

% Valor normalizado m�s cercano

Rn=rnor(R,1);
Rd2n=rnor(Rd2,1);
R1n=rnor(R1,1);
R2n=rnor(R2,1);
Cn=cnor(C);
Cp2=2*Cn;
Cp2n=cnor(Cp2);

% Presentaci�n de los resultados
fprintf('\n')

fprintf('   Filtro  Ranura Doble T Activo'),fprintf('\n')
fprintf('   R1'),exi(R1n),fprintf('ohm')
fprintf('  R2'),exi(R2n),fprintf('ohm'),fprintf('  (Resistencias del divisor de tensi�n)'),fprintf('\n')
fprintf('   R'),exi(Rn),fprintf('ohm')         
fprintf('  R/2'),exi(Rd2n),fprintf('ohm')
fprintf('  C'),exi(Cn),fprintf('F')         
fprintf('  2C'),exi(Cp2n),fprintf('F'),fprintf('\n')
fprintf('\r')



 


