% LNOR(L) es una funci�n que proporciona los valores de inductores normalizados del valor
% del argumento, suponiendo una tolerancia del 1 %.

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


function y=lnor(L)

exp=fix(log10(L)); % para hallar el exponente de la potencia

if L <= 1
 Lapn=10*L*10^(-exp); %Para llevar al valor normalizado para comparacion
else
 Lapn=L*10^(-exp);    
end

% Inductores normalizados a 1 %
Lnorm=[100 102 105 107 110 113 115 118 121 124 127 130 133 137 140 143 147 150 154 158 162 165 169 174,...
       178 182 187 191 196 200 205 210 215 221 226 232 237 243 249 255 261 267 274 280 287 294 301 309,...
       316 324 332 340 348 357 365 374 383 392 402 412 422 432 442 453 464 475 487 499 511 523 536 549,...
       562 576 590 604 619 634 649 665 681 698 715 732 750 768 787 806 825 845 866 887 909 931 953 976 1000 1020];
Lnorm=Lnorm/100;
LL=length(Lnorm);
maxdif=100;

for i=1:LL
  Dif=abs(Lnorm(i)/Lapn-1)*100;
  maxdif=min(Dif,maxdif);
   
  if maxdif < Dif,break, end
  
end	


if L <= 1
 y=(Lnorm(i-1)*10^(exp))/10; 
else
 y=(Lnorm(i-1)*10^(exp)); 
end
