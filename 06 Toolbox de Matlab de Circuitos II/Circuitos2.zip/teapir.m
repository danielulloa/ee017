% TEAPIR realiza la CONVERSI�N DE T A PI para RESISTENCIAS
%          y proporciona los valores de las 
% Resistencias Ra, Rb y Rc del equivalente Pi de una red T de resistencias
% cuando se le ingresa en este orden:          (Ojo con las Unidades)
%      1) R1 de la red T en kohm 
%      2) R2 de la red T en kohm 
%      3) R3 de la red T en kohm 
%                   
%          R1          R3         	               Rb            	
%   o---/\/\/\--*----/\/\/\---o 	   o----*----/\/\/\----*----o 	
%                |               	        |              |      	
%                /           	    	    /              /     
%                \ R2           ===>        \ Ra           \ Rc  
%                /             	            /              /        
%                |             		        |              |       
%                o             		        +-------*------+       
%							                        |
%	                                                o
%  Ejemplo:						                    
%  1)  Datos R1= 10 kohm, R2=500 ohm, R3=20kohm
%  2)  Se introduce: teapir(10,0.5,20)
%  3)  Se obtiene:        
%                 Entre par�ntesis se indican
%                 los valores normalizados al 1 por ciento. 
%                 Ra  = 10.75 kohm   (Ran = 10.7 kohm)
%                 Rb  = 430 kohm   (Rbn = 432 kohm)
%                 Rc  = 21.5 kohm   (Rcn = 21.5 kohm)
%
%  Ver tambi�n BICUA, COMPODE, COMPODEA, KRCKI, KRCIK2, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKALTO, TEAPIC, VAEI y VAENOI 
%
%  Introducir     teapir(R1,R2,R3)   R en kohm    

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1

function y=teapir(R1,R2,R3)

% Adecuaci�n de los valores ingresados
R1=R1*1e3;
R2=R2*1e3;
R3=R3*1e3;

% C�lculo de los componentes de la transformacion de T a Pi
nume=R1*R2+R1*R3+R2*R3;
Ra=nume/R3;
Rb=nume/R2;
Rc=nume/R1;

% Valor normalizado m�s cercano

Ran=rnor(Ra,1);
Rbn=rnor(Rb,1);
Rcn=rnor(Rc,1);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('  Entre par�ntesis se indican'),fprintf('\n')
fprintf('  los valores normalizados al 1 por ciento. '),fprintf('\n')
fprintf('  Ra '),exi(Ra),fprintf('ohm'),fprintf('   (Ran'),exi(Ran),fprintf('ohm)'),fprintf('\n')
fprintf('  Rb '),exi(Rb),fprintf('ohm'),fprintf('   (Rbn'),exi(Rbn),fprintf('ohm)'),fprintf('\n')
fprintf('  Rc '),exi(Rc),fprintf('ohm'),fprintf('   (Rcn'),exi(Rcn),fprintf('ohm)'),fprintf('\n')
fprintf('\r')

 


