%  RESITOT proporciona el residuo y los componentes cuando se extrae
% totalmente un polo para lo cual se ingresa el numerador n y denominador
% de la inmitancia y el polo que se extrae totalmente
% Calculo del residuo para remocion completa del polo

% Funciones adicionales usadas en este programa:
% stair, elicero

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


function [kr,Lp,Cp]=resitot(n,d,polo)

p0=poly(0);
p3=[1 0 abs(polo)^2];

nk=n;
dk=deconv(d,p3);
dk=conv(dk,p0);

nke=polyval(nk,polo);
dke=polyval(dk,polo);

kr=nke/dke; % residuo 

ks=kr*p0;

%comp=stair(p3,ks);    % Circuito LC paralelo a remover como rama serie
%[LC]=elicero(comp);   % Da primero la C y luego la L

%Lp=LC(2);
%Cp=LC(1);
Lp=kr/abs(polo)^2;
Cp=1/kr;




