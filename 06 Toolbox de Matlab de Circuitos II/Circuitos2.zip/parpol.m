% PARPOL proporciona la parte para de un polinomio , es decir los coeficientes
% de los exponentes pares de las potencias de s
% Conservando el orden del vector

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function [Y] = parpol (X)
Y=zeros(size(X));
dimY = length(Y);

if (rem(dimY-1,2) == 0),
  i = 1;
else
  i = 2;
end

while (i <= dimY),
  Y(i) = X(i);
  i = i + 2;
end
    
