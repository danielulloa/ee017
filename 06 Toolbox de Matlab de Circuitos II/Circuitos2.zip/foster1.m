% FOSTER1: S�NTESIS DE UNA RED LC MEDIANTE EL PRIMER M�TODO DE FOSTER 
% Este programa sintetiza una impedancia de tipo LC presentada
% en la forma de un cociente entre polinomios en la variable s. 
% cuando se le ingresa el numerador y el denominador de la
% impedancia.
% Produce como salida la Impedancia sintetizada mediante una
% descripci�n de la interconexi�n de los componentes y sus valores
%
% Ejemplo: Si la impedancia a sintetizar es
% Z(s)= (4s^4 + 40s^2 + 36) / (s^3+ 4s)
% en el indicador de Matlab se ingresa:
% �foster1
% y aparece una solicitud de
%Ingresar el Numerador en el formato [n(n) n(n-1)...n(0)]
% � [4  0  40 0 36]  <----- Se ingresa lo pedido y aparece:
%Ingresar el Denominador en el formato [d(n) d(n-1)...d(0)]
% � [1  0  4  0]  <----- Se ingresa lo pedido
%
% y se obtiene:  
%*** Impedancia Z(s)sintetizada mediante Foster 1 ***
% Los terminales de la impedancia son 
%    el nodo = 1 y el nodo = 4 
% y los componentes se conectan de la siguiente manera:
% Entre el nodo = 1  y el nodo = 2 :  L = 4 H
% Entre el nodo = 2  y el nodo = 3 :  L = 3.75 H
% Entre el nodo = 2  y el nodo = 3 :  C = 66.6667 mF
% Entre el nodo = 3  y el nodo = 4 :  C = 0.111111 F .
%
% Para este ejemplo la impedancia Z(s) es:
%
%                		         3.75 H
%                          +-----//////-----+
%       1       4H       2 |	          3 | 	  0.111 F    4
%        o----//////-------*------| |-------*------| |------o 
%                               66.667 mF 
%
% Ver tambi�n: CAUER1, CAUER2 y FOSTER2  

%   � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio 2002. Version 1.0

% Se establecen las variables globales
global color num den limites
if isempty(color)
   color='r';
end

%Ingreso del numerador y denominador

fprintf('Ingresar el Numerador en el formato [n(n) n(n-1)...n(0)]'),fprintf('\n')
num=input(' � ');
fprintf('Ingresar el Denominador en el formato [d(n) d(n-1)...d(0)]'),fprintf('\n')
den=input(' � ');


m=length(num)-1;
n=length(den)-1;

     

% Las instrucciones siguientes realizan una comprobaci�n simple si la
% funci�n es real y positiva
% 
if abs(m-n)>1
 sprintf('La funci�n no es sintetizable ')
end
% 
% Se comprueba si los coeficientes son reales y positivos
%
for i=1:m+1;
 if (num(i)<0)|(imag(num(i))~=0)
  sprintf('La funci�n no es real positiva')
 end
end
for i=1:n+1;
 if (den(i)<0)|(imag(den(i))~=0)
  sprintf('La funci�n no es real positiva')
 end
end
%
% El paso siguiente consiste en calcular los polos y ceros y verificar
% que son imaginarios
%
ceros=roots(num);
polos=roots(den);
nr=find(real(ceros)~=0);
pr=find(real(polos)~=0);
if (length(nr)~=0)
 sprintf('La funci�n no representa un dipolo LC')
end
if (length(pr)~=0)
 sprintf('La funci�n no representa un dipolo LC')
end

% Se calcula el valor m�ximo para luego graficar
if isempty(limites)
   cm=max(ceros);
   pm=max(polos);
   limites=[0,abs(max(cm,pm))+.5,-10,10];
end


% Mediante la funci�n residue se calculan los res�duos de la funci�n 
% a sintetizar (res), los polos de la misma (pol), y el cociente
% de la divisi�n entre el numerador y el denominador (k).
%
[res,pol,k]=residue(num,den);
res;
pol;
k;
if (res==zeros)
 sprintf('Los polinomios son proporcionales')
end
%
% Procedimiento de s�ntesis.
% Si m < n resulta k=0, y sino k~=0, esto es, hay un residuo 
% del polo en el infinito que corresponde a un inductor en serie.
% 
nodo=1;  % Se inicializa la variable nodo
circuito=[]; %Se pone a cero la variable circuito

if ~isempty(k) %(k~=[])
 circuito(1,1)=nodo;
 circuito(1,2)=nodo+1;
 circuito(1,3)=k(1);     % Se da el valor de la inductancia entre el nodo 1 y 2
 circuito(1,4)=1;        % Con el 1 se indica que es una inductancia
 i=2;
 nodo=2;
else
 i=1;
 nodo=1;
end
j=1;
while j<=n
%  
% Se examina la parte imaginaria de los polos puesto que si se encuentra un 
% polo con parte imaginaria nula quiere decir que representa 
% un capacitor en serie.
%
if (imag(pol(j))==0)
 circuito(i,1)=nodo;
 circuito(i,2)=nodo+1;
 circuito(i,3)=1/res(j);  % El valor del capacitor es el inverso del residuo
 circuito(i,4)=2;         % Se indica que es un capacitor con este 2
 i=i+1;
 j=j+1;
 nodo=nodo+1; % Actualizaci�n del contador %
else
% 
% Ahora no hay polo en el origen. 
% Esto quiere decir que en el circuito quedan pares de polos complejos conjugados 
% que se sintetizan poniendo en paralelo un inductor y un capacitor.
% Para ver como est� hecha la funci�n que se sintetiza con tal
% par de polos, se usa ahora la funci�n 'residue' de forma inversa
% esto es dando los valores de los residuos y de los polos reconstruimos
% el numerador (num1) y el denominador(den1) 
% 
[num1,den1]=residue(res(j:j+1),pol(j:j+1),[]);
%
% C�lculo de los componentes mediante los coeficientes obtenidos de los polinomios numerador
% y denominador.
%
 num1;
 den1;
 circuito(i,1)=nodo;
 circuito(i,2)=nodo+1;
 circuito(i,3)=num1(1)/den1(3);
 circuito(i,4)=1;                  % Inductor
 circuito(i+1,1)=nodo;
 circuito(i+1,2)=nodo+1;
 circuito(i+1,3)=den1(1)/num1(1);
 circuito(i+1,4)=2;                % Capacitor
%
% Se actualizan los �ndices i y j incrementandolos en 2 unidades porque
% se han sintetizado 2 componentes.
% 
 i=i+2;
 j=j+2;
 nodo=nodo+1;
end
end

%
% Visualizaci�n de la tabla que contiene el resultado de la s�ntesis 
% 
disp('  ')
%disp('Nodoinicial, Nodofinal, Valor(F o H), Tipo de Componente(1 -> L,2 -> C)')

circuito;

% Para indicar la impedancia sintetizada
tama=size(circuito);
numerodefilas=tama(1,1);numerodecolumnas=tama(1,2);
nodoi=circuito(1:numerodefilas,1);
nodof=circuito(1:numerodefilas,2);
valores=circuito(1:numerodefilas,numerodecolumnas-1);
componentes=circuito(1:numerodefilas,numerodecolumnas);
nodomax=max(max(nodoi),max(nodof));
fprintf(' *** Impedancia Z(s) sintetizada mediante Foster 1 ***'),fprintf('\n')
fprintf(' Los terminales de la impedancia son '),fprintf('\n'),
fprintf('    el nodo = 1 y el nodo'),exi(nodomax),fprintf('\n')
fprintf(' y los componentes se conectan de la siguiente manera:'),fprintf('\n')

for k=1:numerodefilas
    fprintf(' Entre el nodo'),exi(nodoi(k)),fprintf(' y el nodo'),exi(nodof(k))

   if componentes(k)==1
      fprintf(':  L'),exi(valores(k)),fprintf('H'),fprintf('\n')

   else
      fprintf(':  C'),exi(valores(k)),fprintf('F'),fprintf('\n')
   end
   
end

fprintf('\r')

