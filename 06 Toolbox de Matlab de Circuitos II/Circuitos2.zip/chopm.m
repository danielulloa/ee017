% CHOPM Es una funci�n que elimina los valores
% muy peque�os de un vector.
% Usa una tolerancia por omision de 10^-12

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0



function [Y] = chopm(X)

Y = [];
for i=1:length(X)
if (X(i))>1e-12,       
    Y = [Y X(i)];
    i = i + 1;
end
end