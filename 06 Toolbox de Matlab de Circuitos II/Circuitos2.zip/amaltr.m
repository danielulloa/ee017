% AMALTR es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% Akerberg-Mossberg pasaAltos con Ranura de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) La frecuencia del cero fz en kHz
%                      3) El Q de la etapa
%                      4) La ganancia de alta frecuencia Haf en dB
%                      5) Un valor del capacitor C en nF 
%  Ejemplo:
%  1) Datos: Si fp= 1000 Hz, fz= 700 Hz, el Q= 10, 
%            la ganancia de alta frecuencia = 3 dB, 
%            y el C elegido es = 10nF 
%  
%  2) Se ingresa:   amaltr(1,0.7,10,3,10)
%
%  3) Se obtiene:
%                Etapa AM PasaAltos con ranura
%                R = 15.8 kohm   R/c = 23.2 kohm   QR = 158 kohm
%                C = 10 nF  aC = 15 nF
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
% 	           +------------------------/\/\/\------------------------------+    
% 	           | 		                   R             R                  |    
% 	           |     QR                            +---/\/\/\---+   	    |	
% 	           *---/\/\/\----+	                   |            |	        |	
% 	           |	         |	              C    |      .�|   |	   R    |
% 	           |     | | C   |	             | |   |    .� -|---*---/\/\/\--* 
% 	           *-----| |-----*           +---| |---*---<    |      	        |   
% 	           |     | |     |	         |   | |        `. +|---+	        |	
% 	     aC    |	         |	         |                `.|   |   	    |	
% V1     | |   |    |`.      |	         |                     _|_	        |	
%  o--*--| |---*----|- `.    |	   R     |   |`.                - 	        |    
%  	  |	 | |        |    >---*--/\/\/\---*---|+ `.     		        	    |  
%  	  | 	   +----|+ ,'    |	        /    |    >-------------------------+
% 	  |        |    |,'  	 |	       /  +--|- ,'        		             
% 	  |       _|_     		 o V2     /   |  |,'      		
% 	  |        -      		         /   _|_         		
% 	  |  			  R/c           /     -  
%     +-------------/\/\/\---------+
%
%  Introducir     amaltr(fp,fz,Q,Haf,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=amaltr(fp,fz,Q,Ha,C)


% Se calculan a y c
Ha=10^(Ha/20);
a=Ha;
c=a*((fz/fp)^2);

% Se adecuan los datos:
fp=fp*1000;
C=C*1e-9;
C=cnor(C);

% Se calcula R
R=1/(2*pi*fp*C);

% Se calcula QR
QR=Q*R;
QR=rnor(QR,1);

% Se calcula R/c
Rsc=R/c;
Rsc=rnor(Rsc,1);

% Se calcular aC
aC=a*C;
aC=cnor(aC);

% Se normaliza R
R=rnor(R,1);

% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa AM PasaAltos con ranura'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   R/c'),exi(Rsc),fprintf('ohm')
fprintf('   QR'),exi(QR),fprintf('ohm'),fprintf('\n')
fprintf('   C'),exi(C),fprintf('F'),  
fprintf('  aC'),exi(aC),fprintf('F'), fprintf('\n\n')       




