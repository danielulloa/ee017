% RM3BUTA es una funci�n que proporciona los 
% valores de los Resistores R1,R2, R3 de un FILTRO
% ***  Realimentaci�n M�ltiple de 3�orden Butterworth PasaAlto ***
% cuando se le ingresa en este orden:          (Ojo con las unidades)
%                      1) La frecuencia del corte fc en kHz
%                      3) Un valor de la capacidad C en nF
%	                			    	       | | 
%                             	  +------------| |--------------+  
%                             	  |            | | C/2          |  
%                             	  |                             |  
%                             	  |            +-----/\/\/\-----*    
%                             	  |            |        R3      |    
%                             	  |            |                |    
%         | | C         | | C     |    | | C   |      |`.       |    
% V1 o----| |-----*-----| |-------*----| |-----*------|- `.     |      
%         | |     |     | |       |    | |            |     >---*---o V2
%                 \           	  \                +--|+ ,'        
%                 /          	  /                |  |,'          
%                 \ R1        	  \ R2            _|_              
%                 /           	  /                -    
%                _|_          	 _|_                      
%                 -           	  -                         
% Por ejemplo:   rm3buta(4,2.2) proporciona:
%
%   Filtro RM de 3�orden Butterworth PasaAlto
%   R1 = 7.32 kohm  R2 = 8.66 kohm  R3 = 93.1 kohm
%   C/2 = 1.1 nF. Se adopt�: C = 2.2 nF
%
%
%  Ver tambi�n: BICUA, KRCI, KRCK2, PBDA, PTA1, PTA2, PTP1, PTP2,
%               POLOSKRC, PRIMOR, PRIMORK, RANDTA, RANDTP, RANSL,
%               RM, RM3BUT, SK, SK3BUT, SKPA, VAEI y VAENOI 
%
%  Introducir     rm3buta(fc,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1

function y=rm3buta(fc,C)

% Adecuaci�n de los datos
fc=fc*1000;
C=C*1e-9;
% Se elige una capacidad normalizada
% si en la entrada no se lo ha hecho
Cn=cnor(C);
C2=Cn/2;
C2n=cnor(C2);

den=(2*pi*fc*Cn);

% C�lculo del resistor R1
	R1=0.40734/den;
	R1n=rnor(R1,1);
% C�lculo del resistor R2
	R2=0.474128/den;
	R2n=rnor(R2,1);
% C�lculo del resistor R3
	R3=5.17782/den;
	R3n=rnor(R3,1);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('  Filtro RM de 3�orden Butterworth PasaAlto'),fprintf('\n')
fprintf('  R1'),exi(R1n),fprintf('ohm')
fprintf('  R2'),exi(R2n),fprintf('ohm')
fprintf('  R3'),exi(R3n),fprintf('ohm'),fprintf('\n')
fprintf('  C/2'),exi(C2n),fprintf('F.')
fprintf(' Se adopt�: C'),exi(Cn),fprintf('F')
fprintf('\n')
fprintf('\r')



