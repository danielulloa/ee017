% CHE2ABAJO es un programa que suministra fp y el Q para el proyecto de
%           FILTROS CHEBYSHEV Tipo II ACTIVOS PASABAJOS 
% 	ingresando: 
%       1) La frecuencia de corte de 3dB de la banda de paso
%       2) La atenuaci�n m�nima en la banda de atenuaci�n
% 	    3) El orden n del filtro

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0

fprintf('--------    PROYECTO DE FILTROS CHEBYSHEV II ACTIVOS PASABAJOS    ----------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')

% Ingresos de la frecuencias, la atenuaci�n y el orden
fc=input(' Ingresar la frecuencia de corte de 3dB en kHz:   ');
fprintf(' Ingresar la atenuaci�n m�nima  '),fprintf('\n')
Amin=input(' en la banda de atenuaci�n, Amin en dB :   ');
orden=input(' Ingresar el orden del filtro:   ');

 % Determinaci�n de los polos y ceros de la funci�n Chebyshev tipo II
[ceros,polos,ganancia] = cheby2(orden,Amin,1,'s');

% Para normalizaci�n a la frecuencia de -3dB
epsilon =1/sqrt(10^(.1*Amin)-1);
W3dB=1/(cosh(acosh(1/epsilon)/orden));
Kf=fc*1000/W3dB;

% Determinaci�n de los coeficientes
% de la etapas de segundo orden:
[A,final]=segundo(polos);
[B,final2]=segundo(ceros);

% Presentaci�n de lor resultados
fprintf('\n')
fprintf('          * 2) fp, fz y Q de cada etapa del'),fprintf(' \n')
fprintf('\n')
fprintf(' Filtro Chebyshev II de orden'),exi(orden),
fprintf(', Amin'),exi(Amin),fprintf('dB'),fprintf('\r')
fprintf(' y frecuencia de corte '),exi(fc*1000),fprintf('Hz'),fprintf('\n')

fprintf(' \n')
fprintf(' Etapas de 2� orden:'),fprintf('\n')
for i=1:final
	a=A(i,:);
 	if a(1)==1
 		wp=sqrt(a(3));
 		Q=wp/a(2);
  		%Impresi�n de los polos
  		
  		fprintf(' fp'),exi(wp*Kf),fprintf('Hz')
  		% Impresi�n de los ceros
  		b=B(i,:);
		wz=sqrt(b(3));
		fprintf('   fz'),exi(wz*Kf),fprintf('Hz')
		% Impresi�n del Q	
		fprintf('   Q'),exi(Q),fprintf('\n')%,fprintf('\n')
 	else
 		fprintf('\n'),fprintf(' Etapa de 1� orden:'),fprintf('\n')
 		fprintf(' fp'),exi(a(3)*Kf),fprintf('Hz'),fprintf('\n')
 		fprintf('\n')
	end
end
fprintf('\n')
















