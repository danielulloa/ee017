% ELICOMP es una funci�n auxiliar para uso de los programas 
%              ELIABAJ, ELIABAJO y ELIABAN para 
% determinar la frecuencia a la cual EL M�DULO DE LA TRANSFERENCIA 
% es igual a raiz de 2

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function [y]=elicomp(w)
global PNUME PDENE KNUME
nenw=polyval(PNUME,j*w);
denw=polyval(PDENE,j*w);
modulo=abs(KNUME*nenw/denw);
y=modulo-sqrt(2)/2;
