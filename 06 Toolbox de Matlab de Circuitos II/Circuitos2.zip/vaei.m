% VAEI es una funcion que proporciona los valores de:
% las resistencias R Y R2
% de un filtro  DE VARIABLES DE ESTADO INVERSOR
% cuando se le ingresa en este orden:              (Ojo con las Unidades)
%                       1) La frecuencia central del filtro en KHz
%                       2) El Q de la etapa
%                       3) El valor de la resistencia R1 en KOhms
%                       4) Un valor de la Capacidad C en nF
%  
%  Ejemplo
%  1)  Datos fp= 1 KHz, Q=100, R1= 1 KOhms C=2.2 nF 
%  2)  Se introduce: vaei(1,100,1,2.2)
%  3)  Se obtiene:        
%            Filtro de Variables de estado inversor:
%  R= 71.5 KOhms  R2 = 301 KOhms
%  (Las Resistencias R3 se adoptan )
%
%  Ver tambien BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, SKALTO y VAENOI 
%
%  Introducir     vaei(fp,Q,R1,C)       

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function y=vaei(fp,Q,R1,C)

fp=fp*1000;
R1=R1*1000;
C=C*1e-9;

R=1/(2*pi*fp*C);
R2=(3*Q-1)*R1;

% Valores normalizados m�s cercanos

Rn=rnor(R,1);
R2n=rnor(R2,1);

% Presentacion de los resultados
fprintf('\n')

fprintf('             Filtro de variables de estado inversor:'),fprintf('\n')
fprintf('  R'),exi(Rn),fprintf('Ohms')
fprintf('  R2'),exi(R2n),fprintf('Ohms'),fprintf('\n')
fprintf('  (Las Resistencias R3 se adoptan )'),fprintf('\n')



 


