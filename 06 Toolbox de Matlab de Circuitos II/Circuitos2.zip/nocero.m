% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function [Y] = NOCERO (X)

[nulo, dimX] = size(X);

i = 1;
Y = [];
while ((i < dimX) & (abs(X(i))<eps)),
  i = i + 1;
end
Y = [];
if (abs(X(i))>eps),
  while (i <= dimX),
    Y = [Y X(i)];
    i = i + 1;
  end
end