% KRCTOD es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% KRC pasaTodo de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2  El Q de la etapa
%                      3) Un valor del capacitor C en nF 
%                      4) Un valor de la resistencia R0 en kohm
%  Ejemplo:
%  1) Datos: Si fp= 1400 Hz, el Q= 1.34, 
%            el C elegido es = 10 nF y R0 = 5 kohm
%  
%  2) Se ingresa:   krctod(1.4,1.34,10,5)
%
%  3) Se obtiene:
%                Etapa KRC Pasatodo
%                R = 11.3 kohm   R/a = 15 kohm   R/(1-a) = 47.5 kohm
%                R0/c = 4.99 kohm   R0(K-1) = 6.34 kohm  ** Ho = -6.81077 dB **
%                C = 10 nF  bC = 7.5 nF  (1-b)C = 2.4 nF
%                                     | |
%                    +----------------| |-----------------------+
%                    |                | | C                     |
%                    |                                          |
%  V1        R/a     |       R                         |`.      |
%  o---*---/\/\/\----*----/\/\/\----*------------------|+ `.    |
%      |             |              |                  |    >---*---o V2
%      |	         |    bC | |    |              +---|- ,'    |            
%      *---------------------| |----*              |   |,'      |           
%      |	         |       | |    |              |            |      
%      |		     |              |              | 	   	    |	         
%      | 	R0/c     |              |              |   R0(K-1)  |         
%      +---/\/\/\----------------------------------*---/\/\/\---+             
%  		             /            __|__               
%  	                 \ R/(1-a)    _____ (1-b)C      
%  		             /              |              			                                               
%  		            _|_            _|_             			                                   
%  		             -              -             			                                   
%  			                                                               
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     krctod(fp,Q,C,R0)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1. �����

function y=krctod(fp,Q,C,R0)

% Se adecuan los datos:

fp=fp*1000;
C=C*1e-9;
C=cnor(C);

% Se calculan c, a y b
c=1; % Se fija el valor de c como el m�ximo posible

a=(3*Q+1)/(3*Q-1)*(2*Q-1)/(2*Q+1);
b=a;
Ho=(2*Q-1)/(2*Q+1);
HodB=20*log10(Ho);
K=3-1/Q;


% Se calcula R
R=1/(2*pi*fp*C);
% Se calcula R/a
Rsa=R/a;
Rsa=rnor(Rsa,1);
% Se calcula R(1-a)
Rs1ma=R/(1-a);
Rs1ma=rnor(Rs1ma,1);
% Se calcula R0/c
R0=R0*1e3;
R0sc=R0/c;
R0sc=rnor(R0sc,1);
% Se calcula R0(K-1)
R0Km1=R0*(K-1);
R0Km1=rnor(R0Km1,1);

% Se calcular bC
bC=b*C;
bC=cnor(bC);
% Se calcula (1-b)C;
mbC=(1-b)*C;
mbC=cnor(mbC);
% Se normaliza R
R=rnor(R,1);


% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa KRC Pasatodo'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   R/a'),exi(Rsa),fprintf('ohm')
fprintf('   R/(1-a)'),exi(Rs1ma),fprintf('ohm'),fprintf('\n')
fprintf('   R0/c'),exi(R0sc),fprintf('ohm'),
fprintf('   R0(K-1)'),exi(R0Km1),fprintf('ohm'),
fprintf('  ** Ho'),exi(HodB),fprintf('dB **'),fprintf('\n')
fprintf('   C'),exi(C),fprintf('F'),  
fprintf('  bC'),exi(bC),fprintf('F'),        
fprintf('  (1-b)C'),exi(mbC),fprintf('F'),fprintf('\n'),fprintf('\n')





