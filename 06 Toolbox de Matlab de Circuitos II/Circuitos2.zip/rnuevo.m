% RNUEVO es una funcion que proporciona el valor de
%  la RESISTENCIA R de un filtro CRD que reemplaza a la
%     INDUCTANCIA L del PASABAJOS NORMALIZADO
% cuando se le ingresa en este orden:          (Ojo con las Unidades)
%                       1) El valor de L en H
%                       2) La frecuencia fc en KHz
%                       3) El factor de escala de impedancias Kz
%  
%  Ejemplo
%  1)  Datos L=1.36578H  f=15000 Hz  Kz=1e9
%  2)  Se introduce: rnuevo(1.36578,15,1e9)
%  3)  Se obtiene:        
%   Rnuevo (que reemplaza a L) del filtro CRD pasabajos = 14.3 KOhms      
%
%  Ver tambien BICUA, COMPODE, COMPODEA, KRCKI, KRCIK2, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKALTO, VAEI y VAENOI 
%
%  Introducir     rnuevo(L,f,Kz)       

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function y=rnuevo(L,f,Kz)


f=f*1e3;

R=Kz*L/(2*pi*f);

% Valor normalizado m�s cercano

Rn=lnor(R);

% Presentacion de los resultados
fprintf('\n')

fprintf(' Rnuevo (que reemplaza a L) del filtro CRD pasabajos'),exi(Rn),fprintf('Ohms'),fprintf('\n')


 


