%	BUTPBAJO es un programa que suministra los componentes L y C de 
%                    Filtros BUTTERWORTH PASIVOS PASABAJOS 
% 	ingresando: 
%       1) El orden del filtro
%       2) La frecuencia de corte de 3dB 
%       3) Las resistencias del generador y la carga

%       Utiliza las f�rmulas recursivas obtenidas mediante el m�todo de
%       Darlington y la s�ntesis de impedancias por Cauer

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   15 de Junio de 2002. Version 1.1


fprintf('----------    S�NTESIS DE FILTROS BUTTERWORTH PASIVOS PASABAJOS    ----------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')


% Introducci�n de los datos

fp=input('Ingresar la frecuencia de corte de 3 dB en kHz:   ');
N=input('Ingresar el orden del filtro Butterworth:   ');
R1=input('Ingresar la resistencia R1 del generador en ohm:   ');
R2=input('Ingresar la resistencia R2 de carga en ohm:   ');
fprintf(' \n\n')
fprintf('          * 2) Orden del filtro :'),exi(N),fprintf(' \n\n')

% Adecuaci�n de los datos
Wc=2*pi*fp*1000;       



if R2>R1
% Proporciona L y  C de un Filtro Butterworth
% si se le introduce R1, R2, Wc, y N, empezando por un inductor

RR=R2/R1;
Alfa=((RR-1)/(RR+1))^(1/N);
gama = pi / (2 * N);

L = zeros (1,N);
vector1 = zeros (1,N);

num = 2 * R1 * sin(gama);
div = (1 - Alfa)*Wc;
L(1)= num / div;

C = zeros(1,N);
vector2 = zeros(1,N);

top = 0;
i = 1;
while (i < N),
  top = top + 1;
  i = i + 2;
end

invWc2 = 1 / (Wc * Wc);
alfa2 = Alfa * Alfa;

for m=1:top,
  g1 = gama * (4 * m - 3);
  g2 = gama * (4 * m - 1);
  num = invWc2 * 4 * sin(g1) * sin(g2);

  g3 = gama * (4 * m - 2);
  div = 1 - (2 * Alfa * cos(g3)) + alfa2;
  vector1(m)= num / div;
  C(2*m) = vector1(m) / L(2*m - 1);

  g4 = gama * (4 * m - 1);
  g5 = gama * (4 * m + 1);
  num = invWc2 * 4 * sin(g4) * sin(g5);

  g6 = gama * 4 * m;
  div = 1 - (2 * Alfa * cos(g6)) + alfa2;
  vector2(m) = num / div;
  L(2*m+1) = vector2(m) / C(2*m);
end;


% Presentaci�n de los componentes en pantalla caso R2 mayor que R1

fprintf('\n')
fprintf('          * 3) Componentes L y C del filtro   '),fprintf('\n\n')
fprintf(' Se indican valores normalizados entre parentesis.'),fprintf('\n')
fprintf(' Capacitores al 5 por ciento, inductores al 1 por ciento.'),fprintf('\n\n')

fprintf(' El filtro comienza con una L en serie con R1'),fprintf('\n')


fprintf(' Inductores entre capacitores:')
fprintf(' \n\n')

L=elicn(L);
for i=1:length(L)
    fprintf('    L'),exi(L(i)),fprintf('H'),fprintf('   (Ln'),exi(lnor(L(i))),fprintf('H)'),fprintf(' \n\n')
end


fprintf(' \n\n')
fprintf(' Capacitores a masa:')
fprintf(' \n\n')
C=elicn(C);

for i=1:length(C)
    fprintf('   C'),exi(C(i)),fprintf('F'),fprintf('   (Cn'),exi(cnor(C(i))),fprintf('F)'),fprintf(' \n\n')
end

fprintf(' \n\n')



else
% Proporciona L y  C de un Filtro Butterworth
% si se le introduce R1, R2, Wc, y N, empezando por un capacitor


RR=R2/R1;
Alfa=((1-RR)/(RR+1))^(1/N);
gama = pi / (2 * N);

C = zeros (1,N);
vector1 = zeros (1,N);

num = 2 * sin(gama);
div = (1 - Alfa)*Wc*R1;
C(1)= num / div;

L = zeros(1,N);
vector2 = zeros(1,N);

top = 0;
i = 1;
while (i < N),
  top = top + 1;
  i = i + 2;
end

invWc2 = 1 / (Wc * Wc);
alfa2 = Alfa * Alfa;

for m=1:top,
  g1 = gama * (4 * m - 3);
  g2 = gama * (4 * m - 1);
  num = invWc2 * 4 * sin(g1) * sin(g2);

  g3 = gama * (4 * m - 2);
  div = 1 - (2 * Alfa * cos(g3)) + alfa2;
  vector1(m)= num / div;
  L(2*m) = vector1(m) / C(2*m - 1);

  g4 = gama * (4 * m - 1);
  g5 = gama * (4 * m + 1);
  num = invWc2 * 4 * sin(g4) * sin(g5);

  g6 = gama * 4 * m;
  div = 1 - (2 * Alfa * cos(g6)) + alfa2;
  vector2(m) = num / div;
  C(2*m+1) = vector2(m) / L(2*m);
end;



% Presentaci�n de los componentes en pantalla caso R2 menor que R1

fprintf('\n')
fprintf('          * 3) Componentes L y C del filtro   '),fprintf('\n\n')
fprintf(' Se indican valores normalizados entre parentesis.'),fprintf('\n')
fprintf(' Capacitores al 5 por ciento, inductores al 1 por ciento.'),fprintf('\n\n')

fprintf(' El filtro comienza con un capacitor a masa en el nodo de uni�n con R1'),fprintf('\n')
fprintf(' \n\n')
fprintf(' Capacitores a masa:')
fprintf(' \n\n')
C=elicn(C);

for i=1:length(C)
    fprintf('   C'),exi(C(i)),fprintf('F'),fprintf('   (Cn'),exi(cnor(C(i))),fprintf('F)'),fprintf(' \n\n')
end

fprintf(' Inductores entre capacitores:')
fprintf(' \n\n')

L=elicn(L);
for i=1:length(L)
    fprintf('    L'),exi(L(i)),fprintf('H'),fprintf('   (Ln'),exi(lnor(L(i))),fprintf('H)'),fprintf(' \n\n')
end


fprintf(' \n\n')




end 


fprintf('----------    Fin del c�lculo de L y C del Filtro Butterworth Pasivo Pasabajos    ----------'),fprintf('\n')
