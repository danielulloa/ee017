% DBP proporciona el valor en dB de una relaci�n
% de potencias. (La verdadera definici�n del decibel) 
% 
% Ejemplo: dbp(1/2)
%                  = -3.0103 dB
%
% Introducir dbp(x)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0

function y=dbp(x);
if x==0
    fprintf(' La definici�n de decibel es: dB(x)=10*log10(abs(x))'),fprintf('\n')
    fprintf('��A qui�n se le ocurre tomar el logar�tmo de cero?!')
    fprintf('\n')
    fprintf('\r')
break
end
if x~=1
a=10*log10(abs(x));
	% Presentaci�n de los resultados
	fprintf('          '),exi(a),fprintf('dB')
	fprintf('\n')
	fprintf('\r')
else
    fprintf('           = 0 dB')
	fprintf('\n')
	fprintf('\r')
end

