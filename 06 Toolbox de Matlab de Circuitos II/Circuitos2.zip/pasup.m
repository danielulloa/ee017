% PASUP se utiliza para obtener los valores desnormalizados 
% o de trabajo de los componentes de los filtros SuprimeBanda
% a partir de los componentes de filtros prototipos pasabajos 
% que figuran en forma normalizada en las tablas con Wc = 1 rad/s
% cuando se le ingresa en este orden:          
%  1) Los valores del filtro prototipo de L y C 
%  2) El factor de escala de impedancias Kz
%  3) La frecuencia central f0 y el ancho B
%     de la banda de paso en kHz (ojo con las unidades) 
%
%  Ejemplo:
%  1)  Lp=1.03697 H   Cp=1.41958 F   Kz=50  f=230000 Hz y B=28 kHz
%  2)  Se introduce:  pasup(1.03697,1.41958,50,230,28)
%  3)  Se obtiene:        
%  Valores Prototipo                  Valores Suprimebanda: 
%    Lp = 1.03697            Le1 = 4.36776 �H    Ce1 = 0.109629 �F
%    Cp = 1.41958            Le2 = 0.200204 mH    Ce2 = 2.39173 nF
%
%  Ver tambi�n CNUEVO, LNUEVO, PAALT, PABAJ, PABAN, RNUEVO 
%
%				                                  Ce1        
%              Lp                           +-----| |-----+
%       o----//////----o     ====>          |             |	
%        				                o---*---//////----*--o
%                                                 Le1
%  				        	                           
%	           Cp			                   Le2      Ce2     
%       o-----| |-----o      ====>      o----//////----| |-----o
%					
%  Introducir  pasup(Lp,Cp,Kz,f0[kHz],B[kHz])   

% � Copyright 2009. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   20 de Noviembre de 2009. Version 1.2


function y=pasup(Lp,Cp,Kz,f0,B)  

Bn=B/f0;      % Ancho de Banda Normalizado

f0=f0*1000;   % Frecuencia central de pasabanda
  
Kf=2*pi*f0;   % Factor de normalizacion de frecuencias

a=Kz/Kf;
b=Kz*Kf;

%Circuito paralelo LC equivalente a Lp
Le1=a*(Bn*Lp);
Ce1=1/(b*Bn*Lp);
% Circuito serie LC equivalente a Cp
Le2=a/(Bn*Cp);
Ce2=Bn*Cp/b;

fprintf('\n')
fprintf(' Valores Prototipo                  Valores Suprimebanda: '),fprintf('\n')

if Lp~=0
fprintf('   Lp'),exi(Lp),fprintf('         '),fprintf('  Le1'),exi(Le1),fprintf('H'),fprintf('    Ce1'),exi(Ce1),fprintf('F'),fprintf('\n')
end
if Cp~=0
fprintf('   Cp'),exi(Cp),fprintf('         '),fprintf('  Le2'),exi(Le2),fprintf('H'),fprintf('    Ce2'),exi(Ce2),fprintf('F'),fprintf('\n')
end
fprintf('\r')
