% CAUER2 S�NTESIS DE UN CIRCUITO LC MEDIANTE LA 2� FORMA DE CAUER
% Este programa sintetiza una inmitancia (Impedancia o Admitancia)
% de tipo LC presentada en la forma de un cociente entre polinomios
% en la variable s mediante la forma de
% Cauer 2 (Extracci�n de polos en el origen)
%
% Produce como salida la impedancia y la admitancia sintetizadas 
% mediante una descripci�n de la interconexi�n de los componentes
% y sus valores
%
% Ejemplo 1: Si la inmitancia a sintetizar es
% F(s)= (s^4+10s^2+9) / (s^3+ 4s)
% En el indicador de Matlab se ingresa:
%� cauer2
%Ingresar el Numerador en el formato [n(n) n(n-1)...n(0)]
% � [1 0 10 0 9]
%Ingresar el Denominador en el formato [d(n) d(n-1)...d(0)]
%� [1 0 4 0]
% 
% *** Impedancia Z(s) sintetizada mediante Cauer 2 ***
% Los terminales de la impedancia son los nodos 1(com�n) y 2
% y los componentes se conectan de la siguiente manera:
% Entre el nodo = 2  y el nodo = 3 :  C = 0.444444 F
% Entre el nodo = 3  y el nodo = 1 :  L = 1.9375 H
% Entre el nodo = 3  y el nodo = 4 :  C = 62.435 mF
% Entre el nodo = 4  y el nodo = 1 :  L = 2.06667 H
%
% Para este ejemplo la impedancia Z(s) es:
%
%          2      C=0.44 F   3    C=62.435mF   4      
%          o--------| |------+-------| |-------+
%                            |                 |
%                            )                 )  
%                 L=1.9375H  )      L=2.0666H  )  
%                            )                 )
%         1                  |                 |
%          o-----------------+-----------------+                            
%                  
% *** Admitancia Y(s) sintetizada mediante Cauer 2 ***
% Los terminales de la admitancia son los nodos 1(com�n) y 2
% y los componentes se conectan de la siguiente manera:
% Entre el nodo = 2  y el nodo = 1 :  L = 0.444444 H
% Entre el nodo = 2  y el nodo = 3 :  C = 1.9375 F
% Entre el nodo = 3  y el nodo = 1 :  L = 62.435 mH
% Entre el nodo = 3  y el nodo = 1 :  C = 2.06667 F
%
% Ver tambi�n: CAUER1, FOSTER1 y FOSTER2

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio 2002. Version 1.0


% Se borran las variables
clear n1 n2 tipoc t m n
 
%Ingreso del numerador y denominador

fprintf('Ingresar el Numerador en el formato [n(n) n(n-1)...n(0)]'),fprintf('\n')
num=input(' � ');
fprintf('Ingresar el Denominador en el formato [d(n) d(n-1)...d(0)]'),fprintf('\n')
den=input(' � ');

% Se guardan para sintetizar la admitancia
num1=den;
den1=num;
 
    
   % Estas instrucciones dan vuelta el numerador y el denominador  
    
    num=fliplr(num);
    if num(1)==0
    b=num;
    b(end+1)=0;
    num=b(2:end);
 else
    num;
 end
 
        den=fliplr(den);

    if den(1)==0
    b=den;
    b(end+1)=0;
    den=b(2:end);
 else
    den;
    end
    clear n1 n2 tipoc t m n
    
    % Se determina el grado del numerador y denominador
    m=length(num)-1 ;  % grado del numerador

    n=length(den)-1 ;  % grado del denominador

circuito2=[];      % Se pone a cero la variable en la cual
                   % se introducen los componentes del circuito
   if m>n
      tipoc=-1;    % Variable tipo de componente tipoc: el Capacitor se indica con -1
      n1=2;       % El capacitor va en Serie entre los nodos 2 y 3
      n2=3;
   else
      t=n;
      n=m;
      m=t;
      t=num;
      num=den;
      den=t;
      tipoc=1;     % El Inductor se indica con  1
      n1=2;        % El Inductor va en paralelo entre el nodo 2 y el 1 
      n2=1;
   end
   while m>0
      [c,num]=deconv(num,den);
      t=n;
      n=m-2;  % reduzco el grado del numerador en dos y pasa a ser el grado del nuevo denominador
      m=t;    % el grado del nuevo numerador es el del denominador anterior
      
      
      % Con estas tres invierto el numerador y denominador para las divisiones sucesivas

      t=den;  
      den=num(3:length(num));   % El nuevo denominador se obtiene del resto
      num=t;                   % El nuevo numerador es el antiguo denominador
      
      % Agrego filas a la matriz circuito2 a medida que sintetizo los componentes
      circuito2=[circuito2;n1,n2,1/c(1),tipoc];  %. Esto es por el punto y coma ;
      
      tipoc=-tipoc;      % Indico que el pr�ximo componente
                         % es L si el anterior es C o viceversa
                               
  if n2==1           % Lo que sigue es para ajustar los nodos
         if m==1       
            n2=1;
         else
            n2=n1+1;
         end
      else
         n1=n2;
         n2=1;
      end
      
      
   end     % fin del while
     
%
% Visualizaci�n de la matriz que contiene el resultado de la s�ntesis 
% 
disp('  ')
%disp('Nodoinicial, Nodofinal, Valor(F o H), Tipo de Componente(1 -> L,-1 -> C)')

circuito2;

circuito=circuito2;

% Para indicar la inmitancia sintetizada
tama=size(circuito);
numerodefilas=tama(1,1);numerodecolumnas=tama(1,2);
nodoi=circuito(1:numerodefilas,1);
nodof=circuito(1:numerodefilas,2);
valores=circuito(1:numerodefilas,numerodecolumnas-1);
componentes=circuito(1:numerodefilas,numerodecolumnas);

fprintf(' *** Impedancia Z(s) sintetizada mediante Cauer 2 ***'),fprintf('\n')
fprintf(' Los terminales de la impedancia son los nodos 1(com�n) y 2'),fprintf('\n')
fprintf(' y los componentes se conectan de la siguiente manera:'),fprintf('\n')

for k=1:numerodefilas
    fprintf(' Entre el nodo'),exi(nodoi(k)),fprintf(' y el nodo'),exi(nodof(k))

   if componentes(k)==1
      fprintf(':  L'),exi(valores(k)),fprintf('H'),fprintf('\n')

   else
      fprintf(':  C'),exi(valores(k)),fprintf('F'),fprintf('\n')
   end
end

disp('  ')

%Para sintetizar la admitancia mediante Cauer 2
% Se borran las variables
clear n1 n2 pot t m n


num=num1;
den=den1;  
   % Estas instrucciones dan vuelta el numerador y el denominador  
    
    num=fliplr(num);
    if num(1)==0
    b=num;
    b(end+1)=0;
    num=b(2:end);
 else
    num;
 end
 
        den=fliplr(den);

    if den(1)==0
    b=den;
    b(end+1)=0;
    den=b(2:end);
 else
    den;
    end
  clear n1 n2 pot t m n
  
  % Se determina el grado del numerador y denominador
    m=length(num)-1;   % grado del numerador

    n=length(den)-1;   % grado del denominador

circuito2=[];         % Se pone a cero la variable en la cual
                   % se introducen los componentes del circuito
   if m>n
      pot=-1;      % El Capacitor se indica con -1
      n1=2;        % El capacitor va en en Serie entre los nodos 2 y 3
      n2=3;
   else
      t=n;
      n=m;
      m=t;
      t=num;
      num=den;
      den=t;
      pot=1;     % El Inductor se indica con  1
      n1=2;      % El Inductor va en paralelo entre el nodo 2 y el 1 
      n2=1;
   end
   while m>0
      [c,num]=deconv(num,den);
      t=n;
      n=m-2;
      m=t;
      t=den;
      den=num(3:length(num));
      num=t;
      circuito2=[circuito2;n1,n2,1/c(1),pot];
           pot=-pot;
      if n2==1
         if m==1 
            n2=1;
         else
            n2=n1+1;
         end
      else
         n1=n2;
         n2=1;
      end
   end
     
%
% Visualizaci�n de la tabla que contiene el resultado de la s�ntesis 
% 
disp('  ')
%disp('Nodoinicial, Nodofinal, Valor(F o H), Tipo de Componente(1 -> L,-1 -> C)')

circuito2;

circuito=circuito2;

  % Para indicar la inmitancia sintetizada
tama=size(circuito);
numerodefilas=tama(1,1);numerodecolumnas=tama(1,2);
nodoi=circuito(1:numerodefilas,1);
nodof=circuito(1:numerodefilas,2);
valores=circuito(1:numerodefilas,numerodecolumnas-1);
componentes=circuito(1:numerodefilas,numerodecolumnas);

fprintf(' *** Admitancia Y(s) sintetizada mediante Cauer 2 ***'),fprintf('\n')
fprintf(' Los terminales de la admitancia son los nodos 1(com�n) y 2'),fprintf('\n')
fprintf(' y los componentes se conectan de la siguiente manera:'),fprintf('\n')

for k=1:numerodefilas
    fprintf(' Entre el nodo'),exi(nodoi(k)),fprintf(' y el nodo'),exi(nodof(k))

   if componentes(k)==1
      fprintf(':  L'),exi(valores(k)),fprintf('H'),fprintf('\n')

   else
      fprintf(':  C'),exi(valores(k)),fprintf('F'),fprintf('\n')
   end
end
fprintf('\r')

               