% RAIZRSPI  Selecciona las RAICES REALES de un polinomio 
% que estan situadas en el Semiplano Izquierdo

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   05 de Noviembre de 2000. Version 1.0


function [Y] = raizrspi(X);

L=length(X);
Y=[];
for i=1:L
  
 if (real(X(i))<0 & abs(imag(X(i)))<1e-12)
   
   Y=[Y X(i)];
    
 end
end
