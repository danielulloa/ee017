% Toolbox de Teor�a de Circuitos II
% ---------------------------------
% Conjunto de Funciones basadas en las Clases y 
% utilizadas en los Trabajos Pr�cticos de la Asignatura
% * Teor�a de Circuitos II * . Departamento de Electr�nica.
% Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
% Versi�n 1.1.1    8-Octubre-2002
%
% Funciones para an�lisis y demostraci�n
%   analh       - An�lisis de transferencias definidas en Simulink 
%   atenbut     - Funciones de Atenuaci�n de la aproximaxi�n Butterworth
%   compfiltros - Respuestas en frecuencia de 4 tipos de filtros
%   rescalon    - Grafico de la respuesta �2 orden al variar un par�metro
%   figretardo  - Respuesta de retardo de grupo de una bicu�dratica
%   ganbut      - Caracter�sticas de ganancia de filtros butterworth
%   ganche1     - Caracter�sticas de ganancia de filtros chebyshev I
%   ganche2     - Caracter�sticas de ganancia de filtros chebyshev II
%   ganeli      - Caracter�sticas de ganancia de filtros el�pticos
%   gpc         - Gr�fico de Polos y Ceros de una Funci�n de Transferencia
%   pjo2        - Transferencia, polos y grafico de pasabajo 2 orden normalizado             2) los polos del pasabajos y 
%   poloskrc    - Proporciona fp y Qp de un filtro KRC
%   retbessel   - Representa las funciones retardo de un filtro Bessel 
% 
% Funciones para el dise�o de Etapas de Filtros Activos
%   amalt       - Etapa Akerberg-Mossberg pasaaltos
%   amaltr      - Etapa Akerberg-Mossberg pasaaltos con ranura
%   ambaj       - Etapa Akerberg-Mossberg pasabajos
%   ambajr      - Etapa Akerberg-Mossberg pasabajos con ranura
%   amban       - Etapa Akerberg-Mossberg pasabanda
%   amsup       - Etapa Akerberg-Mossberg suprimebanda
%   amtod       - Etapa Akerberg-Mossberg pasatodo
%   cgialt      - Conversor Generalizado pasaaltos
%   cgialtr     - Conversor Generalizado pasaaltos con ranura
%   cgialtra    - Conversor Generalizado pasaaltos con ranura alternativo
%   cgibaj      - Conversor Generalizado pasabajos 
%   cgibajr     - Conversor Generalizado pasabajos con ranura 
%   cgibajra    - Conversor Generalizado pasabajos con ranura alternativo
%   cgiban      - Conversor Generalizado pasabanda
%   cgisup      - Conversor Generalizado suprimebanda
%   cgitod      - Conversor Generalizado pasatodo 
%   bicua       - Etapa bicuadr�tica ranura sim�trico,pasabajos o pasaaltos
%   compode     - Componente D con el conversor generalizado de impedancias
%   compodea    - Componente D configuraci�n alternativa
%   krcalt      - Etapa KRC General Pasaltos
%   krcaltr     - Etapa KRC General Pasaaltos con Ranura
%   krcbaj      - Etapa KRC General Pasabajos
%   krcbajr     - Etapa KRC General Pasabajos con Ranura
%   krcban      - Etapa KRC General Pasabanda
%   krcsup      - Etapa KRC General Suprimebanda
%   krctod      - Etapa KRC General Pasatodo
%   krci        - Etapa KRC con componentes iguales
%   krcg1       - Etapa KRC con capacitores iguales y ganancia = 1
%   krck1       - Etapa KRC con capacitores iguales, RA=RB y K=1
%   krck2       - Etapa KRC con capacitores iguales y RA=RB y K=2
%   lsimul      - Dise�o de una L con un Conversor Generalizado
%   pbda        - Filtro pasabanda de dos amplificadores
%   primork     - Filtro de 1� orden con ganancia K
%   pta1        - Etapa pasatodo activa bilineal de 1� orden
%   pta1r       - Etapa pasatodo activa bilineal de 1� orden
%   pta2        - PasaTodo Activa Bicuadr�tica de 2� orden
%   pta2r       - PasaTodo Activa Bicuadr�tica de 2� orden
%   randta      - Etapa ranura doble t activa
%   ransl       - Filtro ranura con simulaci�n de L 
%   rm          - Etapa pasabanda de realimentaci�n m�ltiple
%   sk          - Etapa Sallen Key pasabajos 
%   sk2         - Etapa Sallen Key pasabajos con resistencias iguales 
%   skpa        - Etapa Sallen Key pasabaalto
%   vaei        - Etapa de variables de estado inversor
%   vaenoi      - Etapa de variables de estado no inversor
%
% Funciones para el dise�o de Filtros Activos de 3� orden
%   rm3but      - Dise�o de Filtro de RM de 3�orden Butterworth Pasabajo
%   rm3buta     - Dise�o de Filtro de RM de 3�orden Butterworth PasaAlto
%   sk3but      - Dise�o de Filtro Sallen-Key 3�orden Butterworth Pasabajo
%   sk3buta     - Dise�o de Filtro Sallen-Key 3�orden Butterworth PasaAlto
%
% Programas para el dise�o de Filtros Activos
%   besabajo    - Filtros Bessel activos pasabajos ingresando el orden
%   butabajo    - Filtros Butterworth activos pasabajos ingresando el orden
%   butaban     - Filtros Butterworth activos pasabanda
%   butabano    - Filtros Butterworth activos pasabanda ingresando el orden
%   che2abajo   - Filtros Chebyshev II activos pasabajos ingresando el orden
%   cheaalt     - Filtros Chebyshev activos pasaltos
%   cheaalto    - Filtros Chebyshev activos pasaltos ingresando el orden
%   cheabaj     - Filtros Chebyshev activos pasabajos
%   cheabajo    - Filtros Chebyshev activos pasabajos ingresando el orden  
%   cheabano    - Filtros Chebyshev activos pasabanda ingresando el orden
%   eliabaj     - Filtros el�pticos activos pasabajos 
%   elieabajo   - Filtros el�pticos activos pasabajos ingresando el orden
%   eliaban     - Filtros el�pticos activos pasabanda
%
% Funciones para el dise�o de etapas pasivas
%   primor      - Dise�o de etapa pasabajos de 1� orden
%   ptp1        - Etapa Pasatodo de 1�orden con transformador y capacitores
%   ptp2        - Etapa PasaTodo de 2�orden con transformador y capacitores
%   randtp      - Dise�o de una etapa de 2� orden ranura pasiva
%
% Programas para el dise�o de Filtros Pasivos 
%   butpbaj     - Filtros Butterworth pasivos pasabajos
%   butpbajp    - Filtros Butterworth pasivos pasabajos prototipo
%   butpbajo    - Filtros Butterworth pasivos pasabajos ingresando el orden
%   chepalt     - Filtros Chebyshev pasivos pasaaltos
%   chepalto    - Filtros Chebyshev pasivos pasaaltos ingresando el orden
%   chepbaj     - Filtros Chebyshev pasivos pasabajos 
%   chepbajo    - Filtros Chebyshev pasivos pasabajos ingresando el orden
%   chepban     - Filtros Chebyshev pasivos pasabanda
%   chepsup     - Filtros Chebyshev pasivos suprimebanda
%   elipbajp    - Filtros El�pticos Pasivos pasabajos Prototipo
%
% Funciones para Transformaci�n de Componentes
%   paalt	    - Componentes del filtro pasaltos a partir del prototipo
%   pabaj	    - Componentes del filtro pasabajos a partir del prototipo
%   paban	    - Componentes del filtro pasabanda a partir del prototipo
%   pasup	    - Componentes del filtro suprimebanda a partir del prototipo
%
% Funciones para la s�ntesis de Inmitancias LC en las formas can�nicas 
%   cauer1      - Sintetiza una inmitancia LC en la forma de Cauer 1
%   cauer2      - Sintetiza una inmitancia LC en la forma de Cauer 2
%   foster1     - Sintetiza una impedancia LC en la forma de Foster 1 
%   foster2     - Sintetiza una admitancia LC en la forma de Foster 2
%
% Utilidades
%   bessel      - Proporciona los valores de wp y Q de filtros Bessel
%   db          - Da el valor en dB de una relaci�n de tensiones o corrientes
%   dbf         - Da el valor en dB de una relaci�n con salida formateada
%   dbp         - Da el valor en dB de una relaci�n de potencia
%   destem      - Calcula los par�metros descriptores temporales
%   dnuevo      - Da el componente D que reemplaza al capacitor C en filtro CRD
%   lnuevo      - Da L de un pasaaltos que se obtiene de C del pasabajos normalizado
%   rnuevo      - Da R de un filtro CRD que reemplaza a L del pasabajos normalizado
%   teapic      - Realiza la conversi�n de T a PI para capacitores
%   teapir      - Realiza la conversi�n de T a PI para resistencias
%   teapiz      - Realiza la conversi�n de T a PI para impedancias
%   tlaba       - Realiza la conversi�n de una red T de L a bobinas acopladas
%   wyq         - Proporciona wp y Q de un polinomio de 2� orden
%
% Funciones de transferencia de Ejemplo definidas en Simulink
%   h1.mdl      - Funci�n de transferencia de 1� orden
%   h2.mdl      - Funci�n de transferencia de 2� orden
%   h3.mdl      - Funci�n de transferencia de 3� orden
%   h5cheb.mdl  - Funci�n de transferencia de 5� orden Chebyshev
%   hpt1.mdl    - Funci�n de transferencia de 1� orden pasatodo
%   hpt2.mdl    - Funci�n de transferencia de 2� orden pasatodo
%   hpt5.mdl    - Funci�n de transferencia de 5� orden Pasatodo
%   modeloh     - Modelo para definir las funciones de transferencia
%   modelo2abcd - Modelo para definir sistema de 2�orden con variables de estado
%   rlc1.mdl    - Circuito RLC de 2� orden excitado con un escal�n (modelo de la ecuaci�n diferencial)
%   rlc2.mdl    - Circuito RLC de 2� orden excitado con un escal�n (modelo forma normalizada 2� orden)
%   rlc3.mdl    - Circuito RLC de 2� orden para utilizar con analh

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB.
%   15 de Julio de 2002. Versi�n 1.1

% Para instalar el Toolbox leer las instrucciones en el archivo 0_leerme.txt

