%	CHEABANO  Es un programa para el proyecto de
%                FILTROS CHEBYSHEV ACTIVOS PASABANDA 
% 	ingresando: 
%       1) La frecuencia central de la banda de paso
%       2) El ancho de Banda de 3 dB relativo (f2-f1)/fo
% 	3) El orden del filtro pasabajos equivalente          

%       Esta es una  version  que transforma directamte
%       los polos del filtro pasabajos
%       en los polos del filtro pasabanda

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


% 1.- Introduccion de los datos y conversion de los mismos a datos para el pasabajos equivalente

fprintf('-------   Proyecto de FILTROS CHEBYSHEV ACTIVOS PASABANDA     -------------------------------------------------------'),fprintf('\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')

% Puesta a cero de los vectores
Qpolo1=[];
Wpolo1=[];
Qpolo2=[];
Wpolo2=[];
pb1=[];
pb2=[];

% Ingreso de los valores de frecuencia y de atenuacion

n=input('Ingresar el orden del filtro pasabajos equivalente:   ');
f0=input('Ingresar la frecuencia central de la banda de paso fo en KHz:   ');
B=input('Ingresar el ancho de banda de 3 dB relativo  (f2-f1)/fo en % :   ');
Amax=input('Ingresar la atenuacion maxima en la banda de paso Amax en dB :   ');
f0=f0*1000;
B=B/100;
w0=1;
fprintf('\n\n')

% Calculo de los polos del filtro de Chebyshev pasabajos equivalente

j = sqrt(-1);
epsilon = sqrt(10^(.1*Amax)-1);
mu = asinh(1/epsilon)/n;
p = exp(j*(pi*(1:2:2*n-1)/(2*n) + pi/2));
p = sinh(mu)*real(p) + j*cosh(mu)*imag(p);
z = []; 
k = real(prod(-p));

p=cplxpair(p);


% Transformaci�n de los polos del filtro pasabajos a pasabanda

for h=1:length(p)
pb1(h)=(p(h)*B+sqrt((p(h)*B)^2-4*w0^2))/2;
pb2(h)=(p(h)*B-sqrt((p(h)*B)^2-4*w0^2))/2;
end

% De los polos agrupados en funciones de 2 orden,
% se obtiene el Qp y las fp y con ellos se calculan los
% coeficientes del los factores bicuadraticos

  for i=1:2:length(p)
    Wpolo1(i)=abs(pb1(i));
    Qpolo1(i)=Wpolo1(i)/2/abs(real(pb1(i)));
  end
  for i=1:2:length(p)
    Wpolo2(i)=abs(pb2(i));
    Qpolo2(i)=Wpolo2(i)/2/abs(real(pb2(i)));

 end

 
Wpolo1=elicero(Wpolo1)*f0;
Qpolo1=elicero(Qpolo1);
Wpolo2=elicero(Wpolo2)*f0;
Qpolo2=elicero(Qpolo2);

fprintf('\n')
fprintf('---------------  Frecuencias y Q de los polos  ---------------------------------------'),fprintf('\n')
fprintf('\n')

for i=1:length(Wpolo1)

fprintf('fp'),exi(Wpolo1(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo1(i))
fprintf(' \n\n')

end

for i=1:length(Wpolo2)-1

fprintf('fp'),exi(Wpolo2(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo2(i))
fprintf(' \n\n')

end

fprintf('-------    Fin del c�lculo de fp y Q de Filtros Chebyshev Pasabanda    -------------------------------------------------------'),fprintf('\n')

