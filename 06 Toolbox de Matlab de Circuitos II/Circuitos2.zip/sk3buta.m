% SK3BUTA es una funci�n que proporciona los 
% valores de los Resistores R1,R2, R3 de un FILTRO
% ***  Sallen-Key 3�orden Butterworth PasaAlto ***
% cuando se le ingresa en este orden:          (Ojo con las unidades)
%                      1) La frecuencia del corte fc en kHz
%                      3) Un valor de la capacidad C en nF
%
%
%				                      R3     
%                             +-----/\/\/\---*---------------+
%                             |              |               |
%                             |              |               |
%                             |              |	             |
%                             |              |      |`.      |
%                             |              +------|- `.    |      
%        | | C       C | |    |     | | C           |    >---*---o V2
% V1 o---| |-----*-----| |----*-----| |------*------|+ ,'  
%        | |     |     | |          | |      |      |,'     
%                \                           \      
%                /                           /   
%                \ R1                 	     \ R2
%                /                 	         /   
%               _|_                	        _|_  
%                -                   	     -   
% Por ejemplo:   sk3buta(4,2.2) proporciona:
%
%  Filtro Sallen-Key 3�orden Butterworth PasaAlto
%  R1 = 13 kohm  R2 = 88.7 kohm  R3 = 5.11 kohm
%  Se adopt�: C = 2.2 nF
%
%  Ver tambi�n: BICUA, KRCI, KRCK2, PBDA, PTA1, PTA2, PTP1, PTP2,
%               POLOSKRC, PRIMOR, PRIMORK, RANDTA, RANDTP, RANSL,
%               RM, SK, SK3BUT, SKPA, VAEI y VAENOI 
%
%  Introducir     sk3buta(fc,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1

function y=sk3buta(fc,C)

% Adecuaci�n de los datos
fc=fc*1000;
C=C*1e-9;
% Se elige una capacidad normalizada
% si en la entrada no se lo ha hecho
Cn=cnor(C);
C2=Cn/2;
C2n=cnor(C2);

den=(2*pi*fc*Cn);

% C�lculo del resistor R1
	R1=0.718057/den;
	R1n=rnor(R1,1);
% C�lculo del resistor R2
	R2=4.93947/den;
	R2n=rnor(R2,1);
% C�lculo del resistor R3
	R3=0.281943/den;
	R3n=rnor(R3,1);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('  Filtro Sallen-Key 3�orden Butterworth PasaAlto'),fprintf('\n')
fprintf('  R1'),exi(R1n),fprintf('ohm')
fprintf('  R2'),exi(R2n),fprintf('ohm')
fprintf('  R3'),exi(R3n),fprintf('ohm'),fprintf('\n')
fprintf('  Se adopt�: C'),exi(Cn),fprintf('F')
fprintf('\n')
fprintf('\r')



