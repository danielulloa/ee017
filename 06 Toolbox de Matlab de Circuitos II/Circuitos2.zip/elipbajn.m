%	ELIPBAJN es un programa que permite obtener
%       por Sintesis los componentes L Y C de
%       de FILTRO PROTOTIPO ELIPTICOS PASIVOS PASABAJOS 
%           CON RAMAS RESONANTES LC SERIE A MASA
% 	ingresando: 
%       1) La atenuacion m�xima en la  banda de paso (el ripple) en dB
% 	2) La atenuancion m�nima en la banda de atenuacion en dB
%       3) El orden n del filtro

%       Sirve para mostrar la obtenci�n de los componentes de un filtro
%       el�ptico por el m�todo de Darlington y la S�ntesis de Inmitancias
%       para la formaci�n de ceros.
%
%       Atenci�n, Version con inconvenientes: hay que mejorar la elecci�n de polos y ceros de ro

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. �Version en prueba. No definitiva.!

fprintf('*********    Proyecto de Filtros PROTOTIPOS Elipticos Pasivos Pasabajos    *********'),fprintf('\n')

% Ingresos de los datos de frecuencia y atenuacion

Amax=input('Ingresar la Atenuacion maxima en la banda de paso Amax en dB :  ');
Amin=input('Ingresar la Atenuacion minima en la banda de atenuacion Amin en dB:  ');
n=input('Ingresar el orden del filtro:   ');

% Introducci�n de las resistencias del generador y de carga

R1=1;
R2=1;

fprintf('      Calculando .... '),fprintf('\n\n') 

% Calculo de los polos del filtro eliptico

[z,p,k]=ellipap(n,Amax,Amin);

% Datos del filtro prototipo
f0=1;
w0=1;
R0=1;

Kn=k;

NH=poly(z);
DH=poly(p);
NH=real(NH); % Polinomio de numerador
DH=real(DH); % Polinomio del denominador de la funcion de transferencia

K0=R2/(R1+R2);

K=4*(R1/R2)*(K0*Kn)^2;

NHneg=negativo(NH);
DHneg=negativo(DH);

Numc=K*conv(NH,NHneg);
Denc=conv(DH,DHneg);

Numroc=restapol(Denc,Numc);

%Numroc=real(Numroc); 
%Numroc=cero(Numroc);

Raicesroc=roots(Numroc);
Rroc=cplxpair(Raicesroc);
raic=raizcomp(Rroc);
polin=[];
% Formacion del polinomio numerador de ro por eleccion de la raices en el semiplano
% negativo
if rem(n,2)~=0  % si el orden es impar

for i=1:length(raic)/2
  polin(i)=raic(i);
end

polino=poly(polin);
polc=real(polino);
rreal=raizrspi(Raicesroc);
polr=poly(rreal);
Numro=conv(polc,polr);

else
% Hay que arreglar aca
for i=1:length(raic)/2
  polin(i)=raic(i);
end

polino=poly(polin);
polc=real(polino);

Numro=polc;

end



% Numerador y denominador del Coeficiente de reflexion ro
Numro=real(Numro);
Denro=DH;

% Partes pares e impares del numerador y denominador de ro
Np=parpol(Numro);
Ni=impar(Numro);

Dp=parpol(Denro);
Di=impar(Denro);

% Numerador y denominador de la Impedancia Z11 a sintetizar

nz=restapol(Dp,Np);
nz=nocero(nz);
dz=sumapol(Di,Ni);

%nz=restapol(Di,Ni);
%nz=nocero(nz);
%dz=sumapol(Dp,Np);


ctedenz=dz(1)/nz(1);

if ctedenz < 0
fprintf(' Para las especificaciones ingresadas no se puede sintetizar la Impedancia  '),fprintf('\n') 
end
if ctedenz < 0,break
end

%nz=nz/nz(1);   % Coeficientes de la potencia
%dz=dz/dz(1);   % mas alta igual a 1
%dz=dz*ctedenz; 

roots(nz);
roots(dz);


% Se desarrolla la impedancia por extracci�n de ceros



z=abs(z);  % Ceros de la funcion de transferencia

if length(z)~=2
z=zetaco(z); % Acomoda el orden de los ceros en la forma 1 3 4 5.. n 2
end

j=sqrt(-1);

for m=1:2:length(z)

CeroT=z(m)*j;

     
% Calculo del residuo para Remocion parcial de polo 

ny=dz;
dy=nz;

C1=resipar(ny,dy,CeroT);   % Residuo de remocion parcial del polo

if m==1 & C1> 1.4
fprintf(' Para las especificaciones ingresadas no se puede sintetizar el filtro  '),fprintf('\n') 
fprintf(' Variar ligeramente la Amin e intentar de nuevo' ),fprintf('\n') 
end

if m==1 & C1> 1.4
break
end
if m==1
fprintf('  El filtro comienza con una L en serie con R1'),fprintf('\n\n') 
end

Lnodos=C1*R0/w0;
fprintf('  L entre nodos'),exi(Lnodos),fprintf('H'),fprintf('\n\n') 

% Calculo de la admitancia resultante despues de la remocion parcial

[ny2,dy2]=reuncomp(ny,dy,C1);
ny2;
dy2;

% Calculo del residuo para remocion completa del polo
fprintf('  Cero en'),exi(abs(CeroT)*f0),fprintf('Hz'),fprintf('\n\n') 
[residuo,Lpara,Cpara]=resitot(dy2,ny2,CeroT);
k2=residuo;

Lpara;
Cserie=Lpara/R0/w0;

Cpara;
Lserie=Cpara*R0/w0;

fprintf('  L en serie '),exi(Lserie),fprintf('H'),fprintf('\n') 
fprintf('  C en serie'),exi(Cserie),fprintf('F'),fprintf('\n\n') 

% Calculo de la impedancia resultante despues de la remoci�n total del polo
% Zresultante=Z - ZLC

nz2=dy2;
dz2=ny2;
[nz3,dz3]=restaimp(nz2,dz2,k2,CeroT);
nz=nz3;
dz=dz3;

end

Culti=dz(1)/nz(1);

Lulti=Culti*R0/w0;
fprintf('  Ultimo L entre nodos'),exi(Lulti),fprintf('H'),fprintf('\n\n') 

if Lulti> 2
fprintf(' !!! ATENCION: Por redondeos numericos el Filtro fue MAL sintetizado  '),fprintf('\n') 
fprintf(' Variar ligeramente la Amax o la Amin e intentar de nuevo' ),fprintf('\n') 
end