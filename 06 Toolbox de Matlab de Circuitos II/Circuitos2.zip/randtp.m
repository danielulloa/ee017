% RANDTP es una funcion que proporciona los valores de:
% las resistencias  R, R/2 y los capacitores C y 2C 
% de un filtro  RANURA DOBLE T PASIVA
% cuando se le ingresa en este orden:              (Ojo con las Unidades)
%                       1) La frecuencia de ranura en KHz
%                       2) Un valor de la Capacidad C en nF
%  
%  Ejemplo
%  1)  Datos fp= 50 Hz, C=100 nF 
%  2)  Se introduce: randtp(.05,100)
%  3)  Se obtiene:        
%                  Filtro  Ranura Doble T Pasivo:
%  R = 31.6 KOhms  R/2 = 15.8 KOhms  C = 100 nF  2C = 0.2 uF
%
%  Ver tambien BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,
%              PRIMORK, RANDTA, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     randtp(fp,C)       

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function y=randtp(fp,C)

fp=fp*1000;
C=C*1e-9;


R=1/(2*pi*fp*C);
Rd2=R/2;

% Valor normalizado m�s cercano

Rn=rnor(R,1);
Rd2n=rnor(Rd2,1);

Cn=cnor(C);
Cp2=2*Cn;
Cp2n=cnor(Cp2);

% Presentacion de los resultados
fprintf('\n')

fprintf('             Filtro  Ranura Doble T Pasivo:'),fprintf('\n')
fprintf('  R'),exi(Rn),fprintf('Ohms')         
fprintf('  R/2'),exi(Rd2n),fprintf('Ohms')
fprintf('  C'),exi(Cn),fprintf('F')         
fprintf('  2C'),exi(Cp2n),fprintf('F'),fprintf('\n')



 


