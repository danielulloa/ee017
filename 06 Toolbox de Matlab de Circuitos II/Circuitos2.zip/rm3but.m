% RM3BUT es una funci�n que proporciona los
% valores de los capacitores C1,C2 y C3 de un FILTRO 
% *** Realimentaci�n M�ltiple de 3�orden Butterworth Pasabajo  ***
% cuando se le ingresa en este orden:            Ojo con las unidades)
%                      1) La frecuencia del corte fc en kHz
%                      3) Un valor de la resistencia R en kohm
%
%                             +----------/\/\/\-------------+
%                             |            2R               |
%                             |                   | | C3    |
%                             |           +-------| |-------*
%                             |           |       | |       |
%                             |           |                 |
%           R            R    |     R     |         |`.     |
% V1 o---/\/\/\---*---/\/\/\--*--/\/\/\---*---------|- `.   |
%                 |                       |         |    >--*---o V2
%                 |                       |      +--|+ ,'    
%               __|__                   __|__    |  |,'      
%               _____  C1           C2  _____   _|_          
%                 |                       |      -
%                 |                       |     
%                _|_                     _|_      
%                 -                       -
%
% Por ejemplo:   rm3but(4,10.3) proporciona:
%
%    Filtro Realimentaci�n M�ltiple de 3�orden Butterworth Pasabajo
%    C1 = 10 nF  C2 = 8.2 nF  C3 = 0.75 nF
%    2R = 20.5 kohm. Se adopt�: R = 10.2 kohm
%
%  Ver tambi�n: BICUA, KRCI, KRCK2, PBDA, PTA1, PTA2, PTP1, PTP2,
%               POLOSKRC, PRIMOR, PRIMORK, RANDTA, RANDTP, RANSL,
%               RM, SK, SK3BUTA,SKPA, VAEI y VAENOI 
%
%  Introducir     rm3but(fc,R)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1

function y=rm3but(fc,R)

% Adecuaci�n de los datos
fc=fc*1000;
R=R*1000;
% Se elige una resistencia normalizada
% si en la entrada no se lo ha hecho
Rn=rnor(R,1);
R2=2*Rn;
R2n=rnor(R2,1);

den=(2*pi*fc*Rn);

% C�lculo del Capacitor C1
	C1=2.45495/den;
	C1n=cnor(C1);
% C�lculo del Capacitor C2
	C2=2.10914/den;
	C2n=cnor(C2);
% C�lculo del Capacitor C3
	C3=0.193131/den;
	C3n=cnor(C3);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('  Filtro Realimentaci�n M�ltiple de 3�orden Butterworth Pasabajo'),fprintf('\n')
fprintf('  C1'),exi(C1n),fprintf('F')
fprintf('  C2'),exi(C2n),fprintf('F')
fprintf('  C3'),exi(C3n),fprintf('F'),fprintf('\n')
fprintf('  2R'),exi(R2n),fprintf('ohm.')
fprintf(' Se adopt�: R'),exi(Rn),fprintf('ohm')
fprintf('\n')
fprintf('\r')



