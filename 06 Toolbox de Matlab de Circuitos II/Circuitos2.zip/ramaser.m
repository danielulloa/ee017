% RAMASER es una funcion que proporciona los valores
% de las resistencias del bloque RAMa SERie activa que 
% implementa la rama serie de una red escalera pasiva
         
% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


fprintf('-------   PROYECTO DE LA RAMA SERIE ACTIVA    ------------------------------------'),fprintf('\n')
fprintf('          DE UN FILTRO DE DIAGRAMA DE FLUJO           '),fprintf('\n')


np=input('--> * Ingresar el numero de la Rama Pasiva Serie:   ');

% Ingreso de componentes de la rama serie
Rs=0;Ls=0;Cs=0;Lp=0;Cp=0;
fprintf('\n'),fprintf(' --> * 1.- Ingresar los componentes de la Rama Pasiva Serie'),fprintf('\n')
Rs=input('Ingresar la resistencia Rs en Ohms:   ');
Ls=input('Ingresar el inductancia Ls en mH:   ');
Cs=input('Ingresar el capacitor Cs en nF:   ');
Lp=input('Ingresar la inductancia Lp en mH:   ');
Cp=input('Ingresar el capacitor Cp en nF:   ');
fprintf('\n')
if Rs==0 & Ls==0 & Cs==0 & Cp ==0 & Lp ==0 
fprintf('   No hay componentes a simular, tontuelo !.   '),fprintf('\n')
break
elseif Rs~=0 & Ls==0 & Cs==0 & Cp==0 & Lp==0
fprintf(' Una R se simula con una ....R, bobalicon !.   '),fprintf('\n')
break
end

Rs=Rs;
Ls=Ls*1e-3;
Cs=Cs*1e-9;
Cp=Cp*1e-9;
Lp=Lp*1e-3;

% Ingreso de las tensiones y corrientes en Ls y Lp
IkRe=0;VCs=0;ICsRe=0;VCp=0;ILpRe=0;
if Cs~=0 | (Lp & Cp)~=0
 fprintf('\n'),fprintf(' --> * 2.- Ingresar las tensiones MAXIMAS siguientes'),fprintf('\n')
 fprintf('            Todas en Volt o Todas en mVolt'),fprintf('\n')
 fprintf('\n');
 fprintf('   Ingresar la tension  V'),sub(np),fprintf('= I'),sub(np),fprintf(' x Re  sobre la rama '),sub(np),fprintf(' '),fprintf('\n')
 IkRe=input('   : ');
end

if Cs~=0
  fprintf('   Ingresar la tension VC'),sub(np),fprintf('sobre C'),sub(np),fprintf(' '),fprintf('\n')
  VCs=input('   : ');
end

if Lp~=0 & Cp~=0
 
  fprintf('   Ingresar la tension  VCp'),sub(np),fprintf('sobre Cp'),sub(np),fprintf(' '),fprintf('\n')
  VCp=input('   : ');

  fprintf('   Ingresar la tension  ILp'),sub(np),fprintf('x Re  '),fprintf('\n')
  ILpRe=input('   : ');

end

% Ingreso de los coeficientes de entrada
ce1=1;ce2=1;
fprintf('\n'),fprintf(' --> * 3.- Ingresar los coeficientes de entrada'),fprintf('\n')
ce1=input('Ingresar ce1:   ');
ce2=input('Ingresar ce2 :   ');

% Ingreso de los valores adoptados
as=['s'];
while as==['s']

fprintf('\n'),fprintf(' --> * 4.- Ingresar los valores adoptados'),fprintf('\n')
Ra=10;C=10;Re=100;
Ra=input('Ingresar la resistencia Ra en KOhm :   ');
C=input('Ingresar el capacitor C de los integradores en nF :   ');
Re=input('Ingresar la resistencia Re en Ohm :   ');
Ra=Ra*1000;
C=C*1e-9;
Re=Re;
fprintf('\n') 
% Presentacion de los resultados
if Rs ~=0  & Ls ~=0  & Cs ~=0  & Cp  ~=0  & Lp ~=0 
fprintf('   Componentes del Bloque que implementa (Rs + s Ls + 1/s Cs) + (s Lp || 1/s Cp) : '),fprintf('\n')
elseif Rs ~=0  & Ls ~=0  & Cs ~=0 & Cp==0 & Lp==0 
fprintf('   Componentes del Bloque que implementa Rs + s Ls + 1/s Cs : '),fprintf('\n')
elseif Rs ~=0  & Ls  ~=0  &  Cs==0 & Cp==0 & Lp ==0 
fprintf('   Componentes del Bloque que implementa Rs + sLs : '),fprintf('\n')
elseif (  Rs ~=0  & Cs ~=0   &  Ls==0 & Cp==0 & Lp==0   )
fprintf('   Componentes del Bloque que implementa Rs +1/s Cs : '),fprintf('\n')
elseif Ls ~=0  & Cs ~=0 & Rs==0 & Cp==0 & Lp ==0 
fprintf('   Componentes del Bloque que implementa sLs + 1/sCs  : '),fprintf('\n')
elseif Cp ~=0  & Lp ~=0  & (Rs==0 & Ls==0 & Cs==0)
fprintf('   Componentes del Bloque que implementa sLp + 1/sCp en rama serie: '),fprintf('\n')
elseif Rs~=0 & Cp ~=0 & Lp~=0 & Ls==0 & Cs ==0 
fprintf('   Componentes del Bloque que implementa Rs + (sLp || 1/sCp) : '),fprintf('\n')
elseif (Cs ~=0  & Rs==0 & Ls==0 & Cp ==0 & Lp ==0 )
fprintf('   Componentes del Bloque que implementa 1/s Cs : '),fprintf('\n')
elseif (Ls ~=0  & Rs==0 & Cs ==0 & Cp==0 & Lp ==0 )
fprintf('   Componentes del Bloque que implementa s Ls  : '),fprintf('\n')
elseif (Ls ==0  & Rs~=0 & Cs~= 0 & Cp~=0 & Lp~=0 )
fprintf('   Componentes del Bloque que implementa Rs + 1/s Cs + (sLp || 1/sCp)  : '),fprintf('\n')
elseif (Rs ==0  & Ls~=0 & Cs~= 0 & Cp~=0 & Lp~=0 )
fprintf('   Componentes del Bloque que implementa Ls + 1/s Cs + (sLp || 1/sCp)  : '),fprintf('\n')

end

% Adecuacion de los valores ingresados
C=cnor(C);
a=ce1;
b=1/ce2;

% Calculo, normalizaci�n y presentaci�n de los componentes

if Ls~=0
 RaRe=Ls/C;
 Ra=RaRe/Re;
else
RaRe=Ra*Re;
end

Re1=Ra/a ;    Re1n=lnor(Re1);
Re2=Ra/b;     Re2n=lnor(Re2);
fprintf('   Ra'),sub(np),exi(Re1n),fprintf('Ohm'),fprintf('\n')
fprintf('   Rb'),sub(np),exi(Re2n),fprintf('Ohm'),fprintf('\n')
fprintf('   C'),exi(C),fprintf('F'),fprintf('\n')

if Rs ~=0
 R1=(RaRe)/Rs;       R1n=lnor(R1);
 fprintf('   R1'),sub(np),exi(R1n),fprintf('Ohm'),fprintf('\n')
end


if Cs~=0
  m2=VCs/IkRe;
  Rc2a=Cs/C*Re;
  Rc2=Rc2a*m2; Rc2n=lnor(Rc2); 
  R2=(Cs/C*RaRe)/Rc2; R2n=lnor(R2);
  fprintf('   Rc2'),sub(np),exi(Rc2n),fprintf('Ohm'),fprintf('\n')
  fprintf('   R2'),sub(np),exi(R2n),fprintf('Ohm'),fprintf('\n')
end

if Cp~=0 & Lp~=0
 m3=VCp/IkRe;
 R3a=Cp/C*Re;
 Rc3=R3a*m3;          Rc3n=lnor(Rc3);
 R3=Ra/m3;            R3n=lnor(R3);
 fprintf('   Rc3'),sub(np),exi(Rc3n),fprintf('Ohm'),fprintf('\n')
 fprintf('   R3'),sub(np),exi(R3n),fprintf('Ohm'),fprintf('\n')


 m4=ILpRe/VCp;
 Rc4a=Lp/C/Re;
 Rc4=Rc4a*m4;      Rc4n=lnor(Rc4);
 R4=(Cp*Lp/C^2)/Rc4;       R4n=lnor(R4);
 fprintf('   R4'),sub(np),exi(R4n),fprintf('Ohm'),fprintf('\n')
 fprintf('   Rc4'),sub(np),exi(Rc4n),fprintf('Ohm'),fprintf('\n')

end


fprintf('  Las R de los inversores (si hubieran) se adoptan iguales '),fprintf('\n')

 as=input('--> * Desea recalcular los componentes? s/n :  ','s');
end

fprintf('\n'),fprintf('   Fin del calculo de la Rama Serie Activa '),sub(np),fprintf('\n')

fprintf('\n')