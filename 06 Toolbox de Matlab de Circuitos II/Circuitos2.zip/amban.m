% AMBAN es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% Akerberg-Mossberg pasaBanda de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia resonancia fr en kHz
%                      2) El Q de la etapa
%                      3) La ganancia de resonancia Hr en dB
%                      4) Un valor del capacitor C en nF 
%  Ejemplo:
%  1) Datos: Si fr= 1000 Hz, el Q= 10, 
%            la ganancia de resonancia es = 3 dB, 
%            y el C elegido es = 10nF 
%  
%  2) Se ingresa:   amban(1,10,3,10)
%
%  3) Se obtiene:
%                 Etapa AM PasaBanda
%                 R = 15.8 kohm   R/k = 113 kohm
%                 QR = 158 kohm   C = 10 nF
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
% 	           +------------------------/\/\/\------------------------------+    
% 	           | 		                   R             R                  |    
% 	           |     QR                            +---/\/\/\---+   	    |	
% 	           *---/\/\/\----+	                   |            |	        |	
% 	           |	         |	              C    |      .�|   |	   R    |
% 	           |     | | C   |	             | |   |    .� -|---*---/\/\/\--* 
% 	           *-----| |-----*           +---| |---*---<    |      	        |   
% 	           |     | |     |	         |   | |        `. +|---+	        |	
% 	           |	         |	         |                `.|   |   	    |	
% V1    R/k    |    |`.      |	         |                     _|_	        |	
%  o--/\/\/\---*----|- `.    |	   R     |   |`.                - 	        |    
%  	  	            |    >---*--/\/\/\---*---|+ `.     		        	    |  
%  	    	   +----|+ ,'    |	             |    >-------------------------+
% 	           |    |,'  	 |	          +--|- ,'        		             
% 	          _|_     		 o V2         |  |,'      		
% 	           -      		             _|_         		
% 	     			                      -  
%  Introducir     amban(fr,Q,Hr,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=amban(fr,Q,Hr,C)


% Se calculan b=k
Hr=10^(Hr/20);
k=Hr/Q;

% Se adecuan los datos:
fr=fr*1000;
C=C*1e-9;
C=cnor(C);

% Se calcula R
R=1/(2*pi*fr*C);

% Se calcula QR
QR=Q*R;
QR=rnor(QR,1);

% Se calcula R/k
Rsk=R/k;
Rsk=rnor(Rsk,1);

% Se normaliza R
R=rnor(R,1);

% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa AM PasaBanda'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   R/k'),exi(Rsk),fprintf('ohm'),fprintf('\n')
fprintf('   QR'),exi(QR),fprintf('ohm')
fprintf('   C'),exi(C),fprintf('F'),fprintf('\n\n')       




