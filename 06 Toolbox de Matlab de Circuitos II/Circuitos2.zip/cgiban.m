% CGIBAN es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% CGI pasaBANda de 2� orden 
% cuando se le ingresa:                         (Ojo con las unidades                         (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa
%                      3) El valor de la ganancia central Ho en dB
%                      4) Un valor del capacitor C en nF 
%   
%  Ejemplo:
%  1) Datos: Si la fp= 1000 Hz, el Q= 10, la ganancia central = 0 dB
%            y el capacitor elegido es = 20 nF
%
%  2) Se ingresa:   cgiban(1,10,0,20)
%
%  3) Se obtiene:
%       Etapa CGI Pasabanda
%       R = 7.87 kOhm  QR/b = 158 kOhm  QR/(1-b) = 158 kOhm
%       C = 20 nF
%                                                          |`.      	           
%       	              +--------------------------------|+ `.     	         
%       	              |                                |    >---*---o V2         
%                         |                            +---|- ,'    |            
%      	     	          |                            |   |,'      |            
%      		              |                  	C      | 	   	    |	         
% V1    	QR/b          |        R           | |     |     R      |      R     
%    o-----/\/\/\----*----*----/\/\/\----*-----| |-----*---/\/\/\---*---/\/\/\---*---+
%                    |    |              |     | |     |          	             |   |             
%  		             /	__|__            |      	   | 	 		             |   /
%  	        QR/(1-b) \  _____ C          |      .�|    |	                     |   \ R
%  		             /    |              |    .� -|----+                         |   /			                                               
%  		            _|_  _|_             +---<    |                              |   |			                                   
%  		             -    -                   `. +|------------------------------+  _|_			                                   
%  			                                    `.|                     			 -                         
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR, BGPJ,BGPA
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     cgiban(fp,Q,Ho,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=cgiban(fp,Q,Ho,C)

% Se adecuan los datos:

b=(10^(Ho/20))/2;

if b>1 
fprintf(' La ganancia central no puede ser mayor de 6 dB  '),fprintf('\n')
break
end

fp=fp*1000;
C=C*1e-9;
C=cnor(C);
% Se calcula R
R=1/(2*pi*fp*C);

% Se calcula QR/b
QRsb=Q*R/b;
QRsb=rnor(QRsb,1);
% Se calcula QR/(1-b)
QRs1mb=Q*R/(1-b);
QRs1mb=rnor(QRs1mb,1);

% Se normaliza R
R=rnor(R,1);



% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa CGI Pasabanda'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('  QR/b'),exi(QRsb),fprintf('ohm')
fprintf('  QR/(1-b)'),exi(QRs1mb),fprintf('ohm'),fprintf('\n')
fprintf('   C'),exi(C),fprintf('F'),fprintf('\n'),fprintf('\n')



