% AMALT es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% Akerberg-Mossberg pasaAltos de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa
%                      3) La ganancia de alta frecuencia Haf en dB
%                      4) Un valor del capacitor C en nF 
%  Ejemplo:
%  1) Datos: Si fp= 1000 Hz, el Q= 10, 
%            la ganancia de alta frecuencia = 3 dB, 
%            y el C elegido es = 10nF 
%  
%  2) Se ingresa:   amalt(1,10,3,10)
%
%  3) Se obtiene:
%                Etapa AM PasaAltos 
%                R = 15.8 kohm   QR = 158 kohm
%                C = 10 nF  aC = 15 nF
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
% 	           +------------------------/\/\/\------------------------------+    
% 	           | 		                   R             R                  |    
% 	           |     QR                            +---/\/\/\---+   	    |	
% 	           *---/\/\/\----+	                   |            |	        |	
% 	           |	         |	              C    |      .�|   |	   R    |
% 	           |     | | C   |	             | |   |    .� -|---*---/\/\/\--* 
% 	           *-----| |-----*           +---| |---*---<    |      	        |   
% 	           |     | |     |	         |   | |        `. +|---+	        |	
% 	    aC     |	         |	         |                `.|   |   	    |	
% V1    | |    |    |`.      |	         |                     _|_	        |	
%  o----| |----*----|- `.    |	   R     |   |`.                - 	        |    
%  	    | |         |    >---*--/\/\/\---*---|+ `.     		        	    |  
%  	     	   +----|+ ,'    |	             |    >-------------------------+
% 	           |    |,'  	 |	          +--|- ,'        		             
% 	          _|_     		 o V2         |  |,'      		
% 	           -      		             _|_         		
% 	                                      -  
%     
%
%  Introducir     amalt(fp,Q,Haf,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=amalt(fp,Q,Ha,C)


% Se calcula a
Ha=10^(Ha/20);
a=Ha;


% Se adecuan los datos:
fp=fp*1000;
C=C*1e-9;
C=cnor(C);

% Se calcula R
R=1/(2*pi*fp*C);

% Se calcula QR
QR=Q*R;
QR=rnor(QR,1);

% Se calcula aC
aC=a*C;
aC=cnor(aC);

% Se normaliza R
R=rnor(R,1);

% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa AM PasaAltos '),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   QR'),exi(QR),fprintf('ohm'),fprintf('\n')
fprintf('   C'),exi(C),fprintf('F'),  
fprintf('  aC'),exi(aC),fprintf('F'), fprintf('\n\n')       




