% KRCBAJ es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% KRC pasaBajos de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa
%                      3) El valor de la ganancia de continua Ho en dB
%                      4) Un valor del capacitor C en nF 
%                      5) Un valor de la resistencia R0 en kohm
%   
%  Ejemplo:
%  1) Datos: Si fp= 1 kHz, el Q= 5, 
%            la ganancia de continua = 0 dB, 
%            el C elegido es = 10 nF y R0=10kohm
%  
%  2) Se ingresa:   krcbaj(1,5,0,10,10)
%
%  3) Se obtiene:
%               Etapa KRC Pasabajos 
%               R = 15.8 kohm   R/a = 44.2 kohm   R/(1-a) = 24.9 kohm
%               R0 = 10 kohm   R0(K-1) = 18.2 kohm   C = 10 nF
%                                     | |
%                    +----------------| |-----------------------+
%                    |                | | C                     |
%                    |                                          |
%  V1        R/a     |       R                         |`.      |
%  o-------/\/\/\----*----/\/\/\----*------------------|+ `.    |
%                    |              |                  |    >---*---o V2
%      	             |              |              +---|- ,'    |            
%                    |              |              |   |,'      |           
%      	             |              |              |            |      
%      		         |              |              | 	   	    |	         
%       	         |              |              |   R0(K-1)  |         
%                    |              |              *---/\/\/\---+             
%  		             /            __|__            |   
%  	                 \ R/(1-a)    _____ C          \ 
%  		             /              |              / R0			                                               
%  		            _|_            _|_             \			                                   
%  		             -              -             _|_			                                   
%  			                                       -                         
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     krcbaj(fp,Q,Ho,C,R0)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=krcbaj(fp,Q,Ho,C,R0)

% Se adecuan los datos:

Ho=10^(Ho/20);
K=3-1/Q;
coefa=Ho/K;


% Se determina el valor de a
if coefa>1 
a=1; % Se fija el valor de a como el m�ximo posible
Ho=K;
HodB=20*log10(Ho);
else
a=coefa;
Ho=a*K;    
end

R0=R0*1e3;
fp=fp*1000;
C=C*1e-9;
C=cnor(C);

% Se calcula R
R=1/(2*pi*fp*C);
% Se calcula R/a
Rsa=R/a;
Rsa=rnor(Rsa,1);

if a~=1 
% Se calcula R(1-a)
Rs1ma=R/(1-a);
Rs1ma=rnor(Rs1ma,1);
end

% Se normaliza R 
R=rnor(R,1);

% Se calcula R0(K-1)
R0=rnor(R0,1);
R0Km1=R0*(K-1);
R0Km1=rnor(R0Km1,1);

% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa KRC Pasabajos '),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   R/a'),exi(Rsa),fprintf('ohm')
if a~=1 
fprintf('   R/(1-a)'),exi(Rs1ma),fprintf('ohm'),fprintf('\n')
else
fprintf('  ** Ho'),exi(HodB),fprintf('dB **'),fprintf('\n')
end
fprintf('   R0'),exi(R0),fprintf('ohm'),
fprintf('   R0(K-1)'),exi(R0Km1),fprintf('ohm'),
fprintf('   C'),exi(C),fprintf('F'),fprintf('\n'),fprintf('\n')



