function y=pjo2(fp,Qp);
% PJO2 proporciona: 1) la funci�n de transferencia de un filtro pasabajos
%                   2) los polos del pasabajos y 
%                   3) un gr�fico 'normalizado' de los polos en plano s
%  cuando se le ingresa:             (Ojo con las unidades)
%             1) la frecuencia del polo fp en kHz
%             2) el Q del filtro.
%
% Por ejemplo: >> pjo2(1000,0.8)
%
% Q y coeficiente de amortiguamiento:
%   Qp = 0.8     Z=1/(2Qp) = 0.625 
% 
%num/den = 
% 
%              39478417604357.4
%   --------------------------------------
%   s^2 + 7853981.634 s + 39478417604357.4
%
%polos =
%
%  1.0e+006 *
%
% -3.92699081698724 + 4.90480995836284i
% -3.92699081698724 - 4.90480995836284i
%
% Otro ejemplo: Si se introduce pjo2(1000,0.48) los polos son reales
%
%  Introducir     pjo2(fp,Qp)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   3 de Julio del 2002. Version 1.0

fpHz=1000*fp;
wp=2*pi*fpHz;
amortiguamiento = 1/(2*Qp);
fprintf('\n')
fprintf('  Q y coeficiente de amortiguamiento:'),fprintf('\n')
fprintf('   Qp'),exi(Qp),fprintf('     Z=1/(2Qp)'),exi(1/(2*Qp)),fprintf('\n')

[num2,den2] = ord2(wp,amortiguamiento);
printsys(num2*wp^2,den2,'s')

polos=roots(den2); % Calcula los polos
polos=polos(:)  % Los pone como vector columna y los muestra

if Qp < 0.5 
figure(1)
clf;
polosn=polos/wp;
MaxI=max(abs(imag([polosn;j])));     % Determina el tama�o del diagrama
MaxR=max(abs(real([polosn;1])));  
plot(1.5*[-MaxR MaxR],[0 0],'k')     % Grafica el eje real
hold on
text(1.5*MaxR,0,' Re')
plot([0 0],1.5*[-MaxI MaxI],'k')     % Grafica el eje imaginario
text(0,1.5*MaxI,' Im')
grafico=plot(real(polosn),imag(polosn),'bx') ;    % Grafica los polos
grid
set(grafico, 'linewidth', 1.5)
set(grafico, 'markersize', 12)
% T�tulo global en la figura
titulofig = title('Diagrama Normalizado de los Polos en el Eje Real');
set(titulofig,'FontSize',12);
% Subt�tulos de Teor�a de Circuitos II y la fecha
titulos
hold on

else


figure(1)
clf
axis('square');
sgrid(amortiguamiento,1)   % Para mostrar las coordenadas Polares
hold on

grafico=plot(real(polos/wp),imag(polos/wp),'bx'); % Grafica los polos
set(grafico, 'linewidth', 1.5)
set(grafico, 'markersize', 12)
% T�tulo global en la figura
titulofig = title('Diagrama Normalizado de los Polos en funci�n de wp y \zeta=1/(2 Q)');
set(titulofig,'FontSize',12);
% Subt�tulos de Teor�a de Circuitos II y la fecha
titulos
end

% T�tulos de los ejes de la figura
%xlabel('Re \rightarrow'); ylabel('Im \rightarrow');
