% PTP1 es una funci�n que proporciona los valores de
% L, M y k del transformador y el capacitor C (de la base del
% transformador a masa) de la etapa PasaTodo Pasiva de 1� orden
% con transformador y capacitor de resistencia constante,
% cuando se le ingresa en este orden:         (Ojo con las unidades)
%                      1) wp de la etapa normalizada
%                      2) El tiempo de retardo T que va a
%                         proporcionar la etapa en us (microsegundos
%                      3) El factor de escala de impedancias Kz
% Ejemplo:
%       1) Datos: Si s + wp = s + 3.64674, 
%          el retardo de etapa es 100us  y Kz=600
%       2) Se introduce: ptp1(3.64674,100,600)
%       3) Se obtiene:        
%          Etapa Pasatodo Pasiva de 1� orden:
%          L = 4.11326 mH  M = -4.11326 mH  k = -1  C = 45.7029 nF
%
%  Ver tambi�n: BICUA, KRCI, KRCK2, PBDA, PTA1, PTA2, PTP2, POLOSKRC, PRIMOR, 
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%              o-------+         +-------o        
%     		           | �  k   �| 
%    		           )|       |( 
%                   L  )|       |( L        
%    		           )|       |(
%    		           |_________|
%    		                |  
%    		              __|__
%      		  	          _____ C
%			                |
%			               _|_
%			                -
%  Introducir     ptp1(wp,T[us],Kz)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0

function y=ptp1(a,Tet,Kz)

Te=Tet/1e6;   % Retardo de la etapa bilineal en segundos
T=Te/2;       % Retardo de las transferencias de Bessel
Kf=1/T;       % El factor de frecuencia es la inversa del retardo

% Se calcula y se desnomaliza el valor del capacitor
Cn=2/a;
Cd=Cn/(Kz*Kf);

% Se adopta el valor normalizado m�s cercano 
C=cnor(Cd);

% Calculo de la inductancia e inductancia m�tua 
% Inductancia L
Ln=1/(2*a);
Ld=Kz*Ln/Kf;
% Inductancia Mutua M
Mn=-1/(2*a);
Md=Kz*Mn/Kf;

% Coeficiente de acoplamiento k:
k=Mn/Ln;

% Se muestran los resultados en Pantalla
fprintf('\n')
fprintf('    Etapa Pasatodo Pasiva de 1� orden:'),fprintf('\n')
fprintf('    L'),exi(Ld),fprintf('H')
fprintf('  M'),exi(Md),fprintf('H')
fprintf('  k'),exi(k),fprintf('')
%fprintf('  C'),exi(C),fprintf('F'),fprintf('\n') % Si se desea C estandar
fprintf('  C'),exi(Cd),fprintf('F')
fprintf('\n')
fprintf('\r')      

