% RELUCTANCIA es una funci�n que proporciona los valores de
% la reluctancia de una rama de un circuito magn�tico 
% cuando se le ingresa en el siguiente orden:          (Ojo con las unidades)
%                      1) La longitud media de la rama en cm 
%                      2) el �rea de la secci�n recta de la rama en cm^2
%                      3) La permeabilidad relativa �r de la rama
%                      4) El factor de dispersi�n fd 
%
%
%  Ejemplo:                                                             
%  
%  1) Datos:  Si para la rama es:
%                L=50 mm, A= 500 mm ^2, �r=1000, fd=1
%
%  2) Se ingresa:  reluctancia(5,5,1000,1)
%  3) Se obtiene:  
%               * La reluctancia vale 
%                 Reluctancia = 79.5775 kH^-1
%
%  Introducir:     reluctancia(L,A,mur,fd)

% � Copyright 2019. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   11 de febrero de 2019. Version 1.0

function y=reluctancia(L,A,mur,fd)

% Para indicar qu� hay que hacer cuando se introduce solo
% el nombre de la funci�n y evitar el mensaje de error
if nargin==0,
  disp('     Uso:  reluctancia(L,A,mur,fd)')
  disp('     Tipear ''help reluctancia'' para m�s ayuda.')
  disp('     C�tedra de Teor�a de Circuitos II.')
  disp(' ')
  return
end 


% Adecuaci�n de los datos
L=L/100;
A=A/10000;

% C�lculo de la reluctancia
uo=4*pi*1e-7;
R=L/(uo*mur*A*fd);
	 
% Presentaci�n de los resultados
fprintf('\n')

cprintf([1,0,0.1], '* La reluctancia vale \n');

cprintf('blue','  Reluctancia'),exi(R),fprintf('H^-1'),fprintf('\n')

fprintf('\r')