%	CHEPBAN es un programa que proporciona los componentes L y C de un 
%                  FILTRO CHEBYSHEV PASIVO PASABANDA 
% 	ingresando:
%                  1) las frecuencias inferior y superior de la banda de paso,
%                  2) la frecuencia de comienzo de la banda de atenuacion,
% 	           3) la atenuacion maxima en la  banda de paso
% 	           4) la atenuacion minima en la banda de atenuacion 
%                  5) Las resistencias del generador y de la carga              

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   15 de noviembre de 2016. Version 1.1



fprintf('----------    S�NTESIS DE FILTROS CHEBYSHEV PASIVOS PASABANDA    ----------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')

% 1.- Introduccion de los datos y conversion de los mismos a datos para el pasabajos equivalente

f1=input('Ingresar la frecuencia inferior de la banda de paso f1 en kHz: ');
f2=input('Ingresar la frecuencia superior de la banda de paso f2 en kHz : ');
fa=input('Ingresar la frecuencia superior de la banda de atenuacion  fa en kHz: ');
Amax=input('Ingresar la Atenuaci�n m�xima en la banda de paso Amax en dB: ');
Amin=input('Ingresar la Atenuaci�n m�nima en la banda de atenuacion Amin en dB: ');
fprintf('\n\n')

% Adecuacion de los datos
w1=2*pi*f1*1000;
w2=2*pi*f2*1000;
wa=2*pi*fa*1000;
B=w2-w1;
w0=sqrt(w1*w2);

% 2 Determinacion del orden del filtro Chebyshev Pasabanda

%  2.1  Determinacion del orden del filtro Chebyshev pasabajos equivalente

% Transformaci�n de las frecuencias de corte y de atenuacion a pasabajos

w2prima=(w2^2-w0^2)/B/w2;  % Frecuencia de corte de pasabajos equivalente
waprima=(wa^2-w0^2)/B/wa;  % Frecuencia de atenuacion del pasabajos equivalente

% Se "mira en las curvas de atenuaci�n" con cual orden n 
% se cumple con la especificacion de Amin

e=sqrt(10^(Amax/10)-1);         % Epsilon: factor de ondulaci�n
for n=1:1000
  y=n;
  wnor3dB=cosh(acosh(1/e)/n);   % Frecuencia de normalizacion para que la f3dB=1
  wc=w2prima/wnor3dB;           % Frecuencia de corte normalizada a f3dB=1
  wan=waprima/wc;               % Frecuencia de atenuacion normalizada
  Cnwa=cosh(n*acosh(wan));      % Valor del Polinomio de Chebyshev a fa
  AdBwa=10*log10(1+e^2*Cnwa^2); % Atenuaci�n en dB a la frecuencia de atenuacion
  if AdBwa>=Amin,break,end
end
N=y;

fprintf('          * 2) Orden del filtro :'),exi(2*N),fprintf(' \n\n')


% 3.- Introducci�n de las resistencias del generador y de carga
fprintf('          * 3) Ingreso de las resistencias del generador y de carga   '),fprintf('\n')
R1=input('Ingresar la resistencia R1 del generador en Ohms:   ');
fprintf('\n')
fprintf(' Ingresar la resistencia R2 de carga en Ohms ') 
R2=input('(Si el orden del filtro es par, R2 no debe ser igual a R1) :   ');

if (R2==R1 & rem(N,2)==0)
 fprintf(' Que le dije. No sea cabez�n !!!!! ') 
 R2=input('(Ingresar R2 distinto de R1) :   ');
end

if R2>R1
% 4 Proporciona L y  C de un Filtro Chebyshev empezando por un inductor


if rem(N,2)==0
	%fprintf('Filtro Chebyshev de Orden par'),fprintf('\n')
	FacKn=4*R1*R2/(R1+R2)^2;
	
	e=sqrt(10^(Amax/10)-1);
	Kn=(1+e*e)*FacKn;

	if Kn>1
		Kn=1;
		e=sqrt(1/FacKn-1);
		else
		Kn=Kn;
	end
else
	%fprintf('     Filtro Chevyshev de Orden impar'),fprintf('\n')

		Kn=4*R1*R2/(R1+R2)^2;
		e=sqrt(10^(Amax/10)-1);

end

% 4.1 Normalizaci�n de frecuencia

wnor=cosh(acosh(1/e)/N);     % Frecuencia de normalizacion para 
Wc=1/wnor;                   % que la frecuencia de 3dB sea 1

%  4.2 Calculo de los componentes

a=(asinh(1/e))/N;
a1=(asinh(sqrt(1-Kn)/e))/N;

gama = pi / (2 * N);
L = zeros (1,N);
vector1 = zeros (1,N);

num = 2 * sin(gama)*R1;
div = (sinh(a) - sinh(a1))*Wc;
L(1)= num / div;

C = zeros(1,N);
vector2 = zeros(1,N);

top = 0;
i = 1;
while (i < N),
  top = top + 1;
  i = i + 2;
end

invWc2 = 1 / (Wc * Wc);


for m=1:top,
 
 g1 = gama * (4 * m - 3);
  g2 = gama * (4 * m - 1);
  num = invWc2 * 4 * sin(g1) * sin(g2);

  
  
  div = fm(2*m-1,a,a1,N);
  vector1(m)= num / div;
  C(2*m) = vector1(m) / L(2*m - 1);

  g4 = gama * (4 * m - 1);
  g5 = gama * (4 * m + 1);
  num = invWc2 * 4 * sin(g4) * sin(g5);

  
  div =  fm(2*m,a,a1,N);
  vector2(m) = num / div;
  L(2*m+1) = vector2(m) / C(2*m);
end;

% 4.3 Presentaci�n de los componentes en pantalla

L=elicn(L);
C=elicn(C);


fprintf('\n')
fprintf('          * 4) Componentes L y C del filtro   '),fprintf('\n\n')
fprintf(' Se indican valores normalizados entre par�ntesis.'),fprintf('\n')
fprintf(' Capacitores al 5 por ciento, inductores al 1 por ciento.'),fprintf('\n\n')
fprintf('El filtro Pasabanda comienza a partir de R1 con un circuito LC serie:')
fprintf(' \n\n')
fprintf('Circuitos LC serie entre circuitos LC paralelo:')
fprintf(' \n\n')
Ls=L/B;
Cs=[];
for k=1:length(L)
 Cs(k)=1/L(k)/w0^2*B;
end

for i=1:length(L)

fprintf('Ls'),exi(Ls(i)),fprintf('H  (Lsn'),exi(lnor(Ls(i))),fprintf('H)')
fprintf('   en serie con ')
fprintf('   Cs'),exi(Cs(i)),fprintf('F  (Csn'),exi(cnor(Cs(i))),fprintf('F)') 
fprintf(' \n\n')

end


fprintf('Circuitos LC en paralelo a masa Lp, Cp:')
fprintf(' \n\n')
Cp=C/B;
Lp=[];
for k=1:length(C)
Lp(k)=1/C(k)/w0^2*B;
end

for i=1:length(C)

fprintf('Lp'),exi(Lp(i)),fprintf('H  (Lpn'),exi(lnor(Lp(i))),fprintf('H)')
fprintf('   en || con ')
fprintf('   Cp'),exi(Cp(i)),fprintf('F  (Cpn'),exi(cnor(Cp(i))),fprintf('F)') 
fprintf(' \n\n')

end


else
% 5. Proporciona L y  C de un Filtro Chebyshev empezando por un capacitor


if rem(N,2)==0
	%fprintf('       Filtro Chebyshev de Orden par'),fprintf('\n')
	FacKn=4*R1*R2/(R1+R2)^2;
	
	e=sqrt(10^(Amax/10)-1);
	Kn=(1+e*e)*FacKn;

	if Kn>1
		Kn=1;
		e=sqrt(1/FacKn-1);
		else
		Kn=Kn;
	end
else
	%fprintf('      Filtro Chevyshev de Orden impar'),fprintf('\n')

		Kn=4*R1*R2/(R1+R2)^2;
		e=sqrt(10^(Amax/10)-1);

end

% 5.1 Normalizaci�n de frecuencia

wnor=cosh(acosh(1/e)/N);           % Frecuencia de normalizacion para 
Wc=1/wnor;                         % que la frecuencia de 3dB sea 1. Para lo cual 
                                   % hay que eliminar el simbolo % si lo hubiera
% 5.2 Calculo de los componentes

a=(asinh(1/e))/N;
a1=(asinh(sqrt(1-Kn)/e))/N;

gama = pi / (2 * N);

C = zeros (1,N);
vector1 = zeros (1,N);

num = 2  * sin(gama);
div = (sinh(a) - sinh(a1))*Wc*R1;
C(1)= num / div;

L = zeros(1,N);
vector2 = zeros(1,N);

top = 0;
i = 1;
while (i < N),
  top = top + 1;
  i = i + 2;
end

invWc2 = 1 / (Wc * Wc);


for m=1:top,
 
 g1 = gama * (4 * m - 3);
  g2 = gama * (4 * m - 1);
  num = invWc2 * 4 * sin(g1) * sin(g2);

  
  
  div = fm(2*m-1,a,a1,N);
  vector1(m)= num / div;
  L(2*m) = vector1(m) / C(2*m - 1);

  g4 = gama * (4 * m - 1);
  g5 = gama * (4 * m + 1);
  num = invWc2 * 4 * sin(g4) * sin(g5);

  
  div =  fm(2*m,a,a1,N);
  vector2(m) = num / div;
  C(2*m+1) = vector2(m) / L(2*m);
end;

% 5.3 Presentaci�n de los componentes en pantalla

C=elicn(C);
L=elicn(L);

fprintf('\n')
fprintf('          * 4) Componentes L y C del filtro   '),fprintf('\n\n')
fprintf(' Se indican valores normalizados entre par�ntesis.'),fprintf('\n')
fprintf(' Capacitores al 5 por ciento, inductores al 1 por ciento.'),fprintf('\n\n')
fprintf('El filtro pasabanda comienza a partir de R1 con un LC en paralelo a masa '),fprintf('\n')
fprintf(' \n\n')
fprintf('Circuitos LC en paralelo a masa Lp, Cp:')
fprintf(' \n\n')
Cp=C/B;
Lp=[];
for k=1:length(C)
Lp(k)=1/C(k)/w0^2*B;
end

for i=1:length(C)

fprintf('Lp'),exi(Lp(i)),fprintf('H  (Lpn'),exi(lnor(Lp(i))),fprintf('H)')
fprintf('   en || con ')
fprintf('   Cp'),exi(Cp(i)),fprintf('F  (Cpn'),exi(cnor(Cp(i))),fprintf('F)') 
fprintf(' \n\n')

end

fprintf('Circuitos LC serie entre circuitos LC paralelo:')
fprintf(' \n\n')
Ls=L/B;
Cs=[];
for k=1:length(L)
 Cs(k)=1/L(k)/w0^2*B;
end

for i=1:length(L)

fprintf('Ls'),exi(Ls(i)),fprintf('H  (Lsn'),exi(lnor(Ls(i))),fprintf('H)')
fprintf('   en serie con ')
fprintf('   Cs'),exi(Cs(i)),fprintf('F  (Csn'),exi(cnor(Cs(i))),fprintf('F)') 
fprintf(' \n\n')

end


end

fprintf('----------    Fin del c�lculo de L y C del Filtro Chebyshev Pasivo Pasabanda    ----------'),fprintf('\n')
