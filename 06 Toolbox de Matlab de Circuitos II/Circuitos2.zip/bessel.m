function []=bessel(n)
% BESSEL es una funci�n que proporciona los valores
% de wp y Q de las etapas de filtros pasatodo cuando
% se le ingresa el orden del filtro.
% Por ejemplo:
% >> bessel(5)  proporciona:
%
% Par�metros de las Etapas:
% wp = 3.77789 Q = 0.563536 
% wp = 4.26102 Q = 0.916477 
% wp = 3.64674 
%
% Ingresar  bessel(orden)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   8 de Julio de 2002. Version 1.0

% Coeficientes de Bessel
c=[];
c(1)=prod(1:(2*n))/prod(1:n)/(2^n);
for i=1:n
c(i+1)=prod(1:(2*(n)-i))/prod(1:i)/prod(1:(n-i))/(2^(n-i));
end
c;
% Polinomios de Bessel
p=[];
for i=1:n+1
 p(i)=c(n+2-i);
end
a=p;

Na = length(a)-1; 

% Formaci�n de la etapas de segundo orden:
p= cplxpair(roots(a)); 
K = floor(Na/2);

if K*2 == Na     % C�lculo cuando Na es PAR
   A = zeros(K,3); final=K;
   for n=1:2:Na
       Afila = p(n:1:n+1,:);
       Afila = poly(Afila);
       A(fix((n+1)/2),:) = real(Afila);
   end

elseif Na == 1   % C�lculo cuando Na = 1
       A = [0 real(poly(p))];
       final=1;
else             % C�lculo cuando Na es IMPAR y > 1
   A = zeros(K+1,3);final=K+1;
   for n=1:2:2*K
       Afila = p(n:1:n+1,:);
       Afila = poly(Afila);
       A(fix((n+1)/2),:) = real(Afila);
       end
       A(K+1,:) = [0 real(poly(p(Na)))];
end

% Se generan e imprimen los par�metros wp y Q de las etapas
fprintf('\n')
fprintf(' Par�metros de las Etapas:'),fprintf('\n')
for i=1:final
	a=A(i,:);
 	if a(1)==1
 	wp=sqrt(a(3));
 	Q=wp/a(2);
  	fprintf(' wp'),exi(wp),fprintf('Q'),exi(Q),fprintf('\n')
 	else
 	fprintf(' wp'),exi(a(3)),fprintf('\n')
 	fprintf('\n')
	end
end

