% SKALTO es una funcion que proporciona los valores de:
%                las Resistencias y Capacitores
% de una etapa activa SALLEN KEY PASAALTOS de 2 orden 
% cuando se le ingresa:                                (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa y 
%                      3) Un valor de la resistencia en kohm 
%   			                         	 	     
%                    +------/\/\/\------*------------+     
%                    |	       R        |            |
%                    |                  |   |`.      |       
%              C     |      C           +---|- `.    |       
%             | |    |     | |              |    >---*---o V2
%    V1 o-----| |----*-----| |-----*--------|+ ,'            
%             | |          | |     |        |,'              
%                                  /           
%                                  \ mR        
%                                  /               
%                                 _|_            
%  Ejemplo:                        -    
%  1) Datos: Si la fp= 200 Hz, el Q= 1.5 y la R elegida de 30 kohm
%
%  2) Se introduce:   skalto(.2,1.5,30) proporciona:
%
%  3) Se obtiene: 
%                Etapa Sallen-Key Pasaalto adoptando R
%                C = 9.1 nF  R = 29.4 kohm  mR = 261 kohm
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     skalto(fp,Q,R)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1

function y=skalto(fp,Q,R)

fp=fp*1000;
R=R*1000;

m=4*Q^2;
C=1/(2*pi*sqrt(m)*fp*R);
C=cnor(C);
%C=input('Ingresar el valor normalizado mas cercano  ');  % Se puede introducir a mano             
R=1/(2*pi*sqrt(m)*fp*C);    % Se recalcula R              % sacando el signo de porcentaje 
mR=m*R;

R=rnor(R,1);
mR=rnor(mR,1);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('    Etapa Sallen-Key Pasaalto adoptando R'),fprintf('\n')
fprintf('    C'),exi(C),fprintf('F')        
fprintf('  R'),exi(R),fprintf('ohm')
fprintf('  mR'),exi(mR),fprintf('ohm'),fprintf('\n')



