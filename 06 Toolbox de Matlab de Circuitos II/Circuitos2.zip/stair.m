% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0



function [Q] = stair (N,D)

dimN = length(N);
dimD = length(D);

if ((dimD+1) ~= dimN),
  if (dimD == 1),
    Q = N / D(1);
  elseif (dimD > 1),
    if (dimD < dimN),
      Q = [(N(1)/D(1)) stair(D,N(dimD+1:dimN))];
    else
      Q = N;
    end
  end
else
  h = N(1)/D(1);
  if (dimD > 1),
    R = zeros(1,dimD-1);
    for (j=1:dimD-2),
      R (j)= N(j+2) - h*D(j+2);
    end
    R (dimD-1) = N(dimN);
    Q = [h stair(D,nocero(R))];
  else
    if (dimN == 1)
      Q = [h D];
    else
      Q = [h N(2) / D(1)];
    end
  end
end    