% FM funcion auxiliar utilizada en el calculo de los filtros de
% Chebishev a la cual se le pasa el �ndice m, los par�metros a y ac y
% orden del filtro n

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function [Y] = FM(m,a,ac,n)
 a1=sinh(a);
 a2=sinh(ac);   
 gama=m*pi/(2*n);
a3=sin(2*gama);
 a4=2*a1*a2*cos(m*pi/n);
  Y=a1^2+a2^2+a3^2-a4;