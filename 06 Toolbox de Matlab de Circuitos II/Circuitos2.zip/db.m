% DB proporciona el valor en dB de una relaci�n
% de tensiones o corrientes entre dos puntos de
% un circuito. 
% �nicamente si esas variables se miden sobre 
% resistencias iguales da la relaci�n de potencias.
% 
% Ejemplo: db(1/sqrt(2))
%                 ans =
%                        -3.0103
%
% Introducir db(x)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0

function y=db(x);
y=20*log10(abs(x));


