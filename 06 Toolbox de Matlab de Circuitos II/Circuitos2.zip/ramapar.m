% RAMAPAR es una funcion que proporciona los valores
% de las resistencias del bloque RAMa PARlelo activa que 
% implementa la rama paralelo (a masa) de una red escalera pasiva
         
% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

fprintf('-------   PROYECTO DE LA RAMA PARALELO ACTIVA    ------------------------------------'),fprintf('\n')
fprintf('          DE UN FILTRO DE DIAGRAMA DE FLUJO           '),fprintf('\n')


np=input('--> * Ingresar el numero de la Rama Pasiva Paralelo:   ');

% Ingreso de componentes de la rama paralelo
Rp=0;Lp=0;Cp=0;Ls=0;Cs=0;
fprintf('\n'),fprintf(' --> * 1) Ingresar los componentes de la Rama Pasiva Paralelo'),fprintf('\n')
Rp=input('Ingresar la resistencia Rp en Ohms:   ');
Lp=input('Ingresar el inductancia Lp en mH:   ');
Cp=input('Ingresar el capacitor Cp en nF:   ');
Ls=input('Ingresar la inductancia Ls en mH:   ');
Cs=input('Ingresar el capacitor Cs en nF:   ');
fprintf('\n')
if Rp==0 & Lp==0 & Cp==0 & Cs ==0 & Ls ==0 
fprintf('   No hay componentes a simular, tontuelo !.   '),fprintf('\n')
break
elseif Rp~=0 & Lp==0 & Cp==0 & Cs==0 & Ls==0
fprintf(' Una R se simula con una ....R, bobalicon !.   '),fprintf('\n')
break
end

Rp=Rp;
Lp=Lp*1e-3;
Cp=Cp*1e-9;
Cs=Cs*1e-9;
Ls=Ls*1e-3;

% Ingreso de las tensiones y corrientes en Lp y Ls
Vk=0;VLp=0;ILpRe=0;VCs=0;ILsRe=0;
if Lp~=0 | (Ls & Cs)~=0
 fprintf('\n'),fprintf(' --> * 2.- Ingresar las tensiones MAXIMAS siguientes'),fprintf('\n')
 fprintf('            Todas en Volt o Todas en mVolt'),fprintf('\n');
fprintf('\n');
 fprintf('   Ingresar la tension V'),sub(np),fprintf('sobre la rama '),sub(np),fprintf(' '),fprintf('\n')
 Vk=input('   : ');
end

if Lp~=0
  fprintf('   Ingresar la tension IL'),sub(np),fprintf('x Re  '),fprintf('\n')
 ILpRe=input('   : ');
end

if Ls~=0 & Cs~=0
 fprintf('   Ingresar la tension VCs'),sub(np),fprintf('sobre Cs'),sub(np),fprintf(' '),fprintf('\n')
 VCs=input('   : ');
 fprintf('   Ingresar la tension ILs'),sub(np),fprintf('x Re '),fprintf('\n')
 ILsRe=input('   : ');
end

% Ingreso de los coeficientes de entrada
ce1=1;ce2=1;
fprintf('\n'),fprintf(' --> * 3.- Ingresar los coeficientes de entrada'),fprintf('\n')
ce1=input('Ingresar ce1:   ');
ce2=input('Ingresar ce2 :   ');

% Ingreso de los valores adoptados
as=['s'];
while as==['s']


fprintf('\n'),fprintf(' --> * 4.- Ingresar los valores adoptados'),fprintf('\n')
Ra=10;C=10;Re=100;
Ra=input('Ingresar la resistencia Ra en KOhm :   ');
C=input('Ingresar el capacitor C de los integradores en nF :   ');
Re=input('Ingresar la resistencia Re en Ohm :   ');
Ra=Ra*1000;
C=C*1e-9;
Re=Re;
fprintf('\n') 
% Presentacion de los resultados
if Rp ~=0  & Lp ~=0  & Cp ~=0  & Cs  ~=0  & Ls ~=0 
fprintf('   Componentes del Bloque que implementa (Rp || sLp || 1/sCp) || (s Ls + 1/s Cs) : '),fprintf('\n')
elseif Rp ~=0  & Lp ~=0  & Cp ~=0 & Cs==0 & Ls==0 
fprintf('   Componentes del Bloque que implementa Rp || sLp || 1/sCp : '),fprintf('\n')
elseif Rp ~=0  & Lp  ~=0  &  Cp==0 & Cs==0 & Ls ==0 
fprintf('   Componentes del Bloque que implementa Rp || sLp : '),fprintf('\n')
elseif (  Rp ~=0  & Cp ~=0   &  Lp==0 & Cs==0 & Ls==0   )
fprintf('   Componentes del Bloque que implementa Rp || 1/sCp : '),fprintf('\n')
elseif Lp ~=0  & Cp ~=0 & Rp==0 & Cs==0 & Ls ==0 
fprintf('   Componentes del Bloque que implementa sLp || 1/sCp  : '),fprintf('\n')
elseif Cs ~=0  & Ls ~=0  & (Rp==0 & Lp==0 & Cp==0)
fprintf('   Componentes del Bloque que implementa sLs + 1/sCs a masa: '),fprintf('\n')
elseif Rp~=0 & Cs ~=0 & Ls~=0 & Lp==0 & Cp ==0 
fprintf('   Componentes del Bloque que implementa Rp || (sLs + 1/sCs) : '),fprintf('\n')
elseif (Cp ~=0  & Rp==0 & Lp==0 & Cs ==0 & Ls ==0 )
fprintf('   Componentes del Bloque que implementa 1/s Cp : '),fprintf('\n')
elseif (Lp ~=0  & Rp==0 & Cp ==0 & Cs==0 & Ls ==0 )
fprintf('   Componentes del Bloque que implementa s Lp : '),fprintf('\n')
elseif (Lp ==0  & Rp~=0 & Cp~= 0 & Cs~=0 & Ls~=0 )
fprintf('   Componentes del Bloque que implementa Rp || 1/s Cp || (sLs + 1/sCs)  : '),fprintf('\n')
elseif (Rp ==0  & Lp~=0 & Cp~= 0 & Cs~=0 & Ls~=0 )
fprintf('   Componentes del Bloque que implementa Lp || 1/s Cp || (sLs + 1/sCs)  : '),fprintf('\n')

end

% Adecuacion de los valores ingresados
C=cnor(C);
a=ce1;
b=1/ce2;

% Calculo, normalizaci�n y presentaci�n de los componentes

if Cp~=0
 RasRe=Cp/C;
 Ra=RasRe*Re;
else
RasRe=Ra/Re;
end

Re1=Ra/a ;    Re1n=lnor(Re1);
Re2=Ra/b;     Re2n=lnor(Re2);
fprintf('   Ra'),sub(np),exi(Re1n),fprintf('Ohm'),fprintf('\n')
fprintf('   Rb'),sub(np),exi(Re2n),fprintf('Ohm'),fprintf('\n')
fprintf('   C'),exi(C),fprintf('F'),fprintf('\n')


if Rp ~=0
 R1= Rp*RasRe;       R1n=lnor(R1);
 fprintf('   R1'),sub(np),exi(R1n),fprintf('Ohm'),fprintf('\n')
end


if Lp~=0
  m2=ILpRe/Vk;
  Rc2a=Lp/C/Re;
  Rc2=Rc2a*m2; Rc2n=lnor(Rc2); 
  R2=(Lp/C*Ra/Re)/Rc2; R2n=lnor(R2);
  fprintf('   R2'),sub(np),exi(R2n),fprintf('Ohm'),fprintf('\n')
  fprintf('   Rc2'),sub(np),exi(Rc2n),fprintf('Ohm'),fprintf('\n')
end

if Cs~=0 & Ls~=0
 m3=ILsRe/Vk;

 R3a=Ls/C/Re;
 Rc3=R3a*m3;          Rc3n=lnor(Rc3);
 R3=Ra/m3;            R3n=lnor(R3);
 fprintf('   R3'),sub(np),exi(R3n),fprintf('Ohm'),fprintf('\n')
 fprintf('   Rc3'),sub(np),exi(Rc3n),fprintf('Ohm'),fprintf('\n')
 
 m4=VCs/ILsRe;
 Rc4a=Cs/C*Re;
 Rc4=Rc4a*m4;      Rc4n=lnor(Rc4);
 R4=(Cs*Ls/C^2)/Rc4;       R4n=lnor(R4);
 fprintf('   Rc4'),sub(np),exi(Rc4n),fprintf('Ohm'),fprintf('\n')
 fprintf('   R4'),sub(np),exi(R4n),fprintf('Ohm'),fprintf('\n')
end


fprintf('    Las R de los inversores (si hubieran) se adoptan iguales'),fprintf('\n')


 as=input('--> * Desea recalcular los componentes? s/n :  ','s');
end

fprintf('\n'),fprintf('   Fin del calculo de la Rama Paralelo Activa '),sub(np),fprintf('\n')

fprintf('\n')