% PTA1R es una funci�n que proporciona los valores de
% C de la etapa PasaTodo Activa bilineal de 1� orden 
% con un Amplificador Operacional
%
% cuando se le ingresa en este orden:         Ojo con las Unidades)
%                       1) a0 de la etapa normalizada
%                       2) El tiempo de retardo T que va a
%                          proporcionar la etapa en us (microsegundos)
%                       3) Un valor de la Resistencia R en kohm
%  Ejemplo:
%  1)  Datos: Si s + a0 = s + 3.64674, el retardo de
%             la etapa es 100us  y se adopta R=13.7 kohm
%  2)  Se introduce: pta1r(3.64674,100,13.7)
%  3)  Se obtiene:        
%                 Etapa Pasatodo Activa de 1� orden:
%                 C = 1 nF.  Se adopt�: R = 13.7 kohm
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, PTA1, PTA2, PTP1, POLOSKRC, PRIMOR, 
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     pta1r(a0,T[us],R[kohm])

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   5 de Julio de 2002. Version 1.0

function y=pta1r(a0,Tet,R)

Te=Tet/1e6;   % Retardo de la etapa bilineal en segundos
T=Te/2;       % Retardo de las transferencias de Bessel
Kf=1/T;       % El factor de frecuencia es la inversa del retardo

% C�lculo de wp de la transferencia 
wp=a0;
wpd=wp*Kf;

% C�lculo del valor de la capacidad
R=R*1e3;
C=1/(wpd*R);
Rn=rnor(R,1);

% Valores normalizados m�s cercanos
Cn=cnor(C);
Rn=rnor(R,1);
% Presentacion de los resultados
fprintf('\n')
fprintf('    Etapa Pasatodo Activa de 1� orden:'),fprintf('\n')
fprintf('    C'),exi(Cn),fprintf('F.')
fprintf('  Se adopt�: R'),exi(Rn),fprintf('ohm')
fprintf('\n')
fprintf('\r')




