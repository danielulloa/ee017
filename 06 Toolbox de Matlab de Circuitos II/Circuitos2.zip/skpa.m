% SKPA es una funci�n que proporciona los valores de:
%                las Resistencias y Capacitores
% de una etapa activa SALLEN KEY PASAALTOS de 2� orden 
% cuando se le ingresa:                        (Ojo con las unidades)
%                      1) La frecuencia del polo fp en KHz
%                      2) El Q de la etapa y 
%                      3) Un valor de la capacidad en nF 
%   			                         	 	     
%                    +------/\/\/\------*------------+     
%                    |	       R        |            |
%                    |                  |   |`.      |       
%              C     |      C           +---|- `.    |       
%             | |    |     | |              |    >---*---o V2
%    V1 o-----| |----*-----| |-----*--------|+ ,'            
%             | |          | |     |        |,'              
%                                  /           
%                                  \ mR        
%                                  /               
%                                 _|_            
%  Ejemplo:                        -    
%
%  1) Datos: Si fp= 200 Hz, Q= 1.5 y la capacidad elegida es 10 nF
%
%  2) Se ingresa:  skpa(.2,1.5,10) proporciona:
%
%  3) Se obtiene:  C = 10 nF  R = 26.7 kohm  mR = 237 kohm
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     skpa(fp,Q,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1

function y=skpa(fp,Q,C)

fp=fp*1000;
C=C*1e-9;
C=cnor(C);
m=4*Q^2;

R=1/(4*pi*Q*fp*C); % Se calcula R
mR=m*R;            % Se calcula mR

R=rnor(R,1);       % Se adopta el valor normalizado al 1% m�s cercano
mR=rnor(mR,1);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('    Etapa Sallen-Key Pasaalto'),fprintf('\n')
fprintf('    C'),exi(C),fprintf('F')        
fprintf('  R'),exi(R),fprintf('ohm')
fprintf('  mR'),exi(mR),fprintf('ohm'),fprintf('\n')
fprintf('\r')