% RNOR(Resistencia, Tolerancia) Funci�n que normaliza las resistencias a su
% valor comercial mas cercano. La tolerancia puede ser 10, 5 � 1 %. 

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function y=rnor(R,Tol)
exp=fix(log10(R));  % para hallar el exponente de la potencia
Rapn=R*10^(-exp); %Para llevar al valor normalizado para comparacion

if Tol==10
% resistencias normalizadas al 10%

Rnorm=[1 1.2 1.5 1.8 2.2 2.7 3.3 3.9 4.7 5.6 6.8 8.2 9.1 10 12]; 
LR=length(Rnorm);
maxdif=100;
for i=1:LR
  Dif=abs(Rnorm(i)/Rapn-1)*100;
  maxdif=min(Dif,maxdif);
   
  if maxdif < Dif,break, end
  
end	


y=(Rnorm(i-1)*10^(exp)); 




elseif Tol==5
% Resistencias normalizadas al 5 %

Rnorm=[1 1.1 1.2 1.3 1.5 1.6 1.8 2 2.2 2.4 2.7 3 3.3 3.6 3.9 4.3 4.7 5.1 5.6 6.2 6.8 7.5 8.2 9.1 10 11];
LR=length(Rnorm);
maxdif=100;
for i=1:LR
  Dif=abs(Rnorm(i)/Rapn-1)*100;
  maxdif=min(Dif,maxdif);
   
  if maxdif < Dif,break, end
  
end	


y=(Rnorm(i-1)*10^(exp)); 



else Tol==1;
% Resistencias normalizadas al 1%

Rnorm=[100 102 105 107 110 113 115 118 121 124 127 130 133 137 140 143 147 150 154 158 162 165 169 174,...
       178 182 187 191 196 200 205 210 215 221 226 232 237 243 249 255 261 267 274 280 287 294 301 309,...
       316 324 332 340 348 357 365 374 383 392 402 412 422 432 442 453 464 475 487 499 511 523 536 549,...
       562 576 590 604 619 634 649 665 681 698 715 732 750 768 787 806 825 845 866 887 909 931 953 976 1000 1020];

Rnorm=Rnorm/100;
LR=length(Rnorm);
maxdif=100;
for i=1:LR
  Dif=abs(Rnorm(i)/Rapn-1)*100;
  maxdif=min(Dif,maxdif);
   
  if maxdif < Dif,break, end
  
end	


y=(Rnorm(i-1)*10^(exp)); 




end

