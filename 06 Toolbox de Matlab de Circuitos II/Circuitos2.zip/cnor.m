% La funcion Cnor proporciona los valores de capacitores normalizados al valor
% del argumento, suponiendo una tolerancia del 5 %.

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


function y=cnor(C)

exp=fix(log10(C)); % para hallar el exponente de la potencia
if C <= 1
 Capn=10*C*10^(-exp); %Para llevar al valor normalizado para comparacion
else
 Capn=C*10^(-exp);    
end

%Capn=10*C*10^(-exp); %Para llevar al valor normalizado para comparacion

% Capacitores normalizados al 5 %
Cnorm=[1 1.1 1.2 1.3 1.5 1.6 1.8 2 2.2 2.4 2.7 3 3.3 3.6 3.9 4.3 4.7 5.1 5.6 6.2 6.8 7.5 8.2 9.1 10 11];

% Otra tabla de capacitores. Para usarla hay que sacar los %
%Cnorm=[1 1.2 1.5 1.8 2.2 2.7 3 3.3 3.6 3.9 4.3 4.7 5.1 5.6 6.2 6.8 7.5 8.2 9.1 10 12];

LC=length(Cnorm);
maxdif=100;

for i=1:LC
  Dif=abs(Cnorm(i)/Capn-1)*100;
  maxdif=min(Dif,maxdif);
   
  if maxdif < Dif,break, end
  
end	


if C <= 1
 y=(Cnorm(i-1)*10^(exp))/10; 
else
 y=(Cnorm(i-1)*10^(exp)); 
end



%y=(Cnorm(i-1)*10^(exp))/10; 