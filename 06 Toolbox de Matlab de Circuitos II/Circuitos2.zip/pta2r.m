% PTA2R es una funci�n que proporciona los valores de
% QR y C de la etapa PasaTodo Activa de 2� orden 
% con Conversores Generalizados de Impedancia
%
% cuando se le ingresa en este orden:         Ojo con las Unidades)
%                       1) wp de la etapa normalizada
%                       2) Q de la etapa normalizada
%                       3) El tiempo de retardo T que va a
%                          proporcionar la etapa en us (microsegundos)
%                       4) Un valor de la resistencia R en kohm
%                       
%  Ejemplo:
%  1)  Datos: wp = 3.77789 , Q = 0.563536
%      el retardo de la etapa es 100us  y se adopta R = 13.7k
%  2)  Se introduce: pta2r(3.77789,0.563536,100,13.7)
%  3)  Se obtiene:        
%         Etapa Pasatodo Activa de 2� orden con CGI:
%         C = 0.966051 nF  RQ = 7.68 kohm.  Se adopt�: R = 13.7 kohm  
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, PTA1, PTA2, PTP1, POLOSKRC, PRIMOR, 
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     pta2r(wp,Q,T[us],R[kohm])

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   5 de Julio de 2002. Version 1.0

function y=pta2r(wp,Q,Tet,R)

Te=Tet/1e6;   % Retardo de la etapa bicuadratica en segundos
T=Te/2;       % Retardo de las transferencias de Bessel
Kf=1/T;       % El factor de frecuencia es la inversa del retardo

% C�lculo de wpd 

wpd=wp*Kf;

% C�lculo de los valores de C y QR
R=R*1e3;
C=1/(wpd*R);
Rq=Q*R;

% Valores normalizados m�s cercanos

Rn=rnor(R,1);
Rqn=rnor(Rq,1);
Cn=cnor(C);

% Presentacion de los resultados
fprintf('\n')
fprintf('    Etapa Pasatodo Activa de 2� orden con CGI:'),fprintf('\n')
fprintf('    C'),exi(C),fprintf('F')
fprintf('  RQ'),exi(Rqn),fprintf('ohm.')
fprintf('  Se adopt�: R'),exi(Rn),fprintf('ohm')
fprintf('\n')
fprintf('\r')



