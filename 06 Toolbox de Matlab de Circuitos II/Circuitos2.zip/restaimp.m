% RESTAIMP Calculo de la impedancia resultante despues de la remoci�n total del polo
% Zresultante=Z - ZLC
% Proporciona la impedancia resultante cuando se le extrae un polo imaginario
% se le ingresa el numerador nz y denominador nz de la impedancia a la cual
% se le extrae el polo, el polinomio del residuo del polo ks y el polo

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function [nr,dr]=restaimp(nz,dz,k,polo)


ks=k*poly(0); %polinomio del residuo
pp=[1 0 abs(polo)^2]; % polinomio pp que caracteriza al polo

dr=deconv(dz,pp);
na=nz;
nb=conv(dr,ks);
nc=restapol(na,nb);
nr=deconv(nc,pp);

ceros=roots(nr);
polos=roots(dr);