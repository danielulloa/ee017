% RETBESSEL representa las funciones retardo 
% de un filtro Bessel de 2�, 3� y 4� orden
%
% Estas funciones se han ingresado directamente y representado
% mediante la funci�n "easy plot" ezplot. El gr�fico resultante
% no es muy elaborado pero es muy f�cil de obtener.
% Esta funci�n se trabaja as�: 
%	Se define la funci�n:  fun='sin(x)';(notar la funci�n que va entre ' ')
%	Se grafica con :       ezplot(fun)

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

figure(1)
clf
figure(gcf)
set(gcf, 'defaultaxesfontsize', 14)
set(gcf, 'defaulttextfontsize', 14)
set(gcf, 'defaultlinelinewidth', 1.5)
set(gcf, 'defaultlinemarkersize', 10)

ret4='((53.01+ 5.8* w^2 )/(33.64*w^2+9.14^2 -2*9.14*w^2+ w^4)+ (48.37+ 4.21* w^2 )/(17.72*w^2+ 11.49^2-2*11.49*w^2 + w^4))';
ezplot(ret4,[0,10]);

hold on
% El retardo de 3� orden se ha tomado directamente del libro de Huelsman
ret3='((2.321219 )/(w^2+5.39257)+ (23.75656+ 3.67781* w^2 )/(41.72424+0.60743*w^2 + w^4))';
ezplot(ret3,[0,10]);
hold on
% El retardo de 2� orden 
ret2='( 9+ 3*w^2 )/(9 +3*w^2 + w^4)';
ezplot(ret2,[0,10]);
hold on

titulos;

% Ampliaci�n de la zona, donde w var�a entre 0 y 2
% para el retardo de filtro de Bessel de orden 4
figure(2)
clf
figure(gcf)
set(gcf, 'defaultaxesfontsize', 14)
set(gcf, 'defaulttextfontsize', 14)
set(gcf, 'defaultlinelinewidth', 1.5)
set(gcf, 'defaultlinemarkersize', 10)

ret4='((53.01+ 5.8* w^2 )/(33.64*w^2+9.14^2 -2*9.14*w^2+ w^4)+ (48.37+ 4.21* w^2 )/(17.72*w^2+ 11.49^2-2*11.49*w^2 + w^4))';
ezplot(ret4,[0,2]);
hold on
%ret3='((2.321219 )/(w^2+5.39257)+ (23.75656+ 3.67781* w^2 )/(41.72424+0.60743*w^2 + w^4))'
%ezplot(ret3,[0,2]);
titulos