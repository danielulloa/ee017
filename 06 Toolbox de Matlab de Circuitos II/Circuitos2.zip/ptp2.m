% PTP2 es una funci�n que proporciona los valores de
% L, M y k del transformador y los capacitores Ca (que puentea el
% tranformador) y Cb (de la base del tranformador a masa) de la 
% etapa PasaTodo Pasiva de 2� orden con transformador y capacitores
% cargada con una resistencia constante,
% cuando se le ingresa en este orden:           (Ojo con las unidades)
%                       1) wp de la etapa normalizada
%                       2) Q de la etapa normalizada
%                       3) El tiempo de retardo T que va a
%                         proporcionar la etapa en us(microsegundos)
%                       4) El factor de escala de impedancias Kz
% Ejemplo:
%       1)  Datos: wp = 3.77789 , Q = 0.563536,
%           el retardo de etapa es 100us  y Kz=600
%       2)  Se introduce: ptp2(3.77789,0.563536,100,600)
%       3)  Se obtiene:        
%           Etapa Pasatodo Pasiva de 2� orden:
%           L = 9.28314 mH  M = -4.80813 mH  k = -0.517943 
%           Ca = 6.21529 nF  Cb = 78.2849 nF
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, PTA1, PTA2, PTP1, POLOSKRC, PRIMOR, 
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%			               | | Ca
%		        +----------| |----------+
%		        |          | |	        |
%		        |		                |
%         o-----*------+         +------*-----o        
%     		           | �  k   �| 
%    		           )|       |( 
%                   L  )|       |( L        
%    		           )|       |(
%    		           |_________|
%    		                |  
%    		              __|__
%      		  	          _____ Cb
%			                |
%			               _|_
%			                -
%  Introducir     ptp2(wp,Q,T[us],Kz)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0

function y=ptp2(wp,Q,Tet,Kz)

Te=Tet/1e6;   % Retardo de la etapa bicuadratica en segundos
T=Te/2;       % Retardo de las transferencias de Bessel
Kf=1/T;       % El factor de frecuencia es la inversa del retardo


% C�lculo de los valores de los capacitores

Can=Q/(2*wp);
Cad=Can/(Kz*Kf);

Cbn=2/(wp*Q);
Cbd=Cbn/(Kz*Kf);

% Valores de los capacitores estandarizados 
Ca=cnor(Cad);
Cb=cnor(Cbd);


% C�lculo de la inductancia e inductancia m�tua
Ln=Q/(2*wp)*(1+1/Q^2);
Ld=Kz*Ln/Kf;

Mn=Q/(2*wp)*(1-1/Q^2);
Md=Kz*Mn/Kf;

% Coeficiente de acoplamiento k:
k=Mn/Ln;

% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('    Etapa Pasatodo Pasiva de 2� orden:'),fprintf('\n')
fprintf('    L'),exi(Ld),fprintf('H')
fprintf('  M'),exi(Md),fprintf('H')
fprintf('  k'),exi(k),fprintf(''),fprintf('\n')
%fprintf('  Ca'),exi(Ca),fprintf('F')             
%fprintf('  Cb'),exi(Cb),fprintf('F'),fprintf('\n')
fprintf('    Ca'),exi(Cad),fprintf('F')             
fprintf('  Cb'),exi(Cbd),fprintf('F')
fprintf('\n')
fprintf('\r')



