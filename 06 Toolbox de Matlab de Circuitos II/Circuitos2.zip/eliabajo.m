%	ELIABAJO  es un programa que suministra fp,fz y Q para el proyecto
%             de FILTROS EL�PTICOS ACTIVOS PASABAJOS 
% 	ingresando: 
%       1) La frecuencia de corte de 3dB de la banda de paso
%       2) La atenuacion m�xima en la banda de paso (el ripple)
% 	 3) La atenuaci�n m�nima en la banda de atenuacion
%       4) El Orden n del filtro
%
%       Consultar tambien ELIABAJ que permite el proyecto CALCULANDO 
%       el orden n del filtro.

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

fprintf('--------    PROYECTO DE FILTROS EL�PTICOS PASABAJOS    --------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')


% Puesta a cero de los vectores

A3=[];
N=[];
D=[];
a1=[];
a2=[];
a0=[];
b1=[];
b0=[];
Qpolo=[];
Wpolo=[];
Wcero=[];
Wpolo3dB=[];
Wcero3dB=[];
A1=[];
A0=[];
acero=[];

% Ingresos de los datos de frecuencia y atenuaci�n

f3dB=input('Ingresar la frecuencia de corte de 3dB en kHz:   ');
Amax=input('Ingresar la Atenuaci�n m�xima en la banda de paso Am�x en dB :  ');
Amin=input('Ingresar la Atenuaci�n m�nima en la banda de atenuacion Am�n en dB:  ');
n=input('Ingresar el orden del filtro:   ');
f3dB=f3dB*1000;
fprintf(' \n')

% C�lculo de los polos del filtro el�ptico
fprintf('                             Calculando fp,fz y Q. Tarda un poco .... '),fprintf(' \n')
fprintf(' \n')

[z,p,k]=ellipap(n,Amax,Amin);

% Ac� se normalizan los polinomios del filtro el�ptico 
% Las variables se hacen globales para que puedan ser accedidas 
% por la funci�n elicomp

KNUME=k;
PNUME=poly(z);
PDENE=poly(p);

global KNUME PNUME PDENE


W3dB=fzero('elicomp',1); % Encuentra la frecuencia a la cual el modulo es igual a 1/raiz de 2


% Ac� se calculan los ceros
z;
z=cplxpair(z);
nz=length(z);
for i=1:2:nz
acero(i)=1/(abs(z(i)))^2;
Wcero(i)=abs(z(i));
Wcero3dB(i)=Wcero(i)/W3dB;
end

% De los polos agrupados en funciones de 2 orden, se obtiene el Q y la frecuencia

if rem(n,2)~=0   % Si el orden es impar
np=length(p)-1;

  for i=1:2:np
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    Wpolo3dB(i)=Wpolo(i)/W3dB*f3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
  
    a2(i)=1/Wpolo(i)^2;
    a1(i)=sqrt(a2(i))/Qpolo(i);
    A0(i)=Wpolo(i)^2;
    A1(i)=sqrt(A0(i))/Qpolo(i);

   end

poloreal=p(length(p));

else

np=length(p);     % Si el orden es par
  for i=1:2:np
    
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    Wpolo3dB(i)=Wpolo(i)/W3dB*f3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
  
    a2(i)=1/Wpolo(i)^2;
    a1(i)=sqrt(a2(i))/Qpolo(i);
    A0(i)=Wpolo(i)^2;
    A1(i)=sqrt(A0(i))/Qpolo(i);
  end

poloreal=[];

end

% Presentaci�n de los resultados en pantalla

fprintf('          * 2) fp, fz y Q de cada etapa:'),fprintf(' \n')
fprintf(' \n\n')
fpolo=elicn(Wpolo3dB);
fcero=elicn(Wcero3dB)*f3dB;
Qpolo=elicn(Qpolo);
for i=1:length(fpolo)
      
      fprintf('fp'),exi(fpolo(i)),fprintf('Hz'),fprintf('     fz'),exi(fcero(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo(i))
      fprintf(' \n\n')
end

fpreal=abs(poloreal)/W3dB*f3dB; % La frecuencia del polo real que falta 
if rem(n,2)==0
fprintf('Filtro de orden par'),fprintf(' \n\n')
else
fprintf('Filtro de orden impar    ')
fprintf('fpreal'),exi(fpreal),fprintf('Hz'),fprintf(' \n\n')
end
%Ordenfiltro=n

fprintf('-------    Fin del c�lculo de fp,fz y el Q del Filtro El�ptico Pasabajo    -------------------------------------------------------'),fprintf('\n')





  
