% SUB sirve para poner el numero de sub�ndices de componentes
  
% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function[]=sub(x);
exp=fix(log10(x));  % para hallar el exponente de la potencia

if exp < 3
y=x;
y1=fprintf('%g ',y);
elseif exp <6
y=x*10^(-3);
y1=fprintf('%g K',y);
elseif exp <=9
y=x*10^(-6);
y1=fprintf('%g M',y);
elseif exp <=12
y=x*10^(-9);
y1=fprintf('%g G',y);
elseif exp <=15
y=x*10^(-12);
y1=fprintf('%g T',y);
elseif exp <=18
y=x*10^(-15);
y1=fprintf('%g P',y);
elseif exp <=21
y=x*10^(-18);
y1=fprintf('%g E',y);
end

