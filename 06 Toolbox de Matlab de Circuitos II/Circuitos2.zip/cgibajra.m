% CGIBAJRA es una funci�n que proporciona los valores de
% las resistencias, capacitores y la ganancia de una etapa activa
% CGI pasaBajos con Ranura de 2� orden Alternativo
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) La frecuencia del cero fz en kHz    
%                      3) El Q de la etapa
%                      4) Un valor de la resistencia R en kohm 
%   
%  Ejemplo:
%  1) Datos: Si fp= 11.9411 kHz, fz= 25.1824 kHz, el Q= 0.701971 , 
%            y el R elegido es = 10 kohm
%  
%  2) Se ingresa:   cgibajra(11.9411,25.1824,0.701971,10)
%
%  3) Se obtiene:
%                 Etapa CGI Pasabajos con ranura alternativo
%                 R = 10 kohm   C = 0.56 nF
%                 R1 = 59 kohm   R2 = 16.9 kohm
%                 Ganancia de continua de la etapa = 13.0471 dB
%             | |    
%      +------| |----------------------------------------------------------+
%      |      | | C                                   |`.      	           |  
%      |	         +--------------------------------|+ `.     	       |
%      |	         |                                |    >---*---o V2    |    
%      |             |                            +---|- ,'    |           |
%      |	     	 |                            |   |,'      |           |
%      |		     |                  	      | 	   	   |	       |
% V1   | 	   R     |      | | C          R      |     R      |      R1   |
%  o---*---/\/\/\----*------| |-----*----/\/\/\---*---/\/\/\---*---/\/\/\--*---+
%                           | |     |             |          	           |   |             
%  		                            |      	      | 	 		           |   /
%  	                                |      .�|    |	                       |   \ R2
%  		                            |    .� -|----+                        |   /			                                               
%  		                            +---<    |                             |   |			                                   
%  		                                 `. +|-----------------------------+  _|_			                                   
%  			                               `.|                     		       -                         
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     cgibajra(fp,fz,Q,R)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0

function y=cgibajra(fp,fz,Q,R)

% 0) Se verifica un error grosero
if fz<fp
    fprintf(' � En un filtro Pasabajos con ranura'),fprintf('\n')
    fprintf('   fz debe ser mayor que fp !')
    fprintf('\n')
    fprintf('\r')
break
end

% 1)Se adecuan los datos:
fp=fp*1000;
fz=fz*1000;
R=R*1000;
R=rnor(R,1);

% 2) Se calcula C
C=1/(2*pi*fp*R*Q*((fz/fp)^2-1));

% 3) Se calcula R2
R2= Q/(2*pi*fp*C);

% 4) Se calcula R1
R1=R2*((fz/fp)^2-1);

% 5)Se normalizan los valores calculados
R1=rnor(R1,1);
R2=rnor(R2,1);
C=cnor(C);

% 6) Ganancia de la etapa
% ganancia=(fz/fp)^2; te�rica
ganancia=1+R1/R2;
gandB=20*log10(abs(ganancia));

% 7)Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa CGI Pasabajos con ranura alternativo'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   C'),exi(C),fprintf('F'),fprintf('\n')
fprintf('   R1'),exi(R1),fprintf('ohm')
fprintf('   R2'),exi(R2),fprintf('ohm'),fprintf('\n')
fprintf('   Ganancia de continua de la etapa'),exi(gandB),fprintf('dB')
fprintf('\n'),fprintf('\n')



