% CGITOD es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% CGI pasaTODo de 2� orden 
% cuando se le ingresa:                             (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa
%                      3) Un valor del capacitor C en nF 
%   
%  Ejemplo:
%  1) Datos: Si la fp= 1000 Hz, el Q= 10,
%            y el capacitor elegido es = 20 nF
%
%  2) Se ingresa:   cgitod(1,10,20)
%
%  3) Se obtiene:
%                Etapa CGI Pasatodo
%                R = 7.87 kohm  QR = 78.7 kohm  C = 20 nF
%                                    
%        +----------------------/\/\/\----------------------------------------+
%        |                          R                    |`.      	          |  
%      	 |             +---------------------------------|+ `.     	          |
%        |             |                                 |    >--*---o V2     |    
%        |             |                            +----|- ,'   |            |
%        |             |                            |    |,'     |            |
%        |    C        |                  	C       | 	   	     |	          |
%   V1   |   | |       |        R           | |     |     R      |      R     |
%    o---*---| |-------*----/\/\/\----*-----| |-----*---/\/\/\---*---/\/\/\---*
%            | |       |              |     | |     |          	              |               
%                      /	          |      	    | 	 		              |
%                   QR \              |      .�|    |	                      |
%                      /              |    .� -|----+                         |  			                                               
%                     _|_             +---<    |                              |  			                                   
%                      -                   `. +|------------------------------+  			                                   
%  			                                 `.|                     			                           
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR, BGPJ, BGPA, BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     cgitod(fp,Q,Ho,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=cgitod(fp,Q,C)

% Se adecuan los datos:

fp=fp*1000;
C=C*1e-9;
C=cnor(C);
% Se calcula R
R=1/(2*pi*fp*C);

% Se calcula QR
QR=Q*R;
QR=rnor(QR,1);

% Se normaliza R
R=rnor(R,1);

% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa CGI Pasatodo'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('  QR'),exi(QR),fprintf('ohm')
fprintf('  C'),exi(C),fprintf('F'),fprintf('\n'),fprintf('\n')



