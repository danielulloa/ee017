%	CHEPBAJ es un programa que suministra los componentes L y C de 
%                    Filtros CHEBYSHEV PASIVOS PASABAJOS 
% 	ingresando: 
%       1) La frecuencia de corte de 3dB de la banda de paso
%       2) La frecuencia fa donde comienza la banda de atenuacion
%       3) La atenuacion maxima en la  banda de paso (El ripple)
% 	4) La atenuacion minima en la banda de atenuacion 
%       5) Las resistencias del generador y de la carga
%        
%       Consultar tambien CHEPBAJO que permite la sintesis ingresando
%       el orden n del filtro. 

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   15 de noviembre de 2016. Version 1.1


fprintf('----------    S�NTESIS DE FILTROS CHEBYSHEV PASIVOS PASABAJOS    ----------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')


% Ingresos de las frecuencias y las atenuaciones
f3dB=input('Ingresar la frecuencia de corte de 3dB en kHz: ');
fa=input('Ingresar la frecuencia de banda de atenuaci�n fa en kHz: ');
if f3dB >= fa
 fprintf(' En un filtro pasabajos la frecuencia de atenuaci�n es MAYOR que la frecuencia de corte'),fprintf('\n')
 fa=input('Ingresar nuevamente la frecuencia de banda de atenuaci�n fa en kHz: ');
else
end

Amax=input('Ingresar la Atenuaci�n m�xima en la banda de paso Amax en dB : ');
Amin=input('Ingresar la Atenuaci�n m�nima en la banda de atenuaci�n Amin en dB: ');
fprintf(' \n\n')

% Adecuacion de los datos ingresados
f3dB=f3dB*1000;
fa=fa*1000;
Amax=abs(Amax);
Amin=abs(Amin);
fp=f3dB;

% Determinacion del orden del filtro Chebyshev

% Se "mira en las curvas de atenuaci�n" con cual orden n 
% se cumple con la especificacion de Amin

e=sqrt(10^(Amax/10)-1);         % Epsilon: factor de ondulaci�n
for n=1:1000
  y=n;
  wnor3dB=cosh(acosh(1/e)/n);   % Frecuencia de normalizaci�n para que fc=f3dB
  fc=f3dB/wnor3dB;              % Frecuencia de corte normalizada a 3 dB
  fan=fa/fc;                    % Frecuencia de atenuaci�n normalizada
  Cnwa=cosh(n*acosh(fan));      % Valor del Polinomio de Chebyshev de orden n a fa normalizada
  AdBwa=10*log10(1+e^2*Cnwa^2); % Atenuaci�n a la frecuencia de atenuaci�n fa normalizada
  if AdBwa>=Amin,break,end      % Cuando la atenuacion del filtro es 
end                             % mayor que la Amin requerida se para el c�lculo
N=y;

fprintf('          * 2) Orden del filtro :'),exi(N),fprintf(' \n\n')


% 3.- Introducci�n de las resistencias del generador y de carga
fprintf('          * 3) Ingreso de las resistencias del generador y de carga   '),fprintf('\n')
R1=input('Ingresar la resistencia R1 del generador en Ohms:   ');
fprintf('\n')
fprintf(' Ingresar la resistencia R2 de carga en Ohms ') 
R2=input('(Si el orden del filtro es par, R2 no debe ser igual a R1) :   ');

if (R2==R1 & rem(N,2)==0)
 fprintf(' �Qu� le dije?. No sea cabez�n !!!!! ') 
 R2=input('(Ingresar R2 distinto de R1) :   ');
end



if R2>R1
% 4 Proporciona L y  C de un Filtro Chebyshev empezando por un inductor


if rem(N,2)==0
	%fprintf('Filtro Chebyshev de Orden par'),fprintf('\n')
	FacKn=4*R1*R2/(R1+R2)^2;
	
	e=sqrt(10^(Amax/10)-1);
	Kn=(1+e*e)*FacKn;

	if Kn>1
		Kn=1;
		e=sqrt(1/FacKn-1);
		else
		Kn=Kn;
	end
else
	%fprintf('     Filtro Chevyshev de Orden impar'),fprintf('\n')

		Kn=4*R1*R2/(R1+R2)^2;
		e=sqrt(10^(Amax/10)-1);

end

% 4.1 Normalizaci�n de frecuencia

wnor=cosh(acosh(1/e)/N);     % Frecuencia de normalizacion para que la frecuencia de 3dB sea 1
Wc=2*pi*fp/wnor;            % la frecuencia en Hz se pasa a pulsacion w en rad/seg. y se normaliza
      

%  4.2 Calculo de los componentes

a=(asinh(1/e))/N;
a1=(asinh(sqrt(1-Kn)/e))/N;

gama = pi / (2 * N);
L = zeros (1,N);
vector1 = zeros (1,N);

num = 2 * sin(gama)*R1;
div = (sinh(a) - sinh(a1))*Wc;
L(1)= num / div;

C = zeros(1,N);
vector2 = zeros(1,N);

top = 0;
i = 1;
while (i < N),
  top = top + 1;
  i = i + 2;
end

invWc2 = 1 / (Wc * Wc);


for m=1:top,
 
 g1 = gama * (4 * m - 3);
  g2 = gama * (4 * m - 1);
  num = invWc2 * 4 * sin(g1) * sin(g2);

  
  
  div = fm(2*m-1,a,a1,N);
  vector1(m)= num / div;
  C(2*m) = vector1(m) / L(2*m - 1);

  g4 = gama * (4 * m - 1);
  g5 = gama * (4 * m + 1);
  num = invWc2 * 4 * sin(g4) * sin(g5);

  
  div =  fm(2*m,a,a1,N);
  vector2(m) = num / div;
  L(2*m+1) = vector2(m) / C(2*m);
end;

% 4.3 Presentaci�n de los componentes en pantalla
fprintf('\n')
fprintf('          * 4) Componentes L y C del filtro   '),fprintf('\n\n')
fprintf(' Se indican valores normalizados entre par�ntesis.'),fprintf('\n')
fprintf(' Capacitores al 5 por ciento, inductores al 1 por ciento.'),fprintf('\n\n')
fprintf(' El filtro comienza con un inductor en serie con R1'),fprintf('\n\n')


fprintf(' Inductores entre capacitores :')
fprintf(' \n\n')

L=elicn(L);
for i=1:length(L)
    fprintf('    L'),exi(L(i)),fprintf('H'),fprintf('   (Ln'),exi(lnor(L(i))),fprintf('H)'),fprintf(' \n\n')
end

fprintf(' Capacitores a masa:')
fprintf(' \n\n')

C=elicn(C);
for i=1:length(C)
    fprintf('   C'),exi(C(i)),fprintf('F'),fprintf('   (Cn'),exi(cnor(C(i))),fprintf('F)'),fprintf(' \n\n')
end



else
% 5. Proporciona L y  C de un Filtro Chebyshev empezando por un capacitor


if rem(N,2)==0
	%fprintf('       Filtro Chebyshev de Orden par'),fprintf('\n')
	FacKn=4*R1*R2/(R1+R2)^2;
	
	e=sqrt(10^(Amax/10)-1);
	Kn=(1+e*e)*FacKn;

	if Kn>1
		Kn=1;
		e=sqrt(1/FacKn-1);
		else
		Kn=Kn;
	end
else
	%fprintf('      Filtro Chevyshev de Orden impar'),fprintf('\n')

		Kn=4*R1*R2/(R1+R2)^2;
		e=sqrt(10^(Amax/10)-1);

end

% 5.1 Normalizaci�n de frecuencia

wnor=cosh(acosh(1/e)/N);        % Frecuencia de normalizacion para que la frecuencia de 3dB sea 1
Wc=2*pi*fp/wnor;                % se pasa la frecuencia en Hz a pulsacion w en rad/seg.
                
% 5.2 Calculo de los componentes

a=(asinh(1/e))/N;
a1=(asinh(sqrt(1-Kn)/e))/N;

gama = pi / (2 * N);

C = zeros (1,N);
vector1 = zeros (1,N);

num = 2  * sin(gama);
div = (sinh(a) - sinh(a1))*Wc*R1;
C(1)= num / div;

L = zeros(1,N);
vector2 = zeros(1,N);

top = 0;
i = 1;
while (i < N),
  top = top + 1;
  i = i + 2;
end

invWc2 = 1 / (Wc * Wc);


for m=1:top,
 
 g1 = gama * (4 * m - 3);
  g2 = gama * (4 * m - 1);
  num = invWc2 * 4 * sin(g1) * sin(g2);

  
  
  div = fm(2*m-1,a,a1,N);
  vector1(m)= num / div;
  L(2*m) = vector1(m) / C(2*m - 1);

  g4 = gama * (4 * m - 1);
  g5 = gama * (4 * m + 1);
  num = invWc2 * 4 * sin(g4) * sin(g5);

  
  div =  fm(2*m,a,a1,N);
  vector2(m) = num / div;
  C(2*m+1) = vector2(m) / L(2*m);
end;

% 5.3 Presentaci�n de los componentes en pantalla
fprintf('\n')
fprintf('          * 4) Componentes L y C del filtro   '),fprintf('\n\n')
fprintf(' Se indican valores normalizados entre parentesis.'),fprintf('\n')
fprintf(' Capacitores al 5 por ciento, inductores al 1 por ciento.'),fprintf('\n\n')
fprintf(' El filtro comienza a partir de R1 con un capacitor a masa'),fprintf('\n\n')

fprintf(' Capacitores a masa:')
fprintf(' \n\n')

C=elicn(C);
for i=1:length(C)
    fprintf('   C'),exi(C(i)),fprintf('F'),fprintf('   (Cn'),exi(cnor(C(i))),fprintf('F)'),fprintf(' \n\n')
end

fprintf(' Inductores entre capacitores :')
fprintf(' \n\n')

L=elicn(L);
for i=1:length(L)
    fprintf('    L'),exi(L(i)),fprintf('H'),fprintf('   (Ln'),exi(lnor(L(i))),fprintf('H)'),fprintf(' \n\n')
end


end

fprintf('----------    Fin del c�lculo de L y C del Filtro Chebyshev Pasivo Pasabajos    ----------'),fprintf('\n')
