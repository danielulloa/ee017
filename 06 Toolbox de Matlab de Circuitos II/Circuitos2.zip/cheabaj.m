%	CHEABAJ es un programa que suministra fp y Q para el proyecto de
%                    Filtros CHEBYSHEV ACTIVOS PASABAJOS 
% 	ingresando: 
%       1) La frecuencia de corte de 3dB de la banda de paso
%       2) La frecuencia fa donde comienza la banda de atenuaci�n
%       3) La atenuacion m�xima en la  banda de paso (El ripple)
% 	    4) La atenuacion m�nima en la banda de atenuacion 
%        
%       Consultar tambien CHEABAJO que permite el proyecto INGRESANDO 
%       el orden n del filtro.

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1

fprintf('----------    PROYECTO DE FILTROS CHEBYSHEV ACTIVOS PASABAJOS    -----------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')
% Puesta a cero de los vectores

Qpolo=[];
Wpolo=[];
Wcero=[];
Wpolo3dB=[];
p1=[];
p2=[];

% Ingresos de las frecuencias y las atenuaciones
f3dB=input('Ingresar la frecuencia de corte de 3dB en kHz:   ');
fa=input('Ingresar la frecuencia de banda de atenuaci�n fa en KHz:   ');
Amax=input('Ingresar riple m�ximo en la banda de paso Amax en dB :   ');
Amin=input('Ingresar la atenuacion m�nima en la banda de atenuacion Amin en dB:   ');
f3dB=f3dB*1000;
fa=fa*1000;
Amax=abs(Amax);
Amin=abs(Amin);
fprintf(' \n\n')
% Determinaci�n del orden del filtro Chebyshev

e=sqrt(10^(Amax/10)-1);
for n=1:10000
  y=n;
  W3dB=cosh(acosh(1/e)/n);
  fc=f3dB/W3dB;
  fan=fa/fc;
  Cnwa=cosh(n*acosh(fan));
  AdBwa=10*log10(1+e^2*Cnwa^2);
  if AdBwa>=Amin,break,end
end
n=y;


fprintf('          * 2) Orden del filtro '),exi(n),fprintf(' \n\n')


% C�lculo de los polos del filtro de Chebyshev
j = sqrt(-1);
epsilon = sqrt(10^(.1*Amax)-1);
mu = asinh(1/epsilon)/n;
p = exp(j*(pi*(1:2:2*n-1)/(2*n) + pi/2));
p = sinh(mu)*real(p) + j*cosh(mu)*imag(p);
z = []; % No tiene ceros este filtro en su funci�n de transferencia
k = real(prod(-p));
p=cplxpair(p);
e=epsilon;

% Frecuencia de normalizaci�n de 3 dB

W3dB=cosh(acosh(1/e)/n);

% De los polos agrupados en funciones de 2 orden, se obtiene el Q y la frecuencia

if rem(n,2)~=0   % Si el orden es impar
np=length(p)-1;

  for i=1:2:np
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    Wpolo3dB(i)=Wpolo(i)/W3dB*f3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
  end

poloreal=p(length(p));

else
np=length(p);     % Si el orden es par
  for i=1:2:np
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    Wpolo3dB(i)=Wpolo(i)/W3dB*f3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
  end
poloreal=[];
end

% Presentaci�n de los resultados en pantalla

fprintf('          * 3) fp y Q de cada etapa:'),fprintf(' \n')
fprintf(' \n\n')
fpolo=elicero(Wpolo3dB);
fpolo;
Qpolo=elicero(Qpolo);
for i=1:length(fpolo)
      
      fprintf('fp'),exi(fpolo(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo(i))
      fprintf(' \n\n')
end

fpreal=abs(poloreal)/W3dB*f3dB; % La frecuencia del polo real que falta 

if rem(n,2)~=0
 fprintf('fp etapa de primer orden'),exi(fpreal),fprintf('Hz'),fprintf('\n')
end

fprintf('\n')

fprintf('-------    Fin del c�lculo de fp y Q del Filtro Chebyshev Activo Pasabajos    -------------------------------------------------------'),fprintf('\n')

  