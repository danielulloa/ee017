% BUTPBAJP sirve obtener los componentes L y C de un filtro 
% Butterworth Pasivo pasaBajos Prototipo (o normalizado).
% A partir del filtro prototipo y utilizando las funciones
% paalt, pabaj, paban y pasup del Toolbox de Circuitos II
% se pueden obtener los filtros Butteworth 
% pasaaltos, pasabajos, pasabanda y suprimebanda 
% a la frecuencia de trabajo o filtros desnormalizados.

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.2

fprintf('***** Filtros Butterworth Prototipo  ****'),fprintf('\n')

% Ingreso de datos
N=input('Ingresar el orden del filtro Butterworth:   ');
R1=input('Ingresar la resistencia R1 del generador:   ');
R2=input('Ingresar la resistencia R2 de carga:   ');
Wc=1;

if R2>R1
% Proporciona L y  C de un Filtro Butterworth
% si se le introduce R1, R2, Wc, y N, empezando por un inductor

RR=R2/R1;
Alfa=((RR-1)/(RR+1))^(1/N);
gama = pi / (2 * N);

L = zeros (1,N);
vector1 = zeros (1,N);

num = 2 * R1 * sin(gama);
div = (1 - Alfa)*Wc;
L(1)= num / div;

C = zeros(1,N);
vector2 = zeros(1,N);

top = 0;
i = 1;
while (i < N),
  top = top + 1;
  i = i + 2;
end

invWc2 = 1 / (Wc * Wc);
alfa2 = Alfa * Alfa;

for m=1:top,
  g1 = gama * (4 * m - 3);
  g2 = gama * (4 * m - 1);
  num = invWc2 * 4 * sin(g1) * sin(g2);

  g3 = gama * (4 * m - 2);
  div = 1 - (2 * Alfa * cos(g3)) + alfa2;
  vector1(m)= num / div;
  C(2*m) = vector1(m) / L(2*m - 1);

  g4 = gama * (4 * m - 1);
  g5 = gama * (4 * m + 1);
  num = invWc2 * 4 * sin(g4) * sin(g5);

  g6 = gama * 4 * m;
  div = 1 - (2 * Alfa * cos(g6)) + alfa2;
  vector2(m) = num / div;
  L(2*m+1) = vector2(m) / C(2*m);
end;
fprintf('El filtro comienza con un inductor en serie con R1'),fprintf('\n')

fprintf('Inductores en serie:')
L=elicero(L);
L
fprintf('Capacitores a masa:')
C=elicero(C);
C

else
% Proporciona L y  C de un Filtro Butterworth
% si se le introduce R1, R2, Wc, y N, empezando por un capacitor


RR=R2/R1;
Alfa=((1-RR)/(RR+1))^(1/N);
gama = pi / (2 * N);

C = zeros (1,N);
vector1 = zeros (1,N);

num = 2 * sin(gama);
div = (1 - Alfa)*Wc*R1;
C(1)= num / div;

L = zeros(1,N);
vector2 = zeros(1,N);

top = 0;
i = 1;
while (i < N),
  top = top + 1;
  i = i + 2;
end

invWc2 = 1 / (Wc * Wc);
alfa2 = Alfa * Alfa;

for m=1:top,
  g1 = gama * (4 * m - 3);
  g2 = gama * (4 * m - 1);
  num = invWc2 * 4 * sin(g1) * sin(g2);

  g3 = gama * (4 * m - 2);
  div = 1 - (2 * Alfa * cos(g3)) + alfa2;
  vector1(m)= num / div;
  L(2*m) = vector1(m) / C(2*m - 1);

  g4 = gama * (4 * m - 1);
  g5 = gama * (4 * m + 1);
  num = invWc2 * 4 * sin(g4) * sin(g5);

  g6 = gama * 4 * m;
  div = 1 - (2 * Alfa * cos(g6)) + alfa2;
  vector2(m) = num / div;
  C(2*m+1) = vector2(m) / L(2*m);
end;

fprintf('El filtro comienza con un capacitor a masa en el nodo con R1'),fprintf('\n')

fprintf('Capacitores a masa:')
C=elicero(C);
C
fprintf('Inductores en serie:')
L=elicero(L);
L
end


fprintf('------ Fin del c�lculo de Filtros Butterworth Prototipo  -----'),fprintf('\n')