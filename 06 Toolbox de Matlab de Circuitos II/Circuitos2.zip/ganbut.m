% GANBUT Caracter�sticas de GANancia de filtros BUTterworth.
% es una funci�n que por omisi�n representa representa 
% la respuestas de filtros de orden 1 al 9.
% Si se ingresa el orden del filtro: cabut(n)
% representa la respuesta de un filtro Butteworth de orden n.
% Ejemplo campana(*): ganbut(12) representa la respuesta de orden 12.
 
% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   7 de Julio de 2002. Version 1.0

function []=ganbut(orden)

% Si se ingresa el orden, verificar que no supere 64
% �Qui�n necesita un filtro Butt de ese orden?

if nargin==1 
	if orden > 64
        error(' � El orden del filtro debe ser menor que 64 !.')
	end
end

figure; clf;% Se fija la est�tica del display
figure(gcf)
set(gcf, 'defaultaxesfontsize', 14)
set(gcf, 'defaulttextfontsize', 14)
set(gcf, 'defaultlinelinewidth', 1.5)
set(gcf, 'defaultlinemarkersize', 10)
% Frecuencia de corte de 3 dB del filtro (en Hz)
fc=1;wc=fc*2*pi; % pulsaci�n de corte
% Para dibujar las lineas en colores
colormap(lines);
color_map=colormap;
colormap('default');
leyenda=' ';

% Se genera el barrido de frecuencia que 
% produce un gr�fico que se inicia dos d�cadas antes
% y termina dos d�cadas despues de la frecuencia de corte.
inicio=floor(log10(fc/100));final=ceil(log10(fc*100));indice=[inicio:.01:final];w=2*pi*(10.^indice);
% Selecci�n en funci�n del argumento de entrada
% Se dibujan varias o una sola dependiendo de si se ingres� el orden
if nargin<1        % Sin argumentos se dibujan 9 curvas curvas 
Nmin=1; Nmax=9;
else
Nmin=orden;Nmax=orden;  % Se dibuja s�lo la curva del orden pedido
end

% Se grafican las curvas de respuesta en frecuencia de orden N
for n=Nmin:Nmax	[b,a]=butter(n,wc,'s');	[hf,w]=freqs(b,a,w);	%semilogx(w/(2*pi),20*log10(abs(hf))); % En azul	semilogx(w/(2*pi),20*log10(abs(hf)),'color',color_map(n,:)); % En varios colores
	hold on; grid on; zoom on; drawnow;	leyenda=strcat(leyenda,sprintf('N=%g',n)');
	
end;

% Titulos de la figura

% T�tulo global en la figura
title('Caracter�sticas de Amplitud de Filtros Butterworth');

% T�tulos de los ejes de la figura
xlabel('f_n \rightarrow'); ylabel('Amplitud [dB] \rightarrow');

% Recuadro de la leyenda
if nargin<1             % Todas la curvas: en la esquina abajo a la izquierda 
legend(leyenda',3);
else
legend(leyenda',1); % Una sola: en la esquina de arriba a la derecha
end

% Subt�tulos de Teor�a de Circuitos II y la fecha
titulos


%(*) Ejemplo "campana": Ejemplo "Tan Ton-t�n"







   
