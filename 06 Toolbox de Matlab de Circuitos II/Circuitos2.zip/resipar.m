% RESIPAR Proporciona el residuo cuando se extrae parcialmente un polo
% para lo cual se se ingresa el numerador ni y denominador di de la Inmitancia
% y el polo para el cual se le calcula el residuo

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


function [kpar]=resipar(ni,di,polo)

p0=poly(0);
ni0=deconv(ni,p0);
nie=polyval(ni0,polo);
die=polyval(di,polo);
kpar=nie/die;         % Residuo de remocion parcial de polo







