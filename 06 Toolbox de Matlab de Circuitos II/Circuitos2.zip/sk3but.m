% SK3BUT es una funci�n que proporciona los
% valores de los capacitores C1,C2 y C3 de un FILTRO 
% *** Sallen-Key de 3�orden Butterworth Pasabajo  ***
% cuando se le ingresa en este orden:            Ojo con las unidades)
%                      1) La frecuencia del corte fc en kHz
%                      3) Un valor de la resistencia R en kohm
%				                      | | C3     
%                             +-------| |-------*------------+
%                             |       | |       |            |
%                             |                 |            |
%                             |           	    |	         |
%                             |                 |   |`.      |
%                             |                 + --|- `.    |      
%           R            R    |     R               |    >---*---o V2 
% V1 o---/\/\/\---*---/\/\/\--*--/\/\/\---*---------|+ ,'  
%                 |                       |         |,'     
%                 |                       |      
%               __|__                   __|__    
%               _____  C1           C2  _____             
%                 |                       |     
%                 |                       |     
%                _|_                     _|_      
%                 -                       -
%
% Por ejemplo:   sk3but(4,10.3) proporciona:
%
%  Filtro Sallen-Key de 3�orden Butterworth Pasabajo
%  C1 = 5.6 nF  C2 = 0.82 nF  C3 = 13 nF
%  Se adopt�: R = 10.2 kohm
%
%  Ver tambi�n: BICUA, KRCI, KRCK2, PBDA, PTA1, PTA2, PTP1, PTP2,
%               POLOSKRC, PRIMOR, PRIMORK, RANDTA, RANDTP, RANSL,
%               RM, SK, SK3BUTA,SKPA, VAEI y VAENOI 
%
%  Introducir     sk3but(fc,R)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1

function y=sk3but(fc,R)

% Adecuaci�n de los datos
fc=fc*1000;
R=R*1000;
% Se elige una resistencia normalizada
% si en la entrada no se lo ha hecho
Rn=rnor(R,1);
den=(2*pi*fc*Rn);

% C�lculo del Capacitor C1
	C1=1.39265/den;
	C1n=cnor(C1);
% C�lculo del Capacitor C2
	C2=0.202451/den;
	C2n=cnor(C2);
% C�lculo del Capacitor C3
	C3=3.54682/den;
	C3n=cnor(C3);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('  Filtro Sallen-Key de 3�orden Butterworth Pasabajo'),fprintf('\n')
fprintf('  C1'),exi(C1n),fprintf('F')
fprintf('  C2'),exi(C2n),fprintf('F')
fprintf('  C3'),exi(C3n),fprintf('F'),fprintf('\n')
fprintf('  Se adopt�: R'),exi(Rn),fprintf('ohm')
fprintf('\n')
fprintf('\r')



