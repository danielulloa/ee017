% KRCG1 los valores de las resistencias y capacitores
% de una etapa KRC de 2� orden con Ganancia unitaria
% cuando se le ingresa:                    (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa 
%                      3) El valor del capacitor en nF y
%                      4) El valor de la Resistencia RA en kohm 
%                      
%                                  | | C     
%                    +-------------| |---------------+
%                    |             | |               |   
%                    |                               |   
%             R1a    |      R               |`.      |   
%    V1 o---/\/\/\---*---/\/\/\---*---------|+ `.    |       
%                    |            |         |    >---*---o V2
%                    \          __|__   +---|- ,'    |       
%               R1b  /       C  _____   |   |,'      |       
%                    \            |     |            |       
%                   _|_          _|_    *---/\/\/\---+       
%                    -            -     |     RB     
%                                       /        
%                                       \ RA       
%                                       /          
%                                      _|_        
%  Ejemplo:                             -
%
%  1)Datos:    Si fp= 2000 Hz, Q= 8, C= 10 nF y RA= 5kohm
%
%  2)Se ingresa:   krcg1(2,8,10,5) 
%
%  3)Se obtiene:   
%               Filtro KRC de ganancia unitaria 
%               R1a = 22.6 kohm  R1b = 12.1 kohm  R = 7.87 kohm
%               RB = 9.31 kohm.  Se adopt� RA = 4.99 kohm y C = 10 nF
%              
%  Ver tambi�n BICUA, KRCK2, PBDA, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     krcg1(fp,Q,C,RA)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   8 de Octubre de 2002. Version 1.1

function y=krcg1(fp,Q,C,RA)

fp=fp*1000;
C=C*1e-9;
C=cnor(C);
RA=RA*1000;
RA=rnor(RA,1);
% C�lculo de los componentes

R=1/(2*pi*fp*C);
K=3-1/Q;

% C�lculo de R1a
R1a=K*R;
%C�lculo de R1b
R1b=K*R/(K-1);

%C�lculo de RB
RB=(K-1)*RA;

% Valores normalizados
R=rnor(R,1);
RB=rnor(RB,1);
R1a=rnor(R1a,1);
R1b=rnor(R1b,1);

% Presentaci�n de los resultados
fprintf('\r')
fprintf('    Filtro KRC de ganancia unitaria \n')
fprintf('    R1a'),exi(R1a),fprintf('ohm')
fprintf('  R1b'),exi(R1b),fprintf('ohm')
fprintf('  R'),exi(R),fprintf('ohm'),fprintf('\n')
fprintf('    RB'),exi(RB),fprintf('ohm.'),fprintf('  Se adopt� RA'),exi(RA),fprintf('ohm')
fprintf(' y C'),exi(C),fprintf('F')
fprintf('\n')
fprintf('\r')


