function titulos
% TITULOS es una funci�n que pone t�tulos en los gr�ficos
% con el nombre de Teor�a de Circuitos II y en subt�tulos la fecha

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   3 de Julio del 2002. Version 1.0

axes('Position',[.01 .01 .98 .05],'Visible','off');

% T�tulo de la ventana de la figura
set(gcf,'numbertitle','off','name','Teor�a de Circuitos II')

% Posici�n Abajo
%titulo = text(.04,.5,'Teor�a de Circuitos II'); 
fecha = text(.86,.5,date);  %text(.30,.5,date);

% Posici�n Arriba
%titulo = text(.04,19.5,'Teor�a de Circuitos II'); 
%fecha = text(.86,19.5,date);  %text(.30,.5,date);

% Tama�o de las fuentes
%set(titulo,'FontSize',10);
set(fecha,'FontSize',10);

    
    
