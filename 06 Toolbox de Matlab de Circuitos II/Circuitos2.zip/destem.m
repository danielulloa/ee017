%  DESTEM proporciona los par�metros DEScriptores        
%  TEMporales de la respuesta al escal�n de una transferencia
%  cuando se le ingresa los vectores fila de los coeficientes 
%  del numerador y el denominador de la funci�n de transferencia
%  
%   Ejemplo:                                                             
%   1) Datos:  
%                        400000000
%		  H(s)=  ------------------------
%                s^2 + 8500 s + 404000000
%
%   2) Se ingresa:  num=[400000000];
%                   den=[1 8500 400000000];
%                   destem(num, den)
%   3) se obtiene:
%
%  Tiempo del Pico = 0.16 ms
%  Porcentaje de Sobrepaso = 50.4945 por ciento
%
%  Tiempo de crecimiento = 61.1765 �s
%  Tiempo de establecimiento = 0.851765 ms
%
% Ingresar destem(num, den)
                                                          
%  � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1                                                                  
 
function destem(num, den)
m=length(num);n=length(den);
r=roots(den); r=(real(r));
nr=length(r);
for i=1:nr-1
      if r(i) >=0  disp('� Respuesta no acotada !'), return
      else, end
end
rp=abs(real(r)); i=find(rp>0); rn0=rp(i);
rmn=min(rn0); tf=10/rmn; dt=tf/1000;

Css=num(m)/den(n);
if Css==inf
   disp('� Respuesta no acotada !')
   return,else end

t=0:dt:tf;
l=length(t);

c=step(num, den, t);

if c(l) > Css+0.1*Css | c(l) < Css-0.1*Css
disp(' � Respuesta no acotada !'),return
else,end

j=0 ;m =0;
Cmax=max(c);

if Cmax > Css
   po= (Cmax - Css)/Css * 100;
   i=find(c==Cmax); tp=t(i); else,tp=0; end

if tp < 10*dt & tp>0
   tf=round(10*tp); dt=tf/200;
   t=0:dt:tf;
   l=length(t);
   c=step(num, den, t);
   j=0 ;m =0;
   Cmax=max(c);
else, end
if Cmax > Css
   po= (Cmax - Css)/Css * 100;
   i=find(c==Cmax); tp=t(i);
   fprintf('\n'),
fprintf('  Tiempo del Pico'),exi(tp),fprintf('s'),fprintf('\n'),
fprintf('  Porcentaje de Sobrepaso'),exi(po),fprintf('por ciento'),fprintf('\n'),
else, tp=0;end

     for i =1:l
          if  j == 0
              if c(i) >= 0.1*Css  t1=t(i); j=1;
              end
          else, end
          if  m ==0
              if c(i) >= 0.9*Css  t9 = t(i); m =1;
              end
          else, end
      end
      %end
if t9 ~= 0
  tr = t9 -t1;
fprintf('\n')
fprintf('  Tiempo de Crecimiento'),exi(tr),fprintf('s'),fprintf('\n')
end
if tp > tr  t0=tp; else t0=tr; end

tfu=1.02*Css; tfd=.98*Css;
ts1=0;ts2=0;
for i=1:l
 if t(i) >t0 & t(i) <tf
    if c(i) >= tfu  ts1=t(i); else, end
    if c(i) <= tfd  ts2=t(i); else, end
    else,end
end
ts=max(ts1,ts2);
fprintf('  Tiempo de Establecimiento'),exi(ts),fprintf('s'),fprintf('\n\n')

