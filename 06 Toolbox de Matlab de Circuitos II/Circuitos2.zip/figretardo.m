% FIGRETARDO Dibuja las respuesta de retardo 
% de grupo de una funcion bicu�dratica

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   08 de Julio de 2002. Version 1.0

syms s num den            
syms w Q real; % Se declaran w y Q como variables reales
num = s^2 - (1/Q) *s + 1; % numerador of H(s)   
den = s^2 + (1/Q) *s + 1; % denominador of H(s)     
s = j*w; 
num = subs(num); % substituir s = jw en el numerador       
den = subs(den); % substitutir s = jw in the denominador    
R = real(num / den); % parte real of H(jw) 
I = imag(num / den); % parte imaginaria of H(jw)     
phase = atan(I/R); % respuesta de fase    
gdelay = - diff(phase,w); % retardo de grupo
disp('retardo de grupo = '); pretty(simplify(gdelay));          
   

figure; clf;
% % Se prepara y establece la presentaci�n de la figura
figure(gcf)
set(gcf, 'defaultaxesfontsize', 14)
set(gcf, 'defaulttextfontsize', 14)
set(gcf, 'defaultlinelinewidth', 1.5)
set(gcf, 'defaultlinemarkersize', 10)

% Gr�fico del retardo de grupo para varios valores de Q

% Para dibujar las lineas en colores
colormap(lines);
color_map=colormap;
colormap('default');


w=[0:0.01:2.5];
%figure;
%hold on;

indice=1;
for Q = [0.02, 0.1, 0.3, 0.5, 0.57735,2,5, 20, 50]
      
      N = 2*Q*(w.^2 +1);
      D = (w.^4)*(Q^2) + (1 - 2 * Q^2)*(w.^2) + Q^2;
      plot(w,log10(N./D),'color',color_map(indice,:))      hold on; grid on; zoom on; drawnow;
      
      indice=indice+1;
end

% Titulos de la figura

% T�tulo global en la figura
title('Retardos normalizados de una transferencia bicuadr�tica');
% T�tulos de los ejes de la figura
xlabel('\omega \rightarrow','FontSize',14)
ylabel('\tau_d(\omega) \rightarrow','FontSize',14)

% Recuadro de la leyenda
legend('0.02','0.1','0.3','0.5','0.58','2','5','20','50'); % que funciona
set(axes('position',[0 0 1 1]),'visible','off')
text(.67,0.86,'Q \rightarrow');

% Titulos de Teor�a de Circuitos II y la fecha
titulos
