% COMPFILTROS proporciona un gr�fico en el que se comparan las 
% respuestas en frecuencia de 4 tipos de filtros cuando los
% cuatro satisfacen la condici�n del mismo ancho de la banda 
% de paso y atenuaci�n Am�x en la banda de paso **********

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   7 de Julio de 2002. Version 1.0

% Se prepara y establece la presentaci�n de la figura
figure; clf;
figure(gcf)
set(gcf, 'defaultaxesfontsize', 14)
set(gcf, 'defaulttextfontsize', 14)
set(gcf, 'defaultlinelinewidth', 1.5)
set(gcf, 'defaultlinemarkersize', 10)

% Se estable cel Orden de los filtros 
N=5;

% Frecuencia de corte de la banda de paso en Hz
fc=1000;
wc=fc*2*pi;
% Barrido de frecuencia para la representaci�n.
% Se toma dos d�cadas antes y dos d�cadas despues
% de la frecuencia de corte
inicio=floor(log10(fc/100));
final=ceil(log10(fc*100));
indice=[inicio:.01:final];
w=2*pi*(10.^indice);

% Se definen las atenuaciones:
% 1 Atenuaci�n m�xima en la banda de paso (en dB)
Amax=3; % Para que se vea bien en el gr�fico se
        % puede elegir 10 dB en vez de 3 dB 
% 2 Atenuaci�n m�nima en la banda de atenuaci�n (en dB)
Amin=100;

% Las respuestas de los cuatro filtros

% 1 Respuesta Butterworth
[b,a]=butter(N,wc,'s');
[hf,w]=freqs(b,a,w);
% Se encuentra la frecuencia a la cual se produce la atenuaci�n Am�n
[muda,indice]=min(abs(20*log10(abs(hf))+Amax));
% Se calcula el factor de normalizaci�n 
norm=wc/w(indice);
% Se calcula y grafica la respuesta del filtro Butterworth
[b,a]=butter(N,wc*norm,'s');
[hf,w]=freqs(b,a,w);
semilogx(w/(2*pi),20*log10(abs(hf)),'b');
hold on; zoom on; grid on; drawnow;

% 2 Respuesta Chebyshev tipo I
[b,a]=cheby1(N,Amax,wc,'s');
[hf,w]=freqs(b,a,w);
% Se busca la frecuencia a la cual se produce la atenuaci�n deseada
[muda,indice]=min(abs(20*log10(abs(hf))+Amax));
% Se calcula el factor de normalizaci�n 
norm=wc/w(indice);
norm=wc/w(indice);
% Se calcula y grafica la respuesta del filtro Chebyshev I
[b,a]=cheby1(N,Amax,wc*norm,'s');
[hf,w]=freqs(b,a,w);
semilogx(w/(2*pi),20*log10(abs(hf)),'r');
hold on; zoom on; grid on; drawnow;

% 3 Filtro Chebyshev Tipo II
[b,a]=cheby2(N,Amin,wc,'s');
[hf,w]=freqs(b,a,w);
% Se busca la frecuencia a la cual se produce la atenuaci�n deseada
[muda,indice]=min(abs(20*log10(abs(hf))+Amax));
% Se calcula el factor de normalizaci�n
norm=wc/w(indice);
% Se calcula y grafica la respuesta del filtro Chebyshev II
[b,a]=cheby2(N,Amin,wc*norm,'s');
[hf,w]=freqs(b,a,w);
semilogx(w/(2*pi),20*log10(abs(hf)),'g');
hold on; zoom on; grid on; drawnow;

% 4 Filtro el�ptico
[b,a]=ellip(N,Amax,Amin,wc,'s');
[hf,w]=freqs(b,a,w);
% Se busca la frecuencia a la cual se produce la atenuaci�n deseada
[muda,indice]=min(abs(20*log10(abs(hf))+Amax));
% Se calcula el factor de normalizaci�n
norm=wc/w(indice);
% Se calcula y grafica la respuesta del filtro El�ptico
[b,a]=ellip(N,Amax,Amin,wc*norm,'s');
[hf,w]=freqs(b,a,w);
semilogx(w/(2*pi),20*log10(abs(hf)),'m');
hold on; zoom on; grid on; drawnow;
[minimo,indice]=min(20*log10(abs(hf)));


% Grafica la m�scara
% Para que las rayas de la m�scara salgan delicadas
set(gcf, 'defaultlinelinewidth', 1.5)
%semilogxmask([fc -1000 fc -Amax;fc -Amax fc/1000 -Amax;...
%   fc/1000 -Amax fc/1000 -1000; fc/1000 -1000 fc -1000],1);

% Trazado de las l�neas que marcan los l�mites de Amin y Amax

% Linea horizontal que marca los 0 dB
% de la Banda de Paso. Lo levanto un poco para que se vean
% las trazas de las respuestas
plot([fc/100 fc*1],[ -0.1 -0.1],'b:');

% Linea horizontal que marca la Atenuaci�n m�xima 
% de la Banda de Paso
plot([fc/100 fc*1],[ -Amax -Amax],'b:');

% Linea horizontal que marca la Atenuaci�n m�nima 
% de la Banda de Atenuaci�n
plot([fc/1 fc*100],[ -Amin -Amin],'b:');
set(gcf, 'defaultlinelinewidth', 1.5)

% Linea vertical que indica el ancho de la banda de Paso
plot([fc fc],[-Amin 0],'b:');
set(gcf, 'defaultlinelinewidth', 1.5)

% Titulos de la figura

% T�tulo global en la figura
title('Comparaci�n de filtros que tienen la misma Banda de Paso');

% T�tulos de los ejes de la figura
xlabel('Frecuencia [Hz])');ylabel('Amplitud [dB]');

% Recuadro de Leyenda
legend('Butterworth','Chebyshev I','Chebyshev II','El�ptico',1)

% Subt�tulos de Teor�a de Circuitos II y la fecha
titulos