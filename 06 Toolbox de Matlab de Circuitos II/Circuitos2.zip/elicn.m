% ELICN Funcion que elimina los valores cero y negativos de un vector

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0



function [Y] = elicn(X)


Y = [];
for i=1:length(X)
if (X(i))>0,       
    Y = [Y X(i)];
    i = i + 1;
end
end