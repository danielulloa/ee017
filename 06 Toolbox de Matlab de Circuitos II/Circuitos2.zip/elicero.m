% ELICERO elimina los valores cero y negativos de un vector
% Puede ser eliminada pues est� reemplazada por elicn.m
% una vez verificado el cambio el las funciones que la usan

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0




function [Y] = elicero (X)

L=length(X);  
for i=1:L
if (X(i))>0     % Para eliminar los valores negativos
  Z(i)=X(i);
end
end
Y = [];
for i=1:length(Z)
if (Z(i))>0,       % Para eliminar los valores cero
    Y = [Y Z(i)];
    i = i + 1;
end
end