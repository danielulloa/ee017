% SK2 es una funci�n que proporciona los valores de:
% las Resistencias y Capacitores de una etapa activa 
% PASABAJOS SALLEN KEY de 2� orden de resistencias iguales 
% cuando se le ingresa:                          Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa y 
%                      3) Un valor de la resistencia R en kohm
%   			             | | C1         	 	     
%                    +-------| |--------*------------+     
%                    |	     | |	    |            |
%                    |                  |   |`.      |       
%                    |                  +---|- `.    |       
%              R     |      R               |    >---*---o V2
%    V1 o---/\/\/\---*---/\/\/\---*---------|+ ,'            
%                                 |         |,'                  
%                               __|__         
%                            C2 _____        
%                                 |              
%                                _|_           
%  Ejemplo:                       -                                      
%  
%  1) Datos:  Si fp= 10000 Hz, Q= 0.707 y R= 10 kohm
%
%  2) Se ingresa:   sk2(10,0.707,10) 
%
%  3) Se obtiene:  R = 10 kohm  C1 = 2.2 nF  C2 = 1.1 nF   
%
%  Ver tambi�n: BICUA, KRCI, KRCK2, PBDA, PTA1, PTA2, PTP1, PTP2,
%               POLOSKRC, PRIMOR, PRIMORK, RANDTA, RANDTP, RANSL,
%               RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     sk2(fp,Q,R)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   8 de Octubre de 2002. Version 1.0

function y=sk2(fp,Q,R)

% Adecuaci�n de los datos
fp=fp*1000;
R=R*1000;
R=rnor(R,1);

% C�lculo de C1
C1=Q/(pi*fp*R);
C1=cnor(C1);

% C�lculo de C2
C2=1/(4*pi*fp*R*Q);
C2=cnor(C2);


% Presentaci�n de los resultados
fprintf('\n')
fprintf('  Etapa Sallen-Key de resistencias iguales'),fprintf('\n')
fprintf('  R'),exi(R),fprintf('ohm')
fprintf('  C1'),exi(C1),fprintf('F')
fprintf('  C2'),exi(C2),fprintf('F')
fprintf('\n')
fprintf('\r')



