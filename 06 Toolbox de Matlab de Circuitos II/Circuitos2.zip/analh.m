% ANALH permite realizar el an�lisis de una red dada por 
% su funci�n de transferencia H(s) definida PREVIAMENTE en Simulink.
% utilizando:
%          1) Los gr�ficos de respuesta en frecuencia y
%             Los par�metros descriptores de la respuesta en frecuencia
%          2) El gr�fico de la respuesta a escal�n y
%             los par�metros descriptores de la respuesta al escal�n
%          3) El diagrama de polos y ceros de H(s)
%          4) El gr�fico de Nyquist
%          5) El gr�fico de Nichols 
%          6) El lugar de la raices 
%          7) El an�lisis de Routh de Numerador y denominador de H(s)
%          8) Los valores de magnitud y fase de la respuesta en frecuencia
%          
%   *** ANALH solicita el nombre de la H(s) definida en SIMULINK
%   Para crear una transferencia a partir de un plantilla hacer:
%   >> modeloh


% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   9 de Julio de 2002. Version 1.0

% Obtenci�n del modelo en Matlab de la funcion de transferencia del Simulink

% Sonido de Bienvenida
[y]=wavread('ding');
sound(y)


close
fprintf(' Introducir el nombre de la funci�n de transferencia\n')
transf=input(' definida en SIMULINK a analizar? : ','s');
[A,B,C,D]=linmod2(transf);
[NUM,DEN] = SS2TF(A,B,C,D,1); 
NUM=chopm(NUM);
printsys(NUM,DEN)
% Lazo para utilizar cualquiera de las herramientas disponibles para esa funcion de transferencia
KA1=0;
while KA1<=10

% Se muestra el men� de m�todos de an�lisis disponibles 
KA1=menu('Elija el tipo de an�lisis','1) Respuesta en frecuencia ','2) Respuesta al escal�n','3) Respuesta al impulso','4) Gr�fico de polos y ceros de H(s)','5) Lugar de las ra�ces','6) Diagrama de Nyquist','7) Diagrama de Nichols','8) An�lisis de Routh','9) Valores de Magnitud y Fase','10) Cambiar la Transferencia H(s)','11) Salir');
fprintf('\n')
if KA1==1
         % Gr�ficos de Amplitud y fase de la funcion de transferencia 
         figure(1)
         clf
         bode(A,B,C,D,1)
         title('Respuesta a la frecuencia de H(s)')
         titulos
         
 % M�rgen de Ganancia y de fase y las frecuencias de cruce
 fprintf(' * Par�metros para el estudio de la Estabilidad:  \n\n')
           [mag,fase,w]=bode(A,B,C,D,1);
            [Mg,Mf,Fcf180,Fcg0]=margin(mag,fase,w); 
	        Mgdb= 20*log10(Mg);
			fprintf('    M�rgen de Fase      = %7.3g',Mf),fprintf('\n')
			fprintf('    M�rgen de Ganancia  = %7.3g',Mg),fprintf('\n')
			fprintf('    M�rgen de Ganancia en dB= %1.3g',Mgdb),fprintf('\n')
			fprintf('    Frecuencia de cruce de Ganancia 0 dB   '),exi(Fcg0),fprintf('Hz'),fprintf('\n')
			fprintf('    Frecuencia de cruce de Fase 180� '),exi(Fcf180),fprintf('Hz'),fprintf('\n')        
elseif KA1==2
	% Gr�fico de la respuesta al escal�n y Par�metros descriptores de la respuesta al escal�n
    figure(2)
    clf
    step(A,B,C,D,1) 
	title('Respuesta al escal�n de H(s)')
	titulos
    [num,den]=ss2tf(A,B,C,D);
    destem(num, den)        % Par�metros descriptores temporales
    
elseif KA1==3
	% Gr�fico de la respuesta al impulso
    figure(3)
    clf
    impulse(A,B,C,D,1) 
	title('Respuesta al impulso de H(s)')
	titulos
     
elseif KA1==4
        
        % Diagrama de polos y ceros de H(s)
        
        figure(4)
        clf
        axis('square');   % Hace la relaci�n de aspecto cuadrada
        pzmap(A,B,C,D)
        sgrid;
	title('Diagrama de polos y ceros de H(s) ')
	titulos
	
 
elseif KA1==5
        % Lugar de las raices
       figure(5)
       clf
       rlocus(A,B,C,D)
       title('Lugar de las ra�ces ')
       titulos
           
elseif KA1==6
         % Diagrama de Nyquist
         
         figure(6)
         clf
         nyquist(A,B,C,D,1)
	     title('Diagrama de Nyquist ')
	     titulos
         elseif KA1==7
         % Diagrama de Nichols
         figure(7)
         clf
         ngrid('new'),nichols(A,B,C,D,1) 
	     title('Diagrama de Nichols ')
	     titulos
         
elseif KA1==8
		% Tabla de Routh
        close
        fprintf(' ** An�lisis de Routh de N(s) y D(s) de H(s) *\n\n')
        fprintf('   * Numerador de la Transferencia en potencias de s descendientes\n\n')
		syms eps
        format short e
        disp(NUM)
    	routh(NUM,eps)
		fprintf('   * Denominador de la Transferencia en potencias de s descendientes\n\n')   
 		format short e      
		disp(DEN)
    	routh(DEN,eps)
        fprintf('   * Fin del an�lisis de Routh *  \n\n')   
elseif KA1==9
           % Valores de la Respuesta en frecuencia w
           close
           [mag,fase,frec]=bodenhz(A,B,C,D,1);
           magdb=20*log10(mag);
			format short e  
            encabezado=['      frec           mag         H           Fase'];
              unidades=['       Hz                        dB            � '];
            disp(encabezado)
            disp(unidades)
           [frec mag magdb fase]
	
elseif KA1==10
	% Cambiar la funci�n de Transferencia a analizar
    fprintf(' Introducir el nombre de la NUEVA funci�n de transferencia\n')
    transf=input(' de SIMULINK a analizar:  ','s');
    [A,B,C,D]=linmod2(transf);
    [NUM,DEN] = SS2TF(A,B,C,D,1); 
    NUM=chopm(NUM);
    printsys(NUM,DEN)
    fprintf('')
elseif KA1==11
     close all
fprintf('   � Chau !'),fprintf('\n\n')
% Sonido de Despedida
sound(y)

end

end
