% CGIBAJR es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% CGI pasaBajos con Ranura de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) La frecuencia del cero fz en kHz
%                      3) El Q de la etapa
%                      4) El valor de la ganancia de continua Ho en dB
%                      5) Un valor del capacitor C en nF 
%   
%  Ejemplo:
%  1) Datos: Si fp= 2.06 kHz, fz= 4.83 kHz, el Q= 0.865, 
%            la ganancia de continua = -0.225 dB y el C elegido es = 20 nF
%  
%  2) Se ingresa:   cgibajr(2.06,4.83,0.865,-0.225,10)
%
%  3) Se obtiene:
%              Etapa CGI Pasabajos con ranura
%              R = 7.68 kohm  QR/b = 13.7 kohm  QR/(1-b) = 13 kohm
%              R/c = 7.87 kohm  R/(1-c) = 301 kohm
%              C = 10 nF  aC = 5.6 nF  (1-a)C = 4.3 nF
%
%      +---------------------------/\/\/\----------------------------------------+
%      |                             R/c                   |`.      	         |  
%      |	   aC         +--------------------------------|+ `.     	         |
%      |	   | |        |                                |    >---*---o V2     |    
%      *-------| |--------*                            +---|- ,'    |            |
%      |	   | |	      |                            |   |,'      |            |
%      |		          |                  	C      | 	   	    |	         |
% V1   | 	QR/b          |        R           | |     |     R      |      R     |
%    o-*---/\/\/\----*----*----/\/\/\----*-----| |-----*---/\/\/\---*---/\/\/\---*---+
%                    |    |              |     | |     |          	             |   |             
%  		             /	__|__            |      	   | 	 		             |   /
%  	        QR/(1-b) \  _____ (1-a)C     |      .�|    |	                     |   \ R/(1-c)
%  		             /    |              |    .� -|----+                         |   /			                                               
%  		            _|_  _|_             +---<    |                              |   |			                                   
%  		             -    -                   `. +|------------------------------+  _|_			                                   
%  			                                    `.|                     			 -                         
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     cgibajr(fp,fz,Q,Ho,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=cgibajr(fp,fz,Q,Ho,C)

% Se adecuan los datos:

c=10^(Ho/20);
if c>1 
fprintf(' La ganancia de continua no puede ser mayor de 0 dB  '),fprintf('\n')
break
end
fp=fp*1000;
fz=fz*1000;
a=c/2*(1+(fp/fz)^2);
b=c/2;

C=C*1e-9;
C=cnor(C);
% Se calcula R
R=1/(2*pi*fp*C);
% Se calcula R/c
Rsc=R/c;
Rsc=rnor(Rsc,1);
% Se calcula QR/b
QRsb=Q*R/b;
QRsb=rnor(QRsb,1);
% Se calcula QR/(1-b)
QRs1mb=Q*R/(1-b);
QRs1mb=rnor(QRs1mb,1);
% Se calcular aC
aC=a*C;
aC=cnor(aC);
% Se calcula (1-a)C;
maC=(1-a)*C;
maC=cnor(maC);
% Se normaliza R
R=rnor(R,1);

% Se calcula R/(1-c)
if c~=1 
Rs1mc=R/(1-c);
Rs1mc=rnor(Rs1mc,1);
end


% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa CGI Pasabajos con ranura'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('  QR/b'),exi(QRsb),fprintf('ohm')
fprintf('  QR/(1-b)'),exi(QRs1mb),fprintf('ohm'),fprintf('\n')
fprintf('   R/c'),exi(Rsc),fprintf('ohm'),
if c~=1 
fprintf('  R/(1-c)'),exi(Rs1mc),fprintf('ohm'),fprintf('\n')
end
fprintf('   C'),exi(C),fprintf('F'),  
fprintf('  aC'),exi(aC),fprintf('F'),        
fprintf('  (1-a)C'),exi(maC),fprintf('F'),fprintf('\n'),fprintf('\n')



