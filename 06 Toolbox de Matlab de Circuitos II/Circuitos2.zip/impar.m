%IMPAR proporciona la parte IMPAR de un polinomio , es decir los coeficientes
% de los exponentes IMPARES de las potencias de s, 
%conservando el orden del vector

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function [Y] = impar (X)
Y=zeros(size(X));

dimY = length(Y);

if (rem(dimY-1,2) == 0),
  i = 2;
else
  i = 1;
end

while (i <= dimY),
  Y(i) = X(i);
  i = i + 2;
end
    
