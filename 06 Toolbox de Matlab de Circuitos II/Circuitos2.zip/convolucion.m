% CONVOLUCION es una funci�n que se usa para ilustrar el concepto de
% convoluci�n como suma de la respuesta a los impulsos
% desfasados. Se usan transferencias de primer orden y segundo orden
% y proporciona
% las respuestas aproximadas y exactas del circuito cuando
% se le ingresa el tiempo entre pulsos con los cuales se
% conforma la se�al de excitaci�n y el orden del circuito
% Ejemplos:  
%          1) convolucion(0.5,1) permite ver la respuesta aproximada y exacta
%                            de un circuito de 1� orden a un pulso de
%                            que vale 1 hasta 5 y luego 0 hasta 10, cuando la
%                            excitaci�n se compone de 10 pulsos
%          2)  convolucion(0.1,1) Al disminuir el tiempo entre pulsos, se
%                                 mejora la respuesta obtenida
%          
%          3) convolucion(0.02,2) permite ver la respuesta a un circito de
%                             2� orden a un pulso que vale 1 hasta 10,
%                             cuando la excitaci�n se compone de
%                             50 pulsos

% � Copyright 2008. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   30 de setiembre de 2008. Version preliminar

function y=convolucion(TR,orden)

% Para indicar qu� hay que hacer cuando se introduce s�lo
% el nombre de la funci�n y evitar el mensaje de error
if nargin==0,
  disp('     Uso:  convolucion(TR,orden)')
  disp('     Tipear ''help convolucion'' para m�s ayuda.')
  disp('     C�tedra de Teoria de Circuitos II.')
  disp(' ')
  return
end 

% Par�metros temporales que se usan para los gr�ficos
TR1=0.001;
t=0:TR1:10;		       
t2=0:TR:10;

% Uso el color de fondo del sistema
colordefondo = get(0,'DefaultUicontrolBackgroundColor');
set(gcf,'Color',colordefondo)

% Se prepara y establece la presentaci�n de la figura

set(gcf, 'defaultaxesfontsize', 11)
set(gcf, 'defaulttextfontsize', 11)
set(gcf, 'defaultlinelinewidth', 2)
set(gcf, 'defaultlinemarkersize', 8)

% 1. Definici�n de la se�al de entrada y el circuito
% Si el sistema es de primer orden uso un pulso que vale 1 hasta 5
% y si es de segundo orden que vale 1 hasta 10. Tambien uso la
% transferencia adecuada para cada caso

if orden == 1
f=1.*(t<5.01);
f2=1.*(t2<5.01);
sys=tf(1,[1 1]);
else
f=1.*(t<10);
f2=1.*(t2<10);
sys=tf(1,[1 1 1]);
end


% 2. Gr�fico de la se�al de entrada al circuito
figure(gcf)
plot(t,f,'b');
xlabel('Tiempo');
ylabel('Entrada');
title('Se�al de entrada en funci�n del tiempo');
pause;


% 3 Aproximaci�n de la se�al de entrada con pulsos
hold on;
figure
set(gcf,'Color',colordefondo)
p=stem(t2,f2,'b^','filled');
set(p,'LineWidth',2,'MarkerSize',5,'Color','b');


title('Se�al de entrada su y aproximaci�n con impulsos');
hold off
pause;

% 4 Respuesta al impulso del circuito 
figure
set(gcf,'Color',colordefondo)
impulse(sys,t);
title(['Respuesta al impulso del circuito de ',num2str(orden),'� orden']);
xlabel('Tiempo');
ylabel('salida');
pause

% 5. Respuesta al impulso del sistema para cada pulso retardado 
h=impulse(sys,t);		
colores='ymcrgb';
figure
set(gcf,'Color',colordefondo)
imp=zeros(length(t),length(t2));
for i=2:length(t2),
   offset=(i-1)*round(TR/TR1);
   x=h*f2(i)*TR;
   imp(offset+1:length(t),i)=x(1:length(t)-offset);
   plot(t,imp(:,i),colores(mod(i-1,6)+1));
   hold on;
end


titulo=(['Respuesta aproximada con un tiempo entre pulsos de = ',num2str(TR)]);
title(titulo);
xlabel('Tiempo [s]');
ylabel('Respuesta');
approx=sum(imp,2);
plot(t,approx,'k');
%legend(sprintf('Npulsos=%f',5/TR),sprintf('Tiempo de retardo TR=%f',TR));
pause;
hold off;


% 6. Comparaci�n entre las dos respuestas, la aproximada y la
% exacta que da Matlab con la funci�n lsim
approx2=sum(imp,2);
soln=lsim(sys,f,t);
figure
set(gcf,'Color',colordefondo)
plot(t,approx2,'k',t,soln,'r');
title('Comparaci�n entre la respuesta exacta y la aproximada');
xlabel('Tiempo');
ylabel('Respuesta');
legend(['Respuesta aproximada con TR = ',num2str(TR),''],'Respuesta exacta');



