% LNUEVO es una funcion que proporciona el valor de
%  la INDUCTANCIA L de un filtro PASAALTOS
%  que se obtiene por transformacion y escalado de 
%  la CAPACIDAD C del PASABAJOS NORMALIZADO
% cuando se le ingresa en este orden:          (Ojo con las Unidades)
%                       1) El valor de C en H
%                       2) La frecuencia fc en KHz
%                       3) El factor de escala de impedancias Kz
%  
%  Ejemplo
%  1)  Datos C=1.21508H  f=300 Hz  Kz=1e5
%  2)  Se introduce: lnuevo(1.21508,0.3,1e5)
%  3)  Se obtiene:        
%   Lnuevo (correspondiente a C) del filtro pasaaltos = 43.661 H      
%
%  Ver tambien BICUA, COMPODE, COMPODEA, KRCI, KRCK2, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     lnuevo(C,f,Kz)       

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function y=lnuevo(C,f,Kz)


f=f*1e3;

L=Kz/(2*pi*f*C);

% Valor normalizado m�s cercano

%Ln=lnor(L);

% Presentacion de los resultados
fprintf('\n')

fprintf(' Lnuevo (correspondiente a C) del filtro pasaaltos'),exi(L),fprintf('H'),fprintf('\n')


 


