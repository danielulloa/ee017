% PABAN se utiliza para obtener los valores desnormalizados 
% o de trabajo de los componentes de los filtros PasaBanda
% a partir de los componentes de filtros prototipos pasabajos 
% que figuran en forma normalizada en las tablas con Wc = 1 rad/s
% cuando se le ingresa en este orden:          
%  1) Los valores del filtro prototipo de L y C 
%  2) El factor de escala de impedancias Kz
%  3) La frecuencia central f0 y el ancho B
%     de la banda de paso en kHz (ojo con las unidades) 
%
%  Ejemplo:
%  1)  Lp=1.03697 H   Cp=1.41958 F   Kz=50  f=230000 Hz y B=28 kHz
%  2)  Se introduce:  paban(1.03697,1.41958,50,230,28)
%  3)  Se obtiene:        
% Valores Prototipo                  Valores Pasabanda: 
%   Lp = 1.03697            Lb1 = 0.294712 mH    Cb1 = 1.62475 nF
%   Cp = 1.41958            Lb2 = 2.9671 �H    Cb2 = 0.161381 �F
%
%  Ver tambi�n CNUEVO, LNUEVO, PAALT, PABAJ, PASUP, RNUEVO
%
%              Lp                             Lb1      Cb1     
%       o----//////----o     ====>      o----//////----| |-----o
%        
%                                                 Cb2        
%  				                            +-----| |-----+
%	           Cp			                |		      |
%       o-----| |-----o      ====>      o---*---//////----*--o 
%						                          Lb2 
%  Introducir  paban(Lp,Cp,Kz,f0[kHz],B[kHz])   

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1


function y=paban(Lp,Cp,Kz,f0,B)  

Bn=B/f0;      % Ancho de Banda Normalizado

f0=f0*1000;   % Frecuencia central de pasabanda
  
Kf=2*pi*f0;   % Factor de normalizacion de frecuencias

a=Kz/Kf;
b=Kz*Kf;

%Circuito serie LC
Lb1=a*Lp/Bn;
Cb1=Bn/b/Lp;
% Circuito paralelo LC
Lb2=a*Bn/Cp;
Cb2=Cp/b/Bn;

fprintf('\n')
fprintf(' Valores Prototipo                  Valores Pasabanda: '),fprintf('\n')

if Lp~=0
fprintf('   Lp'),exi(Lp),fprintf('         '),fprintf('  Lb1'),exi(Lb1),fprintf('H'),fprintf('    Cb1'),exi(Cb1),fprintf('F'),fprintf('\n')
end
if Cp~=0
fprintf('   Cp'),exi(Cp),fprintf('         '),fprintf('  Lb2'),exi(Lb2),fprintf('H'),fprintf('    Cb2'),exi(Cb2),fprintf('F'),fprintf('\n')
end
fprintf('\r')
