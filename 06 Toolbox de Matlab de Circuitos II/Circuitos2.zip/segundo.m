% SEGUNDO es una funci�n auxiliar para la funci�n che2abajo
% que sirve para determinar los coeficientes de etapas
% de segundo orden a partir de la lista de polos o ceros
% de las etapas

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0


function [A,final]=segundo(polosoceros)
a=poly(polosoceros);
Na = length(a)-1; 
p= cplxpair(polosoceros); 
K = floor(Na/2);

if K*2 == Na     % C�lculo cuando Na es PAR
   A = zeros(K,3); final=K;
   for n=1:2:Na
       Afila = p(n:1:n+1,:);
       Afila = poly(Afila);
       A(fix((n+1)/2),:) = real(Afila);
   end

elseif Na == 1   % C�lculo cuando Na = 1
       A = [0 real(poly(p))];
       final=1;
else             % C�lculo cuando Na es IMPAR y > 1
   A = zeros(K+1,3);final=K+1;
   for n=1:2:2*K
       Afila = p(n:1:n+1,:);
       Afila = poly(Afila);
       A(fix((n+1)/2),:) = real(Afila);
       end
       A(K+1,:) = [0 real(poly(p(Na)))];
end