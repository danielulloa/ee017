% RM es una funci�n que proporciona los valores de:
% las Resistencias R, RA y RB
% de una etapa activa PASABANDA DE REALIMENTACI�N M�LTIPLE 
% cuando se le ingresa:                         (Ojo con las unidades)
%                      1) La frecuencia central fo en kHz
%                      2) El Q de la etapa
%                      3) La ganancia de la banda de paso Ho 
%                      4) Un valor de capacitor en nF 
%                            | |           	 	     
%                    +-------| |-------*-------------+     
%                    |       | | C     |	         |
%                    |	               /             |
%                    |                 \ R 	         |
%                    |        C        /  	         |
%             RA     |       | |       |    |`.      |       
%    V1 o---/\/\/\---*-------| |-------*----|- `.    |       
%                    |       | |            |    >---*---o V2    
%                    /                 +----|+ ,'                     
%                    \ RB              |    |,'                     
%                    /                 |          
%                   _|_               _|_         
%                    -                 -  
%  Ejemplo:
%  1) Datos: si fo=500 Hz, Q=10, Ho=5 y C=10nF,
%  2) Se introduce  rm(0.5,10,5,10) 
%  3) Se obtiene:
%              R= 634 kohm  RA= 63.4 kohm   RB= 1.62 kohm
%
%  Ver tambien BICUA, KRCKI, KRCIK2, PBDA, POLOSKRC, PRIMOR,
%              PRIMORK, RANDTA, RANDTP, RANSL, SK, SKPA, VAEI y VAENOI 
%
%   Introducir rm(fo,Q,Ho,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   11 de Julio de 2002. Version 1.1

function y=rm(f0,Q,H0,C)


f0=f0*1000;
C=C*1e-9;

R=Q/(pi*f0*C);
RA=R/(2*H0);

if Q < sqrt(H0/2)
 fprintf('Verificar los datos de ingreso pues Q es mayor que la ra�z de H0/2 '),fprintf('\n')
 return
else
 RB=R/2/(2*Q^2-H0);
end

% Valor normalizado m�s cercano
Rn=rnor(R,1);
RAn=rnor(RA,1);
RBn=rnor(RB,1);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('   Etapa Pasabanda de Realimentaci�n M�ltiple'),fprintf('\n')
fprintf('   R'),exi(Rn),fprintf('ohm')         
fprintf('  RA'),exi(RAn),fprintf('ohm')
fprintf('  RB'),exi(RBn),fprintf('ohm'),fprintf('\n')
fprintf('\r')



