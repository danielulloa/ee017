function [Y] = CERO (X)
% CERO funci�n que reemplaza por cero valores
% menores que una cierta cota
L=length(X);
for i=1:L
if abs(X(i))>1e-12
  Y(i)=X(i);
else
  Y(i)=0;
end
end
