% KRCI es una funci�n que proporciona los valores de
% las Resistencias R y RB y como dato K de una etapa activa 
% KRC de 2 orden con Capacitores y Resistencias Iguales
% cuando se le ingresa:                        (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa 
%                      3) El valor del capacitor en nF y
%                      4) El valor de la Resistencia RA en kohm 
%                      
%                                  | | C     
%                    +-------------| |---------------+
%                    |             | |               |   
%                    |                               |   
%              R     |      R               |`.      |   
%    V1 o---/\/\/\---*---/\/\/\---*---------|+ `.    |       
%                                 |         |    >---*---o V2
%                               __|__   +---|- ,'    |       
%                            C  _____   |   |,'      |       
%                                 |     |            |       
%                                _|_    *---/\/\/\---+       
%                                 -     |     RB     
%                                       /        
%                                       \ RA       
%                                       /          
%                                      _|_        
%  Ejemplo:                             -
%
%  1)Datos:    Si fp= 1000 Hz, Q= 2, C=1.2 nF y RA= 10kohm
%
%  2)Se ingresa:   krci(1,2,1.2,10) 
%
%  3)Se obtiene:   K=2.5  R = 133 kohm  RB = 15 kohm  
%
%  Ver tambi�n BICUA, KRCK2, PBDA, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     krci(fp,Q,C,RA)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1

function y=krci(fp,Q,C,RA)

fp=fp*1000;
C=C*1e-9;
RA=RA*1000;

R=1/(2*pi*fp*C);
K=3-1/Q;
RB=(K-1)*RA;

R=rnor(R,1);
RB=rnor(RB,1);
fprintf('    Filtro KRC con componentes R y C iguales \n')
fprintf('    K'),exi(K),fprintf('')
fprintf('  R'),exi(R),fprintf('ohm')
fprintf('  RB'),exi(RB),fprintf('ohm')
fprintf('\n')
fprintf('\r')


