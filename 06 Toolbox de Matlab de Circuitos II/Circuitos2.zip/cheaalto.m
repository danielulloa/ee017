%	CHEAALTO es un programa que suministra fp Y Q para el proyecto de
%                    FILTROS CHEBYSHEV ACTIVOS PASAALTOS 
% 	ingresando: 
%       1) La frecuencia de corte de 3dB de la banda de paso
%       2) La atenuacion m�xima en la  banda de paso (El ripple)
% 	3) El ORDEN n del filtro
%
%       Consultar tambien CHEAALT que permite el dise�o CALCULANDO 
%       el orden n del filtro. 

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   9 de Octubre de 2002. Version 1.1

fprintf('----------    PROYECTO DE FILTROS CHEBYSHEV ACTIVOS PASAALTOS    ----------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')


% Puesta a cero de los vectores

Qpolo=[];
Wpolo=[];
Wcero=[];
Wpolo3dB=[];
fpolo=[];
p=[];
p2=[];
fpalto=[];
% Ingresos de las frecuencias y las atenuaciones
f3dB=input('Ingresar la frecuencia de corte de 3dB en KHz:   ');
Amax=input('Ingresar la atenuacion maxima en la banda de paso Amax en dB :   ');
n=input('Ingresar el orden del filtro:   ');
f3dB=f3dB*1000;
fprintf('\n\n')

% Calculo de los polos del filtro de Chebyshev
j = sqrt(-1);
epsilon = sqrt(10^(.1*Amax)-1);
mu = asinh(1/epsilon)/n;
p = exp(j*(pi*(1:2:2*n-1)/(2*n) + pi/2));
p = sinh(mu)*real(p) + j*cosh(mu)*imag(p);
z = []; % No tiene ceros este filtro en su funcion de transferencia
k = real(prod(-p));
p=cplxpair(p);
e=epsilon;

% Frecuencia de normalizacion de 3 dB

W3dB=cosh(acosh(1/e)/n);
%W3dB=1  % Si se le saca el signo de porcentaje se obtiene la Fc a los Amax dB

% De los polos agrupados en funciones de 2 orden, se obtiene el Q y la frecuencia

if rem(n,2)~=0   % Si el orden es impar
np=length(p)-1;

  for i=1:2:np
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    Wpolo3dB(i)=Wpolo(i)/W3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
    fpalto(i)=f3dB/Wpolo3dB(i);
  end

poloreal=p(length(p));

else
np=length(p);    % Si el orden es par
  for i=1:2:np
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    Wpolo3dB(i)=Wpolo(i)/W3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
    fpalto(i)=f3dB/Wpolo3dB(i);
  end
if rem(n,2)~=0   % Si el orden es impar
  poloreal=[]
end
end

% Presentaci�n de los resultados en pantalla

fprintf('          * 2) fp y Q de cada etapa:'),fprintf(' \n')
fprintf(' \n\n')

fpolo=elicero(fpalto);
fpolo;
Qpolo=elicero(Qpolo);
for i=1:length(fpolo)
      
      fprintf('fp'),exi(fpolo(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo(i))
      fprintf(' \n\n')
end

if rem(n,2)~=0
fpreal=f3dB/(abs(poloreal)/W3dB); % La frecuencia del polo real que falta 


 fprintf('fp etapa de primer orden'),exi(fpreal),fprintf('Hz'),fprintf('\n')
end

fprintf('\n')


fprintf('-------    Fin del c�lculo de fp y Q del Filtro Chebyshev Pasaaltos    -------------------------------------------------------'),fprintf('\n')

  