% PRIMORK es una funci�n que proporciona el valor de
% la resistencia R1 de entrada, la resistencia R2 y 
% el capacitor C de realimentaci�n de una etapa Pasabajos de 
% PRIMER ORDEN con GANANCIA (o Atenuaci�n) en continua  
% cuando se le ingresa:                         (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El valor de la Ganancia Ho en dB 
%                      3) El valor de la resistencia R1 de entrada en kohm
%
%                                      R2
%                                +---/\/\/\-----+   
%                                |              |
%                                |     | |      |    
%                                *-----| |------*  
%                                |     | | C	| 
%                                |  	        |
%                        R1      |    |`.       |       
%               V1 o---/\/\/\----*----|- `.     |       
%                                     |    >----*---o V2    
%                                +----|+ ,'                     
%                                |    |,'                     
%                               _|_           
%                                -      
%  Ejemplo 1: Si la fp= 1000 Hz , Ho= 20 dB y la resistencia R1= 20 kohm
%
%  Entonces:  primork(1,20,20) proporciona:    R1 = 19.6 kohm
%                                              R2 = 196 kohm
%                                              C = 0.82 nF
%  Ejemplo 2: primork(1,-10,20) proporciona:
%                                              R1 = 21 kohm
%                                              R2 = 6.65 kohm
%                                              C = 24 nF
%  Notar que ahora R2 (la resistencia de realimentaci�n) es menor que R1
%  Acepta valores negativos de Ho hasta -91 dB.
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,
%              RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir:   primork(fp,Ho,R1)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0

function y=primork(fp,Ho,R1)

fp=fp*1000;
R1=R1*1000;
 
Cte=10^(Ho/20);
R2=R1*Cte;
      
C=1/(2*pi*fp*R2);    
C=cnor(C);
R2=1/(2*pi*fp*C);  
R1=R2/Cte;

R1=rnor(R1,1);
R2=rnor(R2,1);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('   Etapa de Primer Orden con ganancia'),fprintf('\n')
fprintf('   R1'),exi(R1),fprintf('ohm'),fprintf('\n')
fprintf('   R2'),exi(R2),fprintf('ohm'),fprintf('\n')
fprintf('   C'),exi(C),fprintf('F'),fprintf('\n')
fprintf('\r')
