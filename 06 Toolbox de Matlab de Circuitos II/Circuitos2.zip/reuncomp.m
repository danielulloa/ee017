%  REUNCOMP proporciona la inmitancia resultante cuando se le
%  extrae un componente de valor comp
%  Calcula la inmitancia resultante despues de la remocion parcial

% Funciones adicionales usadas en este programa:
% restapol

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


function [nr,dr]=reuncomp(ni,di,comp)

p1=comp*poly(0);
p2=conv(p1,di);
nr=restapol(ni,p2);   % numerador y denominador de la Inmitancia resultante
dr=di;







