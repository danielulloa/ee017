% KRCBAN es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% KRC pasaBanda de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2  El Q de la etapa
%                      3) El valor de la ganancia de resonacia Hr en dB
%                      4) Un valor del capacitor C en nF 
%                      5) Un valor de la resistencia R0 en kohm
% 
% La ganancia de resonacia m�xima que puede proporcionar esta
% configuraci�n es: Hr = 25.1507 dB. Si se supera este valor
% se indica en los resultados el valor de Hr de la etapa.
%
%  Ejemplo:
%  1) Datos: Si fp= 1000 Hz, el Q= 9.54699, 
%            la ganancia de resonancia = 0 dB, 
%            el C elegido es = 20 nF y R0 = 10kohm
%  
%  2) Se ingresa:   krcban(1,9.54699,0,10,10)
%
%  3) Se obtiene:
%                Etapa KRC PasaBanda
%                R = 15.8 kohm   R/a = 442 kohm   R/(1-a) = 16.5 kohm
%                R0/c = 182 kohm   R0(K-1) = 19.1 kohm  R0/(1-c) = 10.5 kohm
%                C = 10 nF  bC = 0.36 nF  (1-b)C = 10 nF
%                                     | |
%                    +----------------| |-----------------------+
%                    |                | | C                     |
%                    |                                          |
%  V1        R/a     |       R                         |`.      |
%  o---*---/\/\/\----*----/\/\/\----*------------------|+ `.    |
%      |             |              |                  |    >---*---o V2
%      |	         |    bC | |    |              +---|- ,'    |            
%      *---------------------| |----*              |   |,'      |           
%      |	         |       | |    |              |            |      
%      |		     |              |              | 	   	    |	         
%      | 	R0/c     |              |              |   R0(K-1)  |         
%      +---/\/\/\----------------------------------*---/\/\/\---+             
%  		             /            __|__            |   
%  	                 \ R/(1-a)    _____ (1-b)C     \ 
%  		             /              |              / R0/(1-c)			                                               
%  		            _|_            _|_             \			                                   
%  		             -              -             _|_			                                   
%  			                                       -                         
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     krcban(fp,Q,Ho,C,R0)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1. �����

function y=krcban(fp,Q,Hrdebe,C,R0)

% Se adecuan los datos:

% para evitar el infinito del coefc
if Q~=0.5 
    Hr=10^(Hrdebe/20);
    coefc=Hr/(2*Q-1);   
else
fprintf('   El Q debe distinto de 0.5 '),fprintf('\n\n')
break
end

if coefc>1 
Hr=(2*Q-1);
c=1; % Se fija el valor de c como el m�ximo posible
HrdB=20*log10(Hr);
else
c=coefc; % Si no se usa el valor c del Hr
Hr=10^(Hrdebe/20);
end

fp=fp*1000;
C=C*1e-9;
C=cnor(C);
K=3-1/Q;
% Se calculan a, b y c ya se calcul�
a=Hr/(3*Q-1);
b=Hr/(3*Q-1);

% Se calcula R
R=1/(2*pi*fp*C);
% Se calcula R/a
Rsa=R/a;
Rsa=rnor(Rsa,1);
% Se calcula R(1-a)
Rs1ma=R/(1-a);
Rs1ma=rnor(Rs1ma,1);
% Se calcula R0/c
R0=R0*1e3;
R0sc=R0/c;
R0sc=rnor(R0sc,1);
% Se calcula R0(K-1)
R0Km1=R0*(K-1);
R0Km1=rnor(R0Km1,1);
% Se calcula R0/(1-c)
if c~=1 
R0s1mc=R0/(1-c);
R0s1mc=rnor(R0s1mc,1);
end
% Se calcular bC
bC=b*C;
bC=cnor(bC);
% Se calcula (1-b)C;
mbC=(1-b)*C;
mbC=cnor(mbC);
% Se normaliza R
R=rnor(R,1);


% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa KRC PasaBanda'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   R/a'),exi(Rsa),fprintf('ohm')
fprintf('   R/(1-a)'),exi(Rs1ma),fprintf('ohm'),fprintf('\n')
fprintf('   R0/c'),exi(R0sc),fprintf('ohm'),
fprintf('   R0(K-1)'),exi(R0Km1),fprintf('ohm'),
if c~=1 
fprintf('  R0/(1-c)'),exi(R0s1mc),fprintf('ohm'),fprintf('\n')
else
fprintf('  ** Hr'),exi(HrdB),fprintf('dB **'),fprintf('\n')
end
fprintf('   C'),exi(C),fprintf('F'),  
fprintf('  bC'),exi(bC),fprintf('F'),        
fprintf('  (1-b)C'),exi(mbC),fprintf('F'),fprintf('\n'),fprintf('\n')





