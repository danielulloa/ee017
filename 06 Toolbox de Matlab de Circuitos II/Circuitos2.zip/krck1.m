% KRCK1 es una funcion que proporciona los valores de:
%          Las Resistencias R2 y R1 de una etapa activa
%          KRC de 2 orden CON CAPACITORES IGUALES Y RA=RB
% cuando se le ingresa:                         (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa y 
%                      3) El valor del capacitor en nF
%                  
%                                  | | C     
%                    +-------- ----| |---------------+
%                    |             | |               |   
%                    |                               |   
%             R1a    |     R2               |`.      |   
%    V1 o---/\/\/\---*---/\/\/\---*---------|+ `.    |       
%                    |            |         |    >---*---o V2
%                    /          __|__   +---|- ,'    |       
%               R1b  \       C  _____   |   |,'      |       
%                    /            |     |            |       
%                   _|_          _|_    *---/\/\/\---+       
%                    -            -     |     RB     
%                                       /        
%                                       \ RA       
%                                       /          
%                                      _|_        
%  Ejemplo:                             -
%
%  1) Datos:  Si fp= 1000 Hz, Q= 2 y el valor del capacitor C= 1.2 nF
%
%  2) Se ingresa:  krck1(1,2,1.2) 
%
%  3) Se obtiene:   R1a = 267 kohm  R1b=        R2 = 66.5 kohm 
%
%  Ver tambien BICUA, KRCI, PBDA, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     krck1(fp,Q,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   8 de Octubre de 2002. Version 1.0

function y=krck1(fp,Q,C)

fp=fp*1000;
C=C*1e-9;

% Calculo R2
R2=1/(2*pi*fp*Q*C);
R2=rnor(R2,1);

% Calculo R1a y R1b
R1=Q^2*R2;
R1a=2*R1;
R1a=rnor(R1a,1);
R1b=2*R1;
R1b=rnor(R1b,1);

% Presentaci�n de los resultados
fprintf('  * Filtro KRC con ganancia 1 y RA=RB * \n')
fprintf('  1) Datos: \n')
fprintf('  fp'),exi(fp),fprintf('Hz'),fprintf('  Q'),exi(Q),fprintf(''),...
fprintf('  C'),exi(C),fprintf('F'),fprintf('\n')
fprintf('  2) Resultados del proyecto: \n')
fprintf('  R1a'),exi(R1a),fprintf('ohm')
fprintf('  R1b'),exi(R1b),fprintf('ohm')
fprintf('  R2'),exi(R2),fprintf('ohm'),fprintf('\n')
fprintf('  El valor de RA=RB se elige \n')
fprintf('\r')                      


