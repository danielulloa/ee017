% DNUEVO es una funcion que proporciona el valor de
%  el COMPONENTE D de un filtro CRD que reemplaza al
%     CAPACITOR  C del PASABAJOS NORMALIZADO
% cuando se le ingresa en este orden:          (Ojo con las Unidades)
%                       1) El valor de C en F
%                       2) La frecuencia fc en KHz
%                       3) El factor de escala de impedancias Kz
%  
%  Ejemplo
%  1)  Datos C=1,207 F  f=15000 Hz  Kz=1e9
%  2)  Se introduce: dnuevo(1.207,15,1e9)
%  3)  Se obtiene:        
%   Dnuevo (que reemplaza a C) del filtro CRD pasabajos = 12.8067 fF.s      
%
%  ( La unidad del componente D es fF.s : femto (10^-15) � Farad � segundo ) 
%
%  Ver tambien BICUA, COMPODE, COMPODEA, KRCKI, KRCIK2, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKALTO, VAEI y VAENOI 
%
%  Introducir     dnuevo(C,f,Kz)       

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   04 de Noviembre de 2000. Version 1.0

function y=dnuevo(C,f,Kz)


f=f*1e3;
D=C/(2*pi*f*Kz);

% Presentacion de los resultados
fprintf('\n')

fprintf(' Dnuevo (que reemplaza a C) del filtro CRD pasabajos'),exi(D),fprintf('F.s'),fprintf('\n')


 


