% PTA2 es una funci�n que proporciona los valores de
% R, QR de la etapa PasaTodo Activa Bicuadr�tica de 2� orden 
% de 2� orden con Conversores Generalizados de Impedancia
%
% cuando se le ingresa en este orden:         Ojo con las Unidades)
%                       1) wp de la etapa normalizada
%                       2) Q de la etapa normalizada
%                       3) El tiempo de retardo T que va a
%                          proporcionar la etapa en us (microsegundos)
%                       4) Un valor de la Capacidad C en nF
%                       
%  Ejemplo:
%  1)  Datos: wp = 3.77789 , Q = 0.563536
%      el retardo de la etapa es 100us  y se adopta C = 1nF
%  2)  Se introduce: pta2(3.77789,0.563536,100,1)
%  3)  Se obtiene:        
%         Etapa Pasatodo Activa de 2� orden con CGI:
%         R = 13.3 kohm  QR = 7.5 kohm.  Se adopt�: C = 1 nF
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, PTA1, PTP1, PTP2, POLOSKRC, PRIMOR, 
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%                                    
%        +----------------------/\/\/\----------------------------------------+
%        |                          R                    |`.      	          |  
%      	 |             +---------------------------------|+ `.     	          |
%        |             |                                 |    >--*---o V2     |    
%        |             |                            +----|- ,'   |            |
%        |             |                            |    |,'     |            |
%        |    C        |                  	C       | 	   	     |	          |
%   V1   |   | |       |       R            | |     |     R      |      R     |
%    o---*---| |-------*----/\/\/\----*-----| |-----*---/\/\/\---*---/\/\/\---*
%            | |       |              |     | |     |          	              |               
%                      /	          |      	    | 	 		              |
%                   QR \              |      .�|    |	                      |
%                      /              |    .� -|----+                         |  			                                               
%                     _|_             +---<    |                              |  			                                   
%                      -                   `. +|------------------------------+  			                                   
%  			                                 `.|                     			                           
%  			                                     
%  Introducir    pta2(wp,Q,T[us],C[nF])

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   5 de Julio de 2002. Version 1.0

function y=pta2(wp,Q,Tet,C)

Te=Tet/1e6;   % Retardo de la etapa bicuadratica en segundos
T=Te/2;       % Retardo de las transferencias de Bessel
Kf=1/T;       % El factor de frecuencia es la inversa del retardo

% C�lculo de wpd 

wpd=wp*Kf;

% C�lculo de los valores de los resistores
C=C*1e-9;
R=1/(wpd*C);
Rq=Q*R;

% Valores normalizados m�s cercanos

Rn=rnor(R,1);
Rqn=rnor(Rq,1);

% Presentacion de los resultados
fprintf('\n')
fprintf('    Etapa Pasatodo Activa de 2� orden con CGI:'),fprintf('\n')
fprintf('    R'),exi(Rn),fprintf('ohm')
fprintf('  QR'),exi(Rqn),fprintf('ohm.')
fprintf('  Se adopt�: C'),exi(C),fprintf('F')
fprintf('\n')
fprintf('\r')



