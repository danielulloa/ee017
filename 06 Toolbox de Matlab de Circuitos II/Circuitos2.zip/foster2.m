% FOSTER2: S�NTESIS DE UNA RED LC MEDIANTE EL SEGUNDO M�TODO DE FOSTER
% Este programa sintetiza una admitancia de tipo LC presentada
% en la forma de un cociente entre polinomios en la variable s. 
% cuando se le ingresa el numerador y el denominador de la
% admitancia.
% Produce como salida la Admitancia sintetizada mediante una
% descripci�n de la interconexi�n de los componentes y sus valores
%
% Ejemplo: Si la admitancia a sintetizar es
% Y(s)= (s^3+ 4s)/(4s^4 + 40s^2 + 36)  
% en el indicador de Matlab se ingresa:
% � foster2 
% y aparece una solicitud de
% Ingresar el Numerador en el formato [n(n) n(n-1)...n(0)]
% � [1  0  4  0]  <----- Se ingresa lo pedido y aparece:
% Ingresar el Denominador en el formato [d(n) d(n-1)...d(0)]
% � [4  0  40 0 36]  <----- Se ingresa lo pedido
%
% y se obtiene: 
% *** Admitancia Y(s)sintetizada mediante Foster 2 ***
% Los terminales de la admitancia son los nodos 1 y 2
% y los componentes se conectan de la siguiente manera:
% Entre el nodo = 1  y el nodo = 3 :  C = 17.3611 mF
% Entre el nodo = 3  y el nodo = 2 :  L = 6.4 H
% Entre el nodo = 1  y el nodo = 4 :  C = 93.75 mF
% Entre el nodo = 4  y el nodo = 2 :  L = 10.6667 H
%
% Para este ejemplo la admitancia Y(s) es:
%
%             2 o--------+----------+
%                        |          |
%                        )          )
%              L= 6.4 H  )          ) L= 10.66 H
%                        )          )
%                        |          |
%                      3 *        4 *
%                        |          |
%                       _|_        _|_
%               17.36F  ___        ___  C=93.75 mF
%                        |          |
%                        |          |
%            1  o--------+----------+
%
% Ver tambi�n: CAUER1, CAUER2 y FOSTER1

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0 


% Se establecen las variables globales
global color num den limites
if isempty(color)
   color='b';
end



%Ingreso del numerador y denominador

fprintf('Ingresar el Numerador en el formato [n(n) n(n-1)...n(0)]'),fprintf('\n')
num=input(' � ');
fprintf('Ingresar el Denominador en el formato [d(n) d(n-1)...d(0)]'),fprintf('\n')
den=input(' � ');

m=length(num)-1;
n=length(den)-1;

%
% Las intrucciones siguientes realizan una comprobaci�n simple si la
% funci�n es real y positiva
% 
if abs(m-n)>1
 sprintf('La funci�n no es sintetizable ')
end
% 
% Se comprueba si los coeficientes son reales y positivos
%
for i=1:m+1;
 if (num(i)<0)|(imag(num(i))~=0)
  sprintf('La funci�n no es real positiva')
 end
end
for i=1:n+1;
 if (den(i)<0)|(imag(den(i))~=0)
  sprintf('La funci�n no es real positiva')
 end
end
%
% El paso siguiente consiste en calcular los polos y ceros y verificar
% que son imaginarios
%
ceros=roots(num);
polos=roots(den);
nr=find(real(ceros)~=0);
pr=find(real(polos)~=0);
if (length(nr)~=0)
 sprintf('La funci�n no representa un dipolo LC')
end
if (length(pr)~=0)
 sprintf('La funci�n no representa un dipolo LC')
end
% Se calcula el valor m�ximo para luego graficar
if isempty(limites)
   cm=max(ceros);
   pm=max(polos);
   limites=[0,abs(max(cm,pm))+.5,-5,5];
end
% Se grafica la reactancia

% gr   % Sacar el % si se desea graficar la reactancia

%
% Mediante la funci�n residue se calculan los res�duos de la funci�n 
% a sintetizar (res), los polos de la misma (pol), y el cociente
% de la divisi�n entre el numerador y el denominador (k).
%
[res,pol,k]=residue(num,den);
res;
pol;
k;
if (res==zeros)
 sprintf('Los polinomios son proporcionales')
end
%
% Procedimiento de s�ntesis.
% Si m < n resulta que k=0, y sino k~=0, esto es, hay un residuo 
% del polo en el infinito que corresponde a un capacitor en paralelo.
% 
circuito=[];                  %Se pone a cero la variable circuito

if ~isempty(k)                % Si hay k
 	circuito(1,1)=1;           % Hay un capacitor entre los nodos 1 y 2
 	circuito(1,2)=2;
 	circuito(1,3)=k(1);        % Se da el valor del capacitor entre el nodo 1 y 2
 	circuito(1,4)=2;           % El 2 indica que es un capacitor 
 	i=2;                       % Se pasa a la fila siguiente
 	 else
  	i=1;
 end
 
nodo= 3;  % Se inicializa la variable nodo que cuenta los nodos internos
j=1;      % Se inicializa la variable que barre los polos

while j<=n
%  
% Se examina la parte imaginaria de los polos puesto que si se encuentra un 
% polo con parte imaginaria nula quiere decir que representa 
% un inductor en paralelo.
%
 if (imag(pol(j))==0)
 circuito(i,1)=1;         % Nodo 1 del paralelo
 circuito(i,2)=2;         % Nodo 2 del paralelo
 circuito(i,3)=1/res(j);  % El valor de la inductancia es el inverso del residuo
 circuito(i,4)=1;         % Se indica que es una Inductancia con este 1
  i=i+1;                  % Se pasa a la fila siguiente
  j=j+1;                  % Se pasa al polo siguiente
  else
% 
% Los polos complejos conjugados representan un inductor y un capacitor en serie
% 
[num1,den1]=residue(res(j:j+1),pol(j:j+1),[]);
%
% C�lculo de los componentes mediante los coeficientes obtenidos
% de los polinomios numerador y denominador.
%
 num1;
 den1;
 circuito(i,1)=1;
 circuito(i,2)=nodo;               % Nodo intermedio
 circuito(i,3)=num1(1)/den1(3);
 circuito(i,4)=2;                  % Capacitor
 circuito(i+1,1)=nodo;             % Nodo intermedio
 circuito(i+1,2)=2;
 circuito(i+1,3)=den1(1)/num1(1);
 circuito(i+1,4)=1;                % Inductor
%
% Se actualizan los �ndices i y j incrementandolos en 2 unidades porque
% se han sintetizado 2 componentes.
% 
 i=i+2;
 j=j+2;
 
 % Se incrementa el contador de nodos en uno
 nodo=nodo+1;       
end
end

%
% Visualizaci�n de la tabla que contiene el resultado de la s�ntesis 
% 
disp('  ')
%disp('Nodoinicial, Nodofinal, Valor(F o H), Tipo de Componente(1 -> L,2 -> C)')

%circuito

% Para indicar la impedancia sintetizada
tama=size(circuito);
numerodefilas=tama(1,1);numerodecolumnas=tama(1,2);
nodoi=circuito(1:numerodefilas,1);
nodof=circuito(1:numerodefilas,2);
valores=circuito(1:numerodefilas,numerodecolumnas-1);
componentes=circuito(1:numerodefilas,numerodecolumnas);

fprintf(' *** Admitancia Y(s) sintetizada mediante Foster 2 ***'),fprintf('\n')
fprintf(' Los terminales de la admitancia son los nodos 1 y 2'),fprintf('\n')
fprintf(' y los componentes se conectan de la siguiente manera:'),fprintf('\n')

for k=1:numerodefilas
    fprintf(' Entre el nodo'),exi(nodoi(k)),fprintf(' y el nodo'),exi(nodof(k))

   if componentes(k)==1
      fprintf(':  L'),exi(valores(k)),fprintf('H'),fprintf('\n')

   else
      fprintf(':  C'),exi(valores(k)),fprintf('F'),fprintf('\n')
   end
   
end

fprintf('\r')


