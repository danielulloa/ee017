% CGIALTR es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% CGI pasaALTtos con Ranura de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) La frecuencia del cero fz en kHz
%                      3) El Q de la etapa
%                      4) La ganancia de alta frecuencia Haf en dB
%                      5) Un valor del capacitor C en nF 
%   
%  Ejemplo:
%  1) Datos: Si fp= 907.077 Hz, fz= 761.508Hz  kHz, el Q= 21.97, 
%            la ganancia de alta frec = 0 dB y el C elegido es = 10 nF
%  
%  2) Se introduce:   cgialtr(0.907077,0.761508,22.1057,0,10)
%
%  3) Se obtiene: 
%               Etapa CGI Pasaaltos con ranura
%               R = 17.4 kohm  QR/b = 1.1 Mohm  QR/(1-b) = 604 kohm
%  		        R/c = 24.9 kohm  R/(1-c) = 59 kohm
%  		        C = 10 nF  aC = 8.2 nF  (1-a)C = 1.5 nF
%
%      +---------------------------/\/\/\----------------------------------------+
%      |                             R/c                   |`.      	         |  
%      |	   aC         +--------------------------------|+ `.     	         |
%      |	   | |        |                                |    >---*---o V2     |    
%      *-------| |--------*                            +---|- ,'    |            |
%      |	   | |	      |                            |   |,'      |            |
%      |		          |                  	C      | 	   	    |	         |
% V1   | 	QR/b          |        R           | |     |     R      |      R     |
%    o-*---/\/\/\----*----*----/\/\/\----*-----| |-----*---/\/\/\---*---/\/\/\---*---+
%                    |    |              |     | |     |          	             |   |             
%  		             /	__|__            |      	   | 	 		             |   /
%  	        QR/(1-b) \  _____ (1-a)C     |      .�|    |	                     |   \ R/(1-c)
%  		             /    |              |    .� -|----+                         |   /			                                               
%  		            _|_  _|_             +---<    |                              |   |			                                   
%  		             -    -                   `. +|------------------------------+  _|_			                                   
%  			                                    `.|                     			 -                         
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
%  Introducir     cgialtr(fp,fz,Q,Haf,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=cgialtr(fp,fz,Q,Haf,C)

% Se adecuan los datos:

c=10^(Haf/20)*(fz/fp)^2;
fp=fp*1000;
fz=fz*1000;
a=c/2*(1+(fp/fz)^2);
b=c/2;

C=C*1e-9;
C=cnor(C);
% Se calcula R
R=1/(2*pi*fp*C);
% Se calcula R/c
Rsc=R/c;
Rsc=rnor(Rsc,1);
% Se calcula QR/b
QRsb=Q*R/b;
QRsb=rnor(QRsb,1);
% Se calcula QR/(1-b)
QRs1mb=Q*R/(1-b);
QRs1mb=rnor(QRs1mb,1);
% Se calcular aC
aC=a*C;
aC=cnor(aC);
% Se calcula (1-a)C;
maC=(1-a)*C;
maC=cnor(maC);

% Se calcula R/(1-c)
if c~=1 
Rs1mc=R/(1-c);
Rs1mc=rnor(Rs1mc,1);
end

% Se normaliza R
R=rnor(R,1);


% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa CGI Pasaaltos con ranura'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('  QR/b'),exi(QRsb),fprintf('ohm')
fprintf('  QR/(1-b)'),exi(QRs1mb),fprintf('ohm'),fprintf('\n')
fprintf('   R/c'),exi(Rsc),fprintf('ohm'),
if c~=1 
fprintf('  R/(1-c)'),exi(Rs1mc),fprintf('ohm'),fprintf('\n')
end
fprintf('   C'),exi(C),fprintf('F'),  
fprintf('  aC'),exi(aC),fprintf('F'),        
fprintf('  (1-a)C'),exi(maC),fprintf('F'),fprintf('\n'),fprintf('\n')



