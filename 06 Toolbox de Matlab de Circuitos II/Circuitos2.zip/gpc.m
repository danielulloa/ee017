function y=gpc(numerador,denominador);
% GPC Hace un Gr�fico y muestra en la ventana de Matlab
% los Polos (x) y Ceros (o) de una funci�n de transferencia
% cuando se le ingresa en el orden enunciado:                      
%                      
%  El numerador y el denominador de la funci�n de transferencia
%
% Por ejemplo: si el numerador es:   s+2       
%              y el denominador es:  s^2+ 2s +100 
%              se introduce: gpc([1 2],[1 2 100])
%
% se abre una ventana con un gr�fico y se obtiene:
%
% polos =
%        -1.00000000000000 + 9.94987437106620i
%        -1.00000000000000 - 9.94987437106620i
%
% ceros =
%        -2
%
% Ejemplo 2:
%  num=[1     0    10     0     9];
%  den=[1     0     4     0];
%  gpc(num,den)
%
%  Introducir     gpc(numerador,denominador)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio del 2002. Version 1.0

clf;

% C�lculo de la r�ices del denominador y del numerador

polos=roots(denominador); % Calcula los polos 
ceros=roots(numerador);   % Calcula los ceros 
polos=polos(:)            % Los pone como un vector columna
ceros=ceros(:)            % Los pone como un vector columna

MaxI=max(abs(imag([polos; ceros;j]))); % Determina el tama�o del diagrama
MaxR=max(abs(real([polos; ceros;1]))); % 
plot(1.5*[-MaxR MaxR],[0 0],'k')       % Grafica el eje real
hold on
text(1.5*MaxR,0,' Re')
plot([0 0],1.5*[-MaxI MaxI],'k')       % Grafica el eje imaginario
text(0,1.5*MaxI,' Im')
plot(real(ceros),imag(ceros),'ro')     % Grafica los ceros
plot(real(polos),imag(polos),'bx')     % Grafica los polos

axis('square');   % Hace la relaci�n de aspecto cuadrada
grid on           % Muestra el cuadriculado
title('Gr�fico de Polos y Ceros');
titulos
hold off


