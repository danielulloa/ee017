% RESPOLOS es una funci�n que grafica el movimiento de los vectores desde 
% los polos al punto de la frecuencia variable jw y la respuesta en 
% en frecuencia de una funci�n de transferencia de 2� orden a partir
% de los vectores los polos y obtiene el m�ximo a traves la circunferencia
% correspondiente.
% Si los polos se espresan de la siguiente manera p1,p2,= -alfa+-j*beta
% se consideran cuatro casos:
%       Caso 1 beta < alfa
%       Caso 2 beta = alfa
%       Caso 3 beta > alfa
%       Caso 4 beta >> alfa
% Si se desea evaluar, por ejemplo el caso 3 se introduce: respolos(3)
% y se obtiene el gr�fico del plano s y la respuesta en frecuencia
%
%  Introducir     respolos(n�mero del caso)

% � Copyright 2008. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   01 de setiembre de 2008. Version 1.0


function y=respolos(caso)
% Para indicar qu� hay que hacer cuando se introduce s�lo
% el nombre de la funci�n y evitar el mensaje de error
if nargin==0,
  disp('     Uso:  respolos(caso)')
  disp('     Tipear ''respolos'' para m�s ayuda.')
  disp('     C�tedra de Teor�a de Circuitos II.')
  disp(' ')
  return
end 
clf

figure(gcf)
%titulotc('Respuesta en frecuencia con circunferencia del valor m�ximo')
set(gcf, 'defaultaxesfontsize', 11)
set(gcf, 'defaulttextfontsize', 11)
set(gcf, 'defaultlinelinewidth', 1.3)
set(gcf, 'defaultlinemarkersize', 8)
% Uso el color de fondo del sistema
colordefondo = get(0,'DefaultUicontrolBackgroundColor');
set(gcf,'Color',colordefondo)
% Se establecen los polos para cada caso
if caso==1
    pp = [ -1+0.5*j  -1-0.5*j ];
     elseif caso==2
       pp = [ -1+1*j  -1-1*j ]; 
    elseif caso==3
       pp = [ -1+2*j  -1-2*j ]; 
    else
   pp = [ -1+20*j  -1-20*j ];     
    end

% Funci�n de Transferencia a partir de los polos
den=conv([1 -(pp(1))],[1 -(pp(2))]);
num=den(3);
nump = max(size(pp));
rp = real(pp);
ip = imag(pp);

% Partes real e imaginaria y el Q de los polos
alfa=abs(rp(1));
beta=abs(ip(1));
Q=0.5*sqrt( (beta/alfa)^2 +1 );
if Q > sqrt(2)/2
Hm=Q/sqrt(1-1/(4*Q)^2);
wp2=(rp(1)^2+ip(1)^2);
wm=sqrt(wp2-2*rp(1)^2);
else
    Hm=1; wm=0;
end

% Limites del dibujo y radio circunferencia de Hm�x
radio=abs(ip(1));
xinf=-1.2*abs(rp(1));
xsup= (radio-abs(rp(1)))+0.5;
wmax = round(1.8*abs(ip(1)));
w = 0:0.1:wmax;
iimax = max(size(w));
h = freqs(num,den,w);
hmag = abs(h);
hang = unwrap(angle(h))/pi*180;

% Gr�fico en el plano s
verdeoscuro=[0 0.5 0];
cremaoscuro=[254/255 197/255 146/255];
subplot(1,2,1)
axis( [ xinf xsup -wmax wmax ] )
xlabel('Real')
ylabel('Imag')

% Ejes de coordenadas
ejex = line('Xdata',[xinf xsup],'Ydata',[0 0],'Color','k','Linewidth',2);
ejey = line('Xdata',[0 0],'Ydata',[-wmax wmax],'Color','k','Linewidth',2);

% Punto donde la circunferencia corta al eje imaginario

l1 = line('Xdata',[0 0],'Ydata',[-wm wm],'Marker','*','Color','k');

title('Plano s con circuferencia de Hm�ximo') 
grid
hold on
% Gr�fico de la circunferencia del valor m�ximo
angulos=-pi/2:pi/20:pi/2;
circ=-abs(rp(1))+ radio.*(cos(angulos)+j.*sin(angulos));
p=plot(circ,'--');
set(p,'LineWidth',2.,'Color',cremaoscuro);

hold on
% Polos de la funci�n de transferencia
l2 = line('Xdata',rp,'Ydata',ip,'Marker','x','Color','k','Linewidth',2);
l3 = line('Xdata',[0],'Ydata',[0],'Marker','o','Color','k','EraseMode', 'xor');
l7 = line('Xdata',[-1 0 ],'Ydata',[0 0],'LineStyle',':','Color','r','EraseMode', 'xor');

% Vectores de los polos al punto de frecuencia m�vil
for ii = 1:nump
	lp(ii) = line('Xdata', [rp(ii) 0],'Ydata',[ip(ii) 0],'Color',verdeoscuro,'LineStyle','-','Linewidth',2,'EraseMode','xor'); 
end


% Gr�fico del m�dulo de la transferencia
rojooscuro=[0.7 0 0];

subplot(1,2,2)
% Marcador que se va moviendo con la frecuencias
l4 = line('Xdata',w(1),'Ydata',hmag(1),'Marker','o','Color','k','EraseMode', 'xor');
l44 = line('Xdata',w(1),'Ydata',hmag(1),'Marker','o','Color','k','EraseMode', 'xor');

xlabel(['Caso ',num2str(caso),': alfa = ',num2str(alfa),', beta = ',num2str(beta),', Q = ',num2str(Q)],'FontSize',12);
ylabel('\omega [rad/s]')
title(['|H (j \omega) |','     Hm�x = ',num2str(Hm),', \omega m�x = ',num2str(wm)])

axis([  0 max(hmag) -wmax wmax ])
grid
hold on
l5 = line('Xdata',[w(1) w(1)],'Ydata',[hmag(1) hmag(1)],'LineStyle','-','Linewidth',3,'Color',rojooscuro,'EraseMode', 'none');
l6 = line('Xdata',[w(1) w(1)],'Ydata',[hmag(1) 0],'LineStyle',':','Color','r','EraseMode', 'xor');
l8 = line('Xdata',[w(1) w(1)],'Ydata',[hmag(1) hmag(1)],'LineStyle','-','Linewidth',3,'Color',rojooscuro,'EraseMode', 'none');
l9 = line('Xdata',[w(1) w(1)],'Ydata',[hmag(1) 0],'LineStyle',':','Color','r','EraseMode', 'xor');



for ii=1:iimax
	
for jj = 1:nump
	set(lp(jj),'Xdata', [rp(jj) 0],'Ydata',[ip(jj) w(ii)])
end	
set(l3,'Xdata',[0],'Ydata',w(ii))
set(l7,'Xdata',[-1 0 ],'Ydata',[w(ii) w(ii)])

set(l4,'Ydata',w(ii),'Xdata',hmag(ii))
set(l44,'Ydata',-w(ii),'Xdata',hmag(ii))
if ii > 1
	set(l5,'Ydata',[w(ii-1) w(ii)],'Xdata',[hmag(ii-1) hmag(ii)])
    set(l8,'Ydata',[-w(ii-1) -w(ii)],'Xdata',[hmag(ii-1) hmag(ii)])
end
set(l6,'Ydata',[w(ii) w(ii)],'Xdata',[hmag(ii) 0])
set(l9,'Ydata',[-w(ii) -w(ii)],'Xdata',[hmag(ii) 0])

if caso == 4
pause(0.01)    % Esto para que vaya m�s r�pido en este caso
else
  pause(0.3)
end
end

%------------------------------------------------------------
 % F�n de la funci�n RESPOLOS
%------------------------------------------------------------
