% AMSUP es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% Akerberg-Mossberg Suprimebanda de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia de la ranura en kHz
%                      2) El Q de la etapa
%                      3) La ganancia de las bandas de paso en dB
%                      4) Un valor del capacitor C en nF 
%  Ejemplo:
%  1) Datos: Si fr= 1000 Hz, el Q= 3, 
%            la ganancia de las bandas de paso = 5 dB, 
%            y el C elegido es = 10nF 
%  
%  2) Se ingresa:   amsup(1,3,5,10)
%
%  3) Se obtiene:
%                Etapa AM Suprimebanda
%                R = 15.8 kohm   R/c = 8.87 kohm   QR = 47.5 kohm
%                C = 10 nF  aC = 18 nF
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
% 	           +------------------------/\/\/\------------------------------+    
% 	           | 		                   R             R                  |    
% 	           |     QR                            +---/\/\/\---+   	    |	
% 	           *---/\/\/\----+	                   |            |	        |	
% 	           |	         |	              C    |      .�|   |	   R    |
% 	           |     | | C   |	             | |   |    .� -|---*---/\/\/\--* 
% 	           *-----| |-----*           +---| |---*---<    |      	        |   
% 	           |     | |     |	         |   | |        `. +|---+	        |	
% 	      aC   |	         |	         |                `.|   |   	    |	
% V1     | |   |    |`.      |	         |                     _|_	        |	
%  o--*--| |---*----|- `.    |	   R     |   |`.                - 	        |    
%  	  |	 | |        |    >---*--/\/\/\---*---|+ `.     		        	    |  
%  	  | 	   +----|+ ,'    |	        /    |    >-------------------------+
% 	  |        |    |,'  	 | 	       /  +--|- ,'        		             
% 	  |       _|_     		 o V2     /   |  |,'      		
% 	  |        -      		         /   _|_         		
% 	  |  			  R/c           /     -  
%     +-------------/\/\/\---------+
%
%  Introducir     amsup(fr,Q,Ho,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=amsup(fp,Q,Ho,C)


% Se calculan a y c
Ho=10^(Ho/20);
c=Ho;
a=c;

% Se adecuan los datos:
fp=fp*1000;
C=C*1e-9;
C=cnor(C);

% Se calcula R
R=1/(2*pi*fp*C);

% Se calcula QR
QR=Q*R;
QR=rnor(QR,1);

% Se calcula R/c
Rsc=R/c;
Rsc=rnor(Rsc,1);

% Se calcular aC
aC=a*C;
aC=cnor(aC);

% Se normaliza R
R=rnor(R,1);

% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa AM Suprimebanda'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   R/c'),exi(Rsc),fprintf('ohm')
fprintf('   QR'),exi(QR),fprintf('ohm'),fprintf('\n')
fprintf('   C'),exi(C),fprintf('F'),  
fprintf('  aC'),exi(aC),fprintf('F'), fprintf('\n\n')       





