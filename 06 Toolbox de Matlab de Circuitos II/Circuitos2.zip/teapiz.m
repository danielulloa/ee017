% TEAPIZ realiza la CONVERSI�N DE T A PI para IMPEDANCIAS
%          y proporciona los valores de las 
% Impedancias Za, Zb y Zc del equivalente Pi de una red T de Z
% cuando se le ingresa en este orden:          (Ojo con las Unidades)
%      1) Z1 de la red T en ohm
%      2) Z2 de la red T en ohm
%      3) Z3 de la red T en ohm
%                                             
%          Z1           Z3                         Zb              
%        _____         _____        	          _____         	
%   o---|_____|---*---|_____|---o 	   o----*----|_____|----*----o 	
%                 |             	        |               |      	
%                 -           	    	  __|__           __|__     
%                | | Z2          ===>	 |_____| Za      |_____| Zc  
%                | |            	        |               |       
%                 -             		    |               |       
%                 |                         +-------*-------+       
%                 o             		            |
%						                            o	
%  Ejemplo:						
%  1)  Datos Z1= 1+j*1 ohm, Z2=2+4*j ohm, Z3=4-1*j ohm
%  2)  Se introduce: teapiz(1+j*1,2+4*j,4-1*j)
%  3)  Se obtiene:        
%                  Za  = 2.1765 + 6.2941i
%                  Zb  = 6.1000 - 0.7000i
%                  Zc  = 19.0000 + 4.0000i
%
%  Ver tambi�n BICUA, COMPODE, COMPODEA, KRCKI, KRCIK2, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKALTO, VAEI y VAENOI 
%
%  Introducir     teapiz(Z1,Z2,Z3)   Z en ohm   

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   12 de Julio de 2002. Version 1.1

function y=teapiz(Z1,Z2,Z3)

% C�lculo de los componentes de la transformacion de T a Pi
nume=Z1*Z2+Z1*Z3+Z2*Z3;
Za=nume/Z3
Zb=nume/Z2
Zc=nume/Z1

fprintf('\r')

 


