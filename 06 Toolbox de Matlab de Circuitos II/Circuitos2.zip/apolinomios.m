% APOLINOMIOS ilustra como a partir de las ra�ces de un polinomio
% se pueden obtener los coeficientes del polinomio.
% Se utilizan en este ejemplo los r�ices 
% de la aproximaxi�n Butterworth

% � Copyright 2009. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   12 de Noviembre de 2009. Versi�n 1.

poly([-1 -0.5+j*0.8660254 -0.5-j*0.8660254])
poly([-0.38268343+j*0.92387953 -0.38268343-j*0.92387953 -0.92387953+j*0.38268343 -0.92387953-j*0.38268343])