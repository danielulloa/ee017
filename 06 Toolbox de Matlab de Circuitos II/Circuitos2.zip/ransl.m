% RANSL es una funcion que proporciona los valores de:
% del capacitor C1 y las resistencias R3 y R4=R5 
% de un filtro RANURA CON SIMULACI�N DE L
% cuando se le ingresa en este orden:              (Ojo con las Unidades)
%                       1) La frecuencia central del filtro en kHz
%                       2) El valor de Q
%                       3) Un valor de la Capacidad C2 en uF (microF)
%  
%  Ejemplo
%  1)  Datos fp= 1 kHz, Q=11.5 C2=1uF 
%  2)  Se introduce: ransl(1,11.5,1)
%  3)  Se obtiene:        
%           Filtro ranura con simulaci�n de L :
%  C1 = 0.47 nF  R3 = 14.7 kohm  R4=R5 = 7.32 kohm
%  (Las Resistencias R1=R2 se adoptan )
%
%  Ver tambien BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,
%              PRIMORK, RANDTA, RANDTP, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     ransl(fp,Q,C2)       

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function y=ransl(fp,Q,C2)

fp=fp*1000;
C2=C2*1e-6;

% Calculo del capacitor C1 y R4

C1=C2/(16*Q^2);
C1n=cnor(C1);
R4=sqrt(1/(4*pi^2*fp^2*C1n*C2));

% Valores normalizado m�s cercano

R4n=rnor(R4,1);
R3n=rnor(2*R4,1);

% Calculo del Q para su verificaci�n
Q=sqrt(C2/C1n)/4;

% Presentacion de los resultados
fprintf('\n')

fprintf('             Filtro ranura con simulaci�n de L :'),fprintf('\n')
fprintf('  C1'),exi(C1n),fprintf('F')
fprintf('  R3'),exi(R3n),fprintf('ohm')
fprintf('  R4=R5'),exi(R4n),fprintf('ohm'),fprintf('\n')
fprintf('  (Las Resistencias R1=R2 se adoptan )'),fprintf('\n')


 


