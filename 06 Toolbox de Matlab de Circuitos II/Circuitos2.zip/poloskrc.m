%  POLOSKRC es una funcion que proporciona:
%        La frecuencia fp , el Qp  y el valor de los polos de un filtro KRC
%  cuando se le ingresa:                         (Ojo con las unidades)
%                      1) El valor de la ganancia K
%                      2) El valor de la resistencia R en KOhms
%                      3) Un valor Capacitor en nF 
%
%  Ejemplo: Si K= 2, R= 10  KOHms y C=2.2  nF
%
%  Entonces:  poloskrc(2,10,2.2) proporciona:
%                    fp = 7.23432 KHz
%                    Qp = 1 
%                    Polos = 1.0e+004 *
%                           -2.2727 + 3.9365i  -2.2727 - 3.9365i
%  Para K=1 se produce la transicion entre raices reales (negativas) y complejas
%  Para K=3 se produce la transicion al semiplano derecho
%
%  Ver tambien BICUA, KRCI, KRCK2, PBDA, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     poloskrc(K,R,C)

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function y=poloskrc(K,R,C)

R=R*1000;
C=C*1e-9;
       
wp=1/(R*C);     
fp=wp/2/pi;
fprintf('\n')
fprintf('  fp'),exi(fp),fprintf('Hz'),fprintf('\n')
Qp=1/(3-K);
fprintf('  Qp'),exi(Qp),fprintf('\n')


p1= -wp/Qp/2 + 0.5 * sqrt((wp/Qp)^2-4*wp^2);
p2= -wp/Qp/2 - 0.5 * sqrt((wp/Qp)^2-4*wp^2);

Polos=[p1 p2]










