%	BESABAJO es un programa que suministra fp Y Qp para el dise�o de
%                    FILTROS BESSEL ACTIVOS PASABAJOS
% 	ingresando: 
%       1) La frecuencia de corte de 3dB de la banda de paso
%       2) El ORDEN n del filtro
%
%       Consultar tambien BESABAJ que permite el dise�o CALCULANDO 
%       el orden n del filtro. ESTO hay que hacerlo

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


fprintf('----------    PROYECTO DE FILTROS BESSEL ACTIVOS PASABAJOS    ----------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')

% Puesta a cero de los vectores

Qpolo=[];
Wpolo=[];
Wcero=[];
Wpolo3dB=[];
fpolo=[];
p=[];
p2=[];


% Ingresos de las frecuencias y las atenuaciones
f3dB=input('Ingresar la frecuencia de corte de 3dB en kHz:   ');
n=input('Ingresar el orden del filtro:   ');
f3dB=f3dB*1000;
fprintf(' \n\n')
% Calculo de los polos del filtro de Bessel

%1.- Coeficientes del polinomio de Bessel
c=[];
c(1)=prod(1:(2*n))/prod(1:n)/(2^n);
for i=1:n
c(i+1)=prod(1:(2*(n)-i))/prod(1:i)/prod(1:(n-i))/(2^(n-i));
end
c;

%2.- Polos del polinomio de Bessel
p=[];
for i=1:n+1
 p(i)=c(n+2-i);
end

p=roots(p);
p=cplxpair(p);

% Frecuencia de normalizacion de 3 dB

% Aca se da la tabla de la frecuencia que normaliza 
% los polinomios de Bessel hasta de orden 20
% para que la ganancia sea de -3 dB a una w=1.
% Lo hago mediante tabla para que sea m�s r�pido
wnorm(1)=1;
wnorm(2)=1.36165412871613;
wnorm(3)=1.75567236868121;
wnorm(4)=2.11391767490422;
wnorm(5)=2.42741070215263;
wnorm(6)=2.70339506120292;
wnorm(7)=2.95172214703872;
wnorm(8)=3.17961723751065;
wnorm(9)=3.39169313891166;
wnorm(10)=3.59098059456916;
wnorm(11)=3.77960741643962;
wnorm(12)=3.95915082114429;
wnorm(13)=4.13082549938354;
wnorm(14)=4.295593409533628;
wnorm(15)=4.454233021624372;
wnorm(16)=4.607385465472648;
wnorm(17)=4.755586548961151;
wnorm(18)=4.899289677284502;
wnorm(19)=5.038882681488201;
wnorm(20)=5.174700441742719;


wnorm=wnorm(n);  % Segun el orden del filtro se toma la frecuencia a la cual el modulo es igual a raiz de 2
W3dB=wnorm;  

%W3dB=1   % Si se le saca el signo de porcentaje se obtiene la Fc a WT=1



% De los polos agrupados en funciones de 2 orden, se obtiene el Q y la frecuencia

if rem(n,2)~=0   % Si el orden es impar
np=length(p)-1;

  for i=1:2:np
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    Wpolo3dB(i)=Wpolo(i)/W3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
    
  end

poloreal=p(length(p));

else
np=length(p);     % Si el orden es par
  for i=1:2:np
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    Wpolo3dB(i)=Wpolo(i)/W3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
    
  end
poloreal=[];
end

% Presentaci�n de los resultados en pantalla

fprintf('          * 2) fp y Q de cada etapa:'),fprintf(' \n')
fprintf(' \n\n')
fpolo=elicero(Wpolo3dB)*f3dB;
Qpolo=elicero(Qpolo);
for i=1:length(fpolo)
      
      fprintf('fp'),exi(fpolo(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo(i))
      fprintf(' \n\n')
end

fpreal=f3dB*(abs(poloreal)/W3dB); % La frecuencia del polo real que falta 
if rem(n,2)==0
fprintf('Filtro de orden par'),fprintf(' \n\n')
else
fprintf('Filtro de orden impar    ')
fprintf('fp de la Etapa de primer orden'),exi(fpreal),fprintf('Hz'),fprintf(' \n\n')
end

fprintf('-------    Fin del c�lculo de fp y Q del Filtro Bessel Pasabajos    -------------------------------------------------------'),fprintf('\n')

  