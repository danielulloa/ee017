% EXI sirve para pasar a EXponentes m�ltiplo de 3 como se usa 
% en Ingenier�a y se utiliza �nicamente dentro de programas
  
% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   05 de Junio de 2002. Version 1.1

function[]=exi(x);
exp=fix(log10(x));  % para hallar el exponente de la potencia
if exp < 0
exp=abs(exp);
if exp <= 3
y=x*10^3;
y1=fprintf(' = %g m',y);
elseif exp <=6
y=x*10^6;
y1=fprintf(' = %g �',y);
elseif exp <=9
y=x*10^9;
y1=fprintf(' = %g n',y);
elseif exp <=12
y=x*10^12;
y1=fprintf(' = %g p',y);
elseif exp <=15
y=x*10^15;
y1=fprintf(' = %g f',y);
elseif exp <=18
y=x*10^18;
y1=fprintf(' = %g a',y);
elseif exp <=21
y=x*10^21;
y1=fprintf(' = %g z',y);
elseif exp <=24
y=x*10^24;
y1=fprintf(' = %g y',y);

end

else

if exp < 3
y=x;
y1=fprintf(' = %g ',y);
elseif exp <6
y=x*10^(-3);
y1=fprintf(' = %g k',y);
elseif exp <=9
y=x*10^(-6);
y1=fprintf(' = %g M',y);
elseif exp <=12
y=x*10^(-9);
y1=fprintf(' = %g G',y);
elseif exp <=15
y=x*10^(-12);
y1=fprintf(' = %g T',y);
elseif exp <=18
y=x*10^(-15);
y1=fprintf(' = %g P',y);
elseif exp <=21
y=x*10^(-18);
y1=fprintf(' = %g E',y);
elseif exp <=24
y=x*10^(-21);
y1=fprintf(' = %g Z',y);
elseif exp <=27
y=x*10^(-24);
y1=fprintf(' = %g Y',y);
end

end