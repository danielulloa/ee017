%	CHEABAJO es un programa que suministra fp y el Q para el proyecto de
%                    FILTROS CHEBYSHEV ACTIVOS PASABAJOS 
% 	ingresando: 
%       1) La frecuencia de corte de 3dB de la banda de paso
%       2) La atenuacion maxima en la banda de paso (El ripple)
% 	3) El Orden n del filtro
%
%       Consultar tambien CHEABAJ que permite el proyecto CALCULANDO 
%       el orden n del filtro.

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

fprintf('----------    PROYECTO DE FILTROS CHEBYSHEV ACTIVOS PASABAJOS    ----------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')

% Puesta a cero de los vectores

Qpolo=[];
Wpolo=[];
Wcero=[];
Wpolo3dB=[];
fpolo=[];
p=[];
p2=[];

% Ingresos de las frecuencias y las atenuaciones
f3dB=input('Ingresar la frecuencia de corte de 3dB en kHz:   ');
Amax=input('Ingresar el ripple maximo en la banda de paso Amax en dB :   ');
n=input('Ingresar el orden del filtro:   ');
fs=f3dB;
f3dB=f3dB*1000;
fs=fs*1000;
fprintf(' \n\n')

% Calculo de los polos del filtro de Chebyshev
j = sqrt(-1);
epsilon = sqrt(10^(.1*Amax)-1);
mu = asinh(1/epsilon)/n;
p = exp(j*(pi*(1:2:2*n-1)/(2*n) + pi/2));
p = sinh(mu)*real(p) + j*cosh(mu)*imag(p);
z = []; % No tiene ceros este filtro en su funcion de transferencia
k = real(prod(-p));
p=cplxpair(p);
e=epsilon;

% Frecuencia de normalizacion de 3 dB

W3dB=cosh(acosh(1/e)/n);


% De los polos agrupados en funciones de 2 orden, se obtiene el Q y la frecuencia

if rem(n,2)~=0   % Si el orden es impar
np=length(p)-1;

  for i=1:2:np
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    Wpolo3dB(i)=Wpolo(i)/W3dB*f3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
  end

poloreal=p(length(p));

else
np=length(p);     % Si el orden es par
  for i=1:2:np
    Wpolo(i)=sqrt(real(p(i))^2+imag(p(i))^2);
    Wpolo3dB(i)=Wpolo(i)/W3dB*f3dB;
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));
  end
poloreal=[];
end

% Presentaci�n de los resultados en pantalla

fprintf('          * 2) fp y Q de cada etapa:'),fprintf(' \n')
fprintf(' \n\n')
fpolo=elicero(Wpolo3dB);
fpolo;
Qpolo=elicero(Qpolo);
for i=1:length(fpolo)
      
      fprintf('fp'),exi(fpolo(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo(i))
      fprintf(' \n\n')
end

fpreal=abs(poloreal)/W3dB*f3dB; % La frecuencia del polo real que falta 
if rem(n,2)==0
fprintf('Filtro de orden par')
else
fprintf('Filtro de orden impar    ')
fprintf('fpreal'),exi(fpreal),fprintf('Hz');fprintf(' \n\n')
end

fprintf('-------    Fin del c�lculo del fp y Q del Filtro Chebyshev Pasabajos    -------------------------------------------------------'),fprintf('\n')

  
