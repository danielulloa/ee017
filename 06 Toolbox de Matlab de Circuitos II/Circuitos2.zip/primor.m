% PRIMOR es una funci�n que proporciona el valor
%                la Resistencia 
% de una etapa pasabajos o pasaaltos de PRIMER ORDEN 
% cuando se le ingresa:                                 (Ojo con las unidades)
%                      1) La frecuencia del polo fp en KHz
%                      2) Un valor Capacitor en nF 
%
%              R               	              | | C                   
%   V1 o----/\/\/\-----*-----o V2 	 V1 o---- | |-----*-----o V2     
%                      |   		              | |     |       
%                    __|__        	                  \            
%                 C  _____          	              / R        
%                      |           	                  \               
%                     _|_       	                 _|_           
%                      -  		                      -      
%  Ejemplo:
%  1) Datos: Si la fp= 382.8 Hz y la capacidad elegida es de 33 nF
%
%  2) Se ingresa:  primor(.3828,33) 
%
%  3) Se obtiene:  R = 12.7 kohm  C = 33 nF 
%
%  Ver tambien BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     primor(fp,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   9 de Octubre de 2002. Version 1.1.1

function y=primor(fp,C)

fp=fp*1000;
C=C*1e-9;
C=cnor(C);       
R=1/(2*pi*fp*C);     
R=rnor(R,1);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('    Etapa de primer orden'),fprintf('\n')
fprintf('  R'),exi(R),fprintf('ohm')
fprintf('  C'),exi(C),fprintf('F'),fprintf('\n')
fprintf('\r')



