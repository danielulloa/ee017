% CNUEVO es una funcion que proporciona el valor de
%  la CAPACIDAD C de un filtro PASAALTOS
%  que se obtiene por transformacion y escalado de 
%  la INDUCTANCIA L del PASABAJOS NORMALIZADO
% cuando se le ingresa en este orden:          (Ojo con las Unidades)
%                       1) El valor de L pasabajos en H
%                       2) La frecuencia fc en KHz
%                       3) El factor de escala de impedancias Kz
%  
%  Ejemplo
%  1)  Datos L=1.02785H  f=300 Hz  Kz=1e5
%  2)  Se introduce: cnuevo(1.02785,0.3,1e5)
%  3)  Se obtiene:        
%   Cnuevo (correspondiente a L) del pasaaltos = 5.1 nF      
%
%  Ver tambien BICUA, COMPODE, COMPODEA, KRCKI, KRCIK2, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKALTO, VAEI y VAENOI 
%
%  Introducir     cnuevo(L,f,Kz)       

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function y=cnuevo(L,f,Kz)


f=f*1e3;

C=1/(2*pi*f*Kz*L);

% Valor normalizado m�s cercano

Cn=cnor(C);

% Presentacion de los resultados
fprintf('\n')

fprintf(' Cnuevo (correspondiente a L) del filtro pasaaltos'),exi(Cn),fprintf('F'),fprintf('\n')


 


