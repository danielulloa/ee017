% CAUER1 S�NTESIS DE UN CIRCUITO LC MEDIANTE LA 1� FORMA DE CAUER
% Este programa sintetiza una inmitancia (Impedancia o Admitancia)
% de tipo LC presentada en la forma de un cociente entre polinomios
% en la variable s mediante la forma de
% Cauer 1 (Extracci�n de polos en el infinito)
%
% Produce como salida la impedancia y la admitancia sintetizadas 
% mediante una descripci�n de la interconexi�n de los componentes
% y sus valores
%
% Ejemplo: Si la inmitancia a sintetizar es
% F(s)= (s^4+10s^2+9) / (s^3+ 4s)
% En el indicador de Matlab se ingresa:
%� cauer1
%Ingresar el Numerador en el formato [n(n) n(n-1)...n(0)]
% � [1 0 10 0 9]
%Ingresar el Denominador en el formato [d(n) d(n-1)...d(0)]
% � [1 0 4 0]
%  
% *** Impedancia Z(s)sintetizada mediante Cauer 1 ***
% Los terminales de la impedancia son los nodos 1(com�n) y 2
% y los componentes se conectan de la siguiente manera:
% Entre el nodo = 2  y el nodo = 3 :  L = 1 H
% Entre el nodo = 3  y el nodo = 1 :  C = 0.166667 F
% Entre el nodo = 3  y el nodo = 4 :  L = 2.4 H
% Entre el nodo = 4  y el nodo = 1 :  C = 0.277778 F .
%
% Para este ejemplo la impedancia Z(s) es:
%
%          2      L= 1 H     3     L=2.4 H    4      
%          o------/////------+------/////-----+
%                            |                |
%                           _|_              _|_
%                  C=0.167F ___     C=0.277F ___  
%                            |                |
%         1                  |                |
%          o-----------------+----------------+                            
%                
% *** Admitancia Y(s)sintetizada mediante Cauer 1 ***
% Los terminales de la admitancia son los nodos 1(com�n) y 2
% y los componentes se conectan de la siguiente manera:
% Entre el nodo = 2  y el nodo = 1 :  C = 1 F
% Entre el nodo = 2  y el nodo = 3 :  L = 0.166667 H
% Entre el nodo = 3  y el nodo = 1 :  C = 2.4 F
% Entre el nodo = 3  y el nodo = 1 :  L = 0.277778 H
%
% Ver tambi�n: CAUER2, FOSTER1 y FOSTER2


% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0


% Se borran las variables
clear n1 n2 pot t m n 

%Ingreso del numerador y denominador

fprintf('Ingresar el Numerador en el formato [n(n) n(n-1)...n(0)]'),fprintf('\n')
num=input(' � ');
fprintf('Ingresar el Denominador en el formato [d(n) d(n-1)...d(0)]'),fprintf('\n')
den=input(' � ');

% Para sintetizar la admitancia
num1=den;
den1=num;
% Se determina el grado del numerador y del denominador    
    m=length(num)-1;   % grado del numerador

    n=length(den)-1;   % grado del denominador

circuito=[];         % Se pone a cero la variable en la cual
                     % se introducen los componentes del circuito
   if m>n
      pot=1;      % El inductor se indica con 1
      n1=2;       % Inductor en Serie entre los nodos 2 y 3
      n2=3;
   else
      t=n;
      n=m;
      m=t;
      t=num;
      num=den;
      den=t;
      pot=-1;    % El Capacitor se indica con - 1
      n1=2;      % El capacitor va en paralelo entre el nodo 2 y el 1 
      n2=1;
   end
   while m>0
      [c,num]=deconv(num,den);
      t=n;
      n=m-2;
      m=t;
      t=den;
      den=num(3:length(num));
      num=t;
      circuito=[circuito;n1,n2,c(1),pot];
           pot=-pot;
      if n2==1
         if m==1 
            n2=1;
         else
            n2=n1+1;
         end
      else
         n1=n2;
         n2=1;
      end
   end
     
   %
% Visualizaci�n de la tabla que contiene el resultado de la s�ntesis 
% 
disp('  ')
%disp('Nodoinicial, Nodofinal, Valor(F o H), Tipo de Componente(1 -> L,-1 -> C)')

%circuito

% Para indicar la inmitancia sintetizada
tama=size(circuito);
numerodefilas=tama(1,1);numerodecolumnas=tama(1,2);
nodoi=circuito(1:numerodefilas,1);
nodof=circuito(1:numerodefilas,2);
valores=circuito(1:numerodefilas,numerodecolumnas-1);
componentes=circuito(1:numerodefilas,numerodecolumnas);

fprintf(' *** Impedancia Z(s) sintetizada mediante Cauer 1 ***'),fprintf('\n')
fprintf(' Los terminales de la impedancia son los nodos 1(com�n) y 2'),fprintf('\n')
fprintf(' y los componentes se conectan de la siguiente manera:'),fprintf('\n')

for k=1:numerodefilas
    fprintf(' Entre el nodo'),exi(nodoi(k)),fprintf(' y el nodo'),exi(nodof(k))

   if componentes(k)==1
      fprintf(':  L'),exi(valores(k)),fprintf('H'),fprintf('\n')

   else
      fprintf(':  C'),exi(valores(k)),fprintf('F'),fprintf('\n')
   end
   
end
disp('  ')
% S�ntesis de la admitancia
num=num1;
den=den1;
% Se determina el grado del numerador y del denominador    
    m=length(num)-1;   % grado del numerador

    n=length(den)-1;   % grado del denominador

circuito=[];         % Se pone a cero la variable en la cual
                     % se introducen los componentes del circuito
   if m>n
      pot=1;      % El inductor se indica con 1
      n1=2;       % Inductor en Serie entre los nodos 2 y 3
      n2=3;
   else
      t=n;
      n=m;
      m=t;
      t=num;
      num=den;
      den=t;
      pot=-1;    % El Capacitor se indica con - 1
      n1=2;      % El capacitor va en paralelo entre el nodo 2 y el 1 
      n2=1;
   end
   while m>0
      [c,num]=deconv(num,den);
      t=n;
      n=m-2;
      m=t;
      t=den;
      den=num(3:length(num));
      num=t;
      circuito=[circuito;n1,n2,c(1),pot];
           pot=-pot;
      if n2==1
         if m==1 
            n2=1;
         else
            n2=n1+1;
         end
      else
         n1=n2;
         n2=1;
      end
   end
     
   %
% Visualizaci�n de la tabla que contiene el resultado de la s�ntesis 
% 
disp('  ')
%disp('Nodoinicial, Nodofinal, Valor(F o H), Tipo de Componente(1 -> L,-1 -> C)')

%circuito

% Para indicar la inmitancia sintetizada
tama=size(circuito);
numerodefilas=tama(1,1);numerodecolumnas=tama(1,2);
nodoi=circuito(1:numerodefilas,1);
nodof=circuito(1:numerodefilas,2);
valores=circuito(1:numerodefilas,numerodecolumnas-1);
componentes=circuito(1:numerodefilas,numerodecolumnas);

fprintf(' *** Admitancia Y(s) sintetizada mediante Cauer 1 ***'),fprintf('\n')
fprintf(' Los terminales de la admitancia son los nodos 1(com�n) y 2'),fprintf('\n')
fprintf(' y los componentes se conectan de la siguiente manera:'),fprintf('\n')

for k=1:numerodefilas
    fprintf(' Entre el nodo'),exi(nodoi(k)),fprintf(' y el nodo'),exi(nodof(k))

   if componentes(k)==1
      fprintf(':  L'),exi(valores(k)),fprintf('H'),fprintf('\n')

   else
      fprintf(':  C'),exi(valores(k)),fprintf('F'),fprintf('\n')
   end
   
end

fprintf('\r')



               