% LSIMUL es una funci�n que proporciona los valores de:
% las resistencias R1=R2=R3=R5
% de un CONVERSOR GENERALIZADO DE IMPEDANCIAS 
% PARA SIMULAR L CON UN BORNE A MASA
% cuando se le ingresa en este orden:    (Ojo con las Unidades)
%                       1) El valor de L en H
%                       2) Un valor adoptado de C4 en nF
%	                     o              	
%		                 | 	     	      	 
%    	                 *-----+          
%	 	                 >     |               
%	 	              R1 <     |                
%	                     |     |   |`.         
%	  +------------------*     +---|+ `.       
%	  |                  |         |    >---+  
%	  |                  >     +---|- ,'    |  
%	  |               R2 <	   |   |,'      |  
%	  |                  |     |    	    |  
%	  |            +-----*-----+            |  
%	  |            |     |	                |  
%	  |            |     > R3               |  
%	  |      .�|   |     <	                |  
%	  |    .� -|---+     |                  |  
%	  +---<    |         *------------------+  
%	       `. +|---+   __|__        		   
%  	         `.|   |   _____ C4       		
%	               |     | 	    	    	
%	               +-----*          	    	
%	                     |              
%	    	             > R5          
%	    	             <  
% 		       	        _|_     
% Ejemplo:	             -   
%  1)  Datos L=56.724H  C=10 nF 
%  2)  Se introduce: lsimul(56.724,10)
%  3)  Se obtiene:        
%        Conversor generalizado de Impedancias simulando L:
%
%            R1=R2=R3=R5 = 75 kohm  C4 = 10 nF
%
%  Ver tambi�n: BICUA, CNUEVO, COMPODE, COMPODEA, KRCI, KRCK2, LNUEVO,
%               POLOSKRC, PRIMOR, PRIMORK,RANDTA, RANDTP, RANSL, RM,
%               RNUEVO, SK, SK3BUT, SK3BUTA,SKPA, VAEI y VAENOI 
%
%  Introducir     lsimul(L,C)   L en H, C en nF     

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   11 de Julio de 2002. Version 1.1

function y=lsimul(L,C2)


C2=C2*1e-9;
C2=cnor(C2);
R=sqrt(L/C2);

% Valor normalizado m�s cercano

Rn=lnor(R);

% Presentaci�n de los resultados
fprintf('\n')

fprintf('        Conversor generalizado de Impedancias simulando L:'),fprintf('\n\n')
fprintf('            R1=R2=R3=R5'),exi(Rn),fprintf('ohm'),fprintf('    C4'),exi(C2),fprintf('F'),fprintf('\n')


 


