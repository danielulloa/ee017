% TLABA realiza la conversi�n de una red T de inductancias L 
% a Bobinas Acopladas y proporciona los valores de:
% L1, L2 y M del las bobinas acopladas equivalentes a una
% red T de inductancias.
% cuando se le ingresa en este orden:          (Ojo con las Unidades)
%       1) La de la red T en H (Rama horizontal izquierda de la T)
%       2) Lb de la red T en H (Rama horizontal derecha de la T)
%       3) Lc de la red T en H (Rama vertical de la T)
%
% Se puede usar esta conversi�n para eliminar los valores negativos
% de las inductancias que pueden aparecer en los procedimientos
% de s�ntesis.
%
% Ejemplo:
%   1)  Datos: La = 1,5 H, Lb = -0.25, Lc = 1.5
%   2)  Se introduce: tlaba(1.5,-0.25,1.5)
%   3)  Se obtiene: L1 = 3 H  L2 = 1.25 H  M = 1.5 H
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, PASATODO2, POLOSKRC, PRIMOR, 
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%              
%  Introducir     tlaba(La,Lb,Lc)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   5 de Julio de 2002. Version 1.0

function y=tlaba(La,Lb,Lc)

% C�lculo de la inductancias e inductancia m�tua
L1=La+Lc;
L2=Lb+Lc;
M=Lc;

% Valores de los inductores expresados con los prefijos del S.I.
fprintf('  L1'),exi(L1),fprintf('H')
fprintf('  L2'),exi(L2),fprintf('H')
fprintf('  M'),exi(M),fprintf('H'),fprintf('\n')



