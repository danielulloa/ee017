% SK es una funci�n que proporciona los valores de:
% las Resistencias y Capacitores
% de una etapa activa PASABAJOS SALLEN KEY de 2� orden 
% cuando se le ingresa:                          Ojo con las unidades)
%                      1) La frecuencia del polo fp en kHz
%                      2) El Q de la etapa y 
%                      3) Un valor de la resistencia en kohm
%   			             | | nC         	 	     
%                    +-------| |--------*------------+     
%                    |	     | |	    |            |
%                    |                  |   |`.      |       
%                    |                  +---|- `.    |       
%             mR     |      R               |    >---*---o V2
%    V1 o---/\/\/\---*---/\/\/\---*---------|+ ,'            
%                                 |         |,'                  
%                               __|__         
%                            C  _____        
%                                 |              
%                                _|_           
%  Ejemplo:                       -                                      
%  
%  1) Datos:  Si fp= 4520 Hz, Q= 0.761 y R= 10.5kohm
%
%  2) Se ingresa:   sk(4.52,0.761,10.5) 
%
%  3) Se obtiene:  mR = 10.7 kohm  R = 10.2 kohm  C = 2.2 nF  nC = 5.1 nF   
%
%  Ver tambi�n: BICUA, KRCI, KRCK2, PBDA, PTA1, PTA2, PTP1, PTP2,
%               POLOSKRC, PRIMOR, PRIMORK, RANDTA, RANDTP, RANSL,
%               RM, SKPA, VAEI y VAENOI 
%
%  Introducir     sk(fp,Q,R)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1

function y=sk(f0,Q,Ra)

% Adecuaci�n de los datos
f0=f0*1000;
Ra=Ra*1000;

% C�lculo del Capacitor C
Ca=1/(4*pi*Q*f0*Ra);
C=cnor(Ca);

% C�lculo del na
na= 4*Q^2;
naC=na*C;

% C�lculo de nC
nC=cnor(naC);
n=nC/C;

if n < na
nC=sigui(nC);
n=nC/C;
end

% C�lculo de m
k=n/Q^2-2;
m=(k+sqrt((k^2)-4))/2;

%C�lculo de R y mR
R= 1/(2*pi*sqrt(m*n)*f0*C);
R=rnor(R,1);

mR=m*R;
mR=rnor(mR,1);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('    Etapa Sallen-Key'),fprintf('\n')
fprintf('  mR'),exi(mR),fprintf('ohm')
fprintf('  R'),exi(R),fprintf('ohm')
fprintf('  C'),exi(C),fprintf('F')
fprintf('  nC'),exi(nC),fprintf('F')
fprintf('\n')
fprintf('\r')



