% WYQ proporciona el wp y Q de un polinomio de
% segundo orden:  a2*s^2 + a1*s + a0
% ingresado como [a2 a1 a0]
%
% Ejemplo: 
%        1)Datos: Si el polinomio es:  s^2+ 1.3764 s +1.3764
% 
%        2)Se ingresa: a=[1 1.3764 1.3764]; wyq(a)
%
%        3)Se obtiene: wp = 1.1732   Q = 0.852369  
% 
%  Introducir     wyq(a)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0

function y=wyq(a)
if a(1)==1
wp=sqrt(a(3));
Q=wp/a(2);
else
wp=sqrt(a(3)/a(1));
Q=wp/(a(2)/a(1));
end
fprintf(' wp'),exi(wp),fprintf('  Q'),exi(Q),fprintf('\n'),fprintf('\n')