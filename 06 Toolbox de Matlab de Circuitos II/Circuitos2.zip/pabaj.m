% PABAJ se utiliza para obtener los valores desnormalizados 
% o de trabajo de los componentes de los filtros PasaBajos
% a partir de los componentes de filtros prototipos pasabajos 
% que figuran en forma normalizada en las tablas con Wc = 1 rad/s
% cuando se le ingresa en este orden:              
%  1) Los valores normalizados de L y C 
%  2) El factor de escala de impedancias Kz
%  3) La frecuencia de desnormalizaci�n f en kHz (ojo)   
%
%  Ejemplo:
%  1)  Lp=0.41135 H   Cp=0.81023 F   Kz=100  f=1000 Hz
%  2)  Se introduce:  pabaj(0.41135,0.81023,100,1)
%  3)  Se obtiene:        
% Valores Prototipo            Valores Pasabajos: 
%   Lp = 0.41135                Ld = 6.54684 mH
%   Cp = 0.81023                Cd = 1.28952 �F
%
%  Ver tambi�n CNUEVO, LNUEVO, PAALT, PABAN, PASUP, RNUEVO
%
%             Lp                              Ld    
%      o----//////----o     ====>      o----//////----o   
%          
%             Cp                              Cd            
%      o-----| |-----o      ====>      o-----| |-----o     
%
%  Introducir  pabaj(Lp,Cp,Kz,f[kHz]) 

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1


function y=pabaj(Lp,Cp,Kz,f)  
Kf=1000*2*pi*f;
Ld=Kz*Lp/Kf;
Cd=Cp/(Kz*Kf);

fprintf('\n')
fprintf(' Valores Prototipo            Valores Pasabajos: '),fprintf('\n')

if Lp~=0
fprintf('   Lp'),exi(Lp),fprintf('            '),fprintf('   Ld'),exi(Ld),fprintf('H'),fprintf('\n')
end
if Cp~=0
fprintf('   Cp'),exi(Cp),fprintf('            '),fprintf('   Cd'),exi(Cd),fprintf('F'),fprintf('\n')
end
fprintf('\r')
