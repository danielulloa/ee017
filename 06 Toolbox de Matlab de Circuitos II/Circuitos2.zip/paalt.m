% PAALT se utiliza para obtener los valores desnormalizados 
% o de trabajo de los componentes de los filtros PasaAltos
% a partir de los componentes de filtros prototipos pasabajos 
% que figuran en forma normalizada en las tablas con Wc = 1 rad/s
% cuando se le ingresa en este orden:          
%  1) Los valores del filtro prototipo de L y C 
%  2) El factor de escala de impedancias Kz
%  3) La frecuencia de desnormalizaci�n f en kHz (ojo) 
%
%  Ejemplo:
%  1)  Lp=1.03697 H   Cp=1.41958 F   Kz=300  f=525000 Hz
%  2)  Se introduce:  paalt(1.03697,1.41958,300,525)
%  3)  Se obtiene:        
%  Valores Prototipo             Valores Pasaaltos: 
%   Lp = 1.03697                  Ca = 0.974481 nF
%   Cp = 1.41958                  La = 64.0652 �H
%
%  Ver tambi�n CNUEVO, LNUEVO, PABAJ, PABAN, PASUP, RNUEVO
%
%                 Lp                              Ca
%          o----//////----o     ====>      o-----| |-----o
%        
%                 Cp                              La        
%          o-----| |-----o       ====>     o----//////----o 
%
%  Introducir  paalt(Lp,Cp,Kz,f[kHz])   

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1


function y=paalt(Lp,Cp,Kz,f)  
Kf=f*1000*2*pi;
La=Kz/(Kf*Cp);
Ca=1/(Kz*Kf*Lp);

fprintf('\n')
fprintf(' Valores Prototipo             Valores Pasaaltos: '),fprintf('\n')

if Lp~=0
fprintf('   Lp'),exi(Lp),fprintf('            '),fprintf('    Ca'),exi(Ca),fprintf('F'),fprintf('\n')
end
if Cp~=0
fprintf('   Cp'),exi(Cp),fprintf('            '),fprintf('    La'),exi(La),fprintf('H'),fprintf('\n')
end
fprintf('\r')
