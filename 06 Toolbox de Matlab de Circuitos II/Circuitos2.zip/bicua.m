% BICUA es una funcion que proporciona los valores de:
% las Resistencias R, R1, R4 y R5
% de una etapa activa  BICUADRATICA RANURA SIMETRICO,
%                      RANURA PASABAJOS O RANURA PASALTOS
% cuando se le ingresa en este orden:                  (Ojo con las Unidades)
%                       1) La frecuencia del polo fp en KHz
%                       2) La frecuencia del cero fz en KHz 
%                       3) El Q de la etapa
%                       4) Un valor de Resistencia R2 en KOhms 
%                       5) Un valor de Capacidad en nF
%                       6) La ganancia Ho en dB
%  
%  Ejemplo 1: 
%  1)  Datos fp= 1000 Hz, fz = 1000Hz Q=20, R2=100KOhms , C=10 nF y Ho= 0 dB
%  2)  Se introduce: bicua(1,1,20,100,10,0)
%  3)  Se obtiene:         Filtro Bicuadratico Ranura simetrico:
%                       R = 15.8 KOhms  R1 = 316 KOhms  R5 = 100 KOhms
%  Ejemplo 2:
%  1)  Datos fp= 1000 Hz, fz = 3000 Hz Q=20, R2=100KOhms , C=10 nF y Ho= 0 dB
%  2)  Se introduce: bicua(1,3,20,100,10,0)
%  3)  Se obtiene:         Filtro Bicuadratico Ranura Pasabajos :
%                 R = 15.8 KOhms  R1 = 316 KOhms  R4 = 619 Ohms  R5 = 11 KOhms
%  Ejemplo 3:
%  1)  Datos fp= 1000 Hz, fz= 700 Hz Q=20, R2=100KOhms , C=10 nF y Ho= 0 dB
%  2)  Se introduce: bicua(1,.7,20,100,10,0)
%  3)  Se obtiene:        Filtro Bicuadratico Ranura Pasaaltos :
%                 R = 15.8 KOhms  R1 = 316 KOhms  R4 = 9.76 KOhms  R5 = 100 KOhms
%
%  Ver tambien KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%  Introducir     bicua(fp,fz,Q,R2,C,HodB)       

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0

function y=bicua(fp,fz,Q,R2,C,HodB)

fp=fp*1000;
fz=fz*1000;
R2=R2*1000;
C=C*1e-9;
Ho=10^(HodB/20);

R=1/(2*pi*fp*C);
R1=Q*R;

if fz ~= fp
 R4=R2/Q*fp^2/abs(fp^2-fz^2);
else
   R4 = inf;
end


if fz > fp
 R5=Ho*R2*(fp/fz)^2;
else
 R5=R2*Ho;
end


% Valor normalizado m�s cercano
Rn=rnor(R,1);
R1n=rnor(R1,1);
R4n=rnor(R4,1);
R5n=rnor(R5,1);

% Presentacion de los resultados
fprintf('\n\n')
if fz == fp
 fprintf('             Filtro Bicuadratico Ranura simetrico:'),fprintf('\n')
elseif fz > fp
 fprintf('             Filtro Bicuadratico Ranura Pasabajos :'),fprintf('\n')
else
 fprintf('             Filtro Bicuadratico Ranura Pasaaltos :'),fprintf('\n')
end

fprintf('  R'),exi(Rn),fprintf('Ohms')         
fprintf('  R1'),exi(R1n),fprintf('Ohms')
if fz ~= fp
 fprintf('  R4'),exi(R4n),fprintf('Ohms')
end
fprintf('  R5'),exi(R5n),fprintf('Ohms'),fprintf('\n')
fprintf('\n\n')

