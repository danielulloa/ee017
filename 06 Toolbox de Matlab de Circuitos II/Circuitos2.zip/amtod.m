% AMTOD es una funci�n que proporciona los valores de
% las resistencias y capacitores de una etapa activa
% Akerberg-Mossberg pasaTodo de 2� orden 
% cuando se le ingresa:                          (Ojo con las unidades)
%                      1) La frecuencia del polo en kHz
%                      2) El Q de la etapa
%                      3) Un valor del capacitor C en nF 
%  Ejemplo:
%  1) Datos: Si fp= 1000 Hz, el Q= 5, 
%            y el C elegido es = 10nF  
% 
%  2) Se ingresa:   amtod(1,5,10)
%
%  3) Se obtiene:
%                Etapa AM pasaTodo
%                R = 15.8 kohm   R/b = 78.7 kohm
%                QR = 78.7 kohm   C = 10 nF
%  			                                     
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, POLOSKRC, PRIMOR,BGPJ,BGPA,BGPB,
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, VAEI y VAENOI 
%
% 	           +------------------------/\/\/\------------------------------+    
% 	           | 		                   R             R                  |    
% 	           |     QR                            +---/\/\/\---+   	    |	
% 	           *---/\/\/\----+	                   |            |	        |	
% 	           |	         |	              C    |      .�|   |	   R    |
% 	           |     | | C   |	             | |   |    .� -|---*-*-/\/\/\--* 
% 	           *-----| |-----*           +---| |---*---<    |     | 	    |   
% 	           |     | |     |	         |   | |        `. +|--+  |	        |	
% 	      C    |	         |	         |                `.|  |  |	        |
% V1     | |   |    |`.      |	         |                    _|_ |	        |	
%  o--*--| |---*----|- `.    |	   R     |   |`.               -  |	        |    
%  	  |	 | |        |    >---*--/\/\/\---*---|+ `.     		      | 	    |  
%  	  | 	   +----|+ ,'    |	        /    |    >-------------------------+
% 	  |        |    |,'  	 | 	       /  +--|- ,'        		  |           
% 	  |       _|_     		 o V2     /   |  |,'      		      |
% 	  |        -      		         /   _|_         		      |
% 	  |  			  R             /     -                       |
%     *-------------/\/\/\---------+                              |
%     |                                        R/b                |
%     +--------------------------------------/\/\/\---------------+
%
%  Introducir     amtod(fp,Q,C)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.1.

function y=amtod(fp,Q,C)


% Se calcula b

b=1/Q;

% Se adecuan los datos:
fp=fp*1000;
C=C*1e-9;
C=cnor(C);

% Se calcula R
R=1/(2*pi*fp*C);

% Se calcula QR
QR=Q*R;
QR=rnor(QR,1);

% Se calcula R/b
Rsb=R/b;
Rsb=rnor(Rsb,1);


% Se normaliza R
R=rnor(R,1);

% Se muestran los resultados en pantalla
fprintf('\n')
fprintf('   Etapa AM pasaTodo'),fprintf('\n')
fprintf('   R'),exi(R),fprintf('ohm')
fprintf('   R/b'),exi(Rsb),fprintf('ohm'),fprintf('\n')
fprintf('   QR'),exi(QR),fprintf('ohm')
fprintf('   C'),exi(C),fprintf('F'),fprintf('\n\n')       





