% PBDA es una funci�n que proporciona los valores de:
% las resistencias R1=R2 y R3 de
% de un filtro  PASABANDA DE DOS AMPLIFICADORES
% cuando se le ingresa en este orden:              (Ojo con las Unidades)
%                       1) La frecuencia central del filtro en kHz
%                       2) El Q de la etapa
%                       3) Un valor de la Capacidad C en nF
%                               
%                           .�|   		                   R4     
%			              .� +|--------------------*---/\/\/\---+ 
%                    +---<    |                    |            |
%		             |	  `. -|------+	           /	        | 
%		             |	    `.|      |             \ R4	       _|_
%		             |		         |             /	        - 
%                    |      | |      |    	       |	       	 
%                    *------| |------*---/\/\/\----*             
%                    |      | | C    |     R2	   |             
%                    /	             |             |		 
%                    \ R1            |    |`.      |	        
%                    /               +----|- `.    | 	        
%             R3     |                    |    >---*---o V2        
%    V1 o---/\/\/\---*--------------------|+ ,'           
%                    |                    |,'         
%                  __|__                               
%                  _____ C                               
%                    |                       
%                   _|_                      
%                    -               
%  Ejemplo:
%  1)  Datos: fp= 2 kHz, Q=20, C=10 nF 
%  2)  Se introduce: pbda(2,20,10)
%  3)  Se obtiene:        
%  Filtro  Pasabanda de dos amplificadores
%  R1=R2 = 7.87 kohm  R3 = 158 kohm
%  (Las resistencias R4 del divisor de tensi�n se adoptan )
%
%  Ver tambi�n BICUA, KRCI, KRCK2, POLOSKRC, PRIMOR, PRIMORK,
%              RANDTA, RANDTP, RANSL, RM, SK, SKALTO, VAEI y VAENOI 
%
%  Introducir     pbda(fp,Q,C)       

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   11 de Julio de 2002. Version 1.2

function y=pbda(fp,Q,C)

fp=fp*1000;
C=C*1e-9;

R=1/(2*pi*fp*C);
R3=Q*R;

% Valores normalizados m�s cercanos

Rn=rnor(R,1);
R3n=rnor(R3,1);

% Presentaci�n de los resultados
fprintf('\n')
fprintf('   Filtro Pasabanda de dos amplificadores'),fprintf('\n')
fprintf('   R1=R2'),exi(Rn),fprintf('ohm')
fprintf('  R3'),exi(R3n),fprintf('ohm'),fprintf('\n')
fprintf('  (Las resistencias R4 del divisor de tensi�n se adoptan)'),fprintf('\n')
fprintf('\r')



 


