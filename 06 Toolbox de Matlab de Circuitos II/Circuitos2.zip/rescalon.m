% RESCALON
% Crea un grafico de malla o de superficie que muestra el efecto
% de aumentar la parte real de un par de polos
% complejos conjugados

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   3 de Julio del 2002. Version 1.0

clf
t=[0:0.05:5];
numerodepolos = 12;
y = zeros(length(t),numerodepolos);
n=1;
while n<=numerodepolos,
     [num,den]=zp2tf([],[-n/4+3*i  -n/4-3*i],(n/4)^2+9);
     [y(1:length(t),n),x,tmuda]=step(num,den,t);
     n=n+1;
end
mesh(y')
% surf(y')
title('Grafico que muestra la Respuesta al Escal�n para doce ubicaciones de los polos ')
titulos
