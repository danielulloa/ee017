% DBF proporciona el valor en dB de una relaci�n
% de tensiones o corrientes entre dos puntos de
% un circuito son la salida formateada
% �nicamente si esas variables se miden sobre 
% resistencias iguales da la relaci�n de potencias.
% 
% Ejemplo: dbf(1/sqrt(2))
%                  = -3.0103 dB
%
% Introducir dbf(x)

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   15 de Julio de 2002. Version 1.0

function y=dbf(x);
if x==0
    fprintf(' La definici�n de decibel es: dB(x)=20*log10(abs(x))'),fprintf('\n')
    fprintf('��A qui�n se le ocurre tomar el logar�tmo de cero?!')
    fprintf('\n')
    fprintf('\r')
break
end
if x~=1
a=20*log10(abs(x));
	% Presentaci�n de los resultados
	fprintf('          '),exi(a),fprintf('dB')
	fprintf('\n')
	fprintf('\r')
else
    fprintf('           = 0 dB')
	fprintf('\n')
	fprintf('\r')
end

