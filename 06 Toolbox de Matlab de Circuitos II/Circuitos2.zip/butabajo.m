%	BUTABAJO  Es un programa para el proyecto de
%                FILTROS BUTTERWORH ACTIVOS PASABAJOS
% 	ingresando: 
%       1) La frecuencia de corte de 3 dB de la banda de paso
%       2) El orden del filtro           

% � Copyright 2000. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   19 de Octubre de 2000. Version 1.0


% 1.- Introduccion de los datos y conversion de los mismos a datos para el pasabajos equivalente

fprintf('----------   PROYECTO DE FILTROS BUTTERWORTH ACTIVOS PASABAJOS   ----------'),fprintf('\n\n')
fprintf('          * 1) Ingreso de las especificaciones   '),fprintf('\n')

% Puesta a cero de los vectores

Qpolo=[];
Wpolo=[];
a0=[];
a1=[];

% Ingreso de los valores de frecuencia y de atenuacion

f0=input('Ingresar la frecuencia corte de 3 dB en KHz:   ');
n=input('Ingresar el orden del filtro pasabajos:   ');
f0=f0*1000;
fprintf('\n\n')

% Calculo de los polos del filtro de Butterworth pasabajos

z = [];
p = exp(sqrt(-1)*(pi*(1:2:2*n-1)/(2*n) + pi/2));
p=cplxpair(p);
k = real(prod(-p));

% De los polos agrupados en funciones de 2 orden,
% se obtiene el Qp y las fp y con ellos se calculan los
% coeficientes del los factores bicuadraticos

if rem(n,2)~=0   % Si el orden es impar
ni=length(p)-1;

  for i=1:2:ni
    Wpolo(i)=abs(p(i));
    Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));

% Coeficientes de los factores bicuadraticos  
   
    a0(i)=Wpolo(i)^2;
    a1(i)=sqrt(a0(i))/Qpolo(i);
    
  end

% Calculo del polo real. Se lo extrae como �ltimo polo del vector de polos

poloreal=p(length(p));

else

np=length(p);     % Si el orden es par
  for i=1:2:np
    
     Wpolo(i)=abs(p(i));
     Qpolo(i)=Wpolo(i)/2/abs(real(p(i)));

% Coeficientes de los factores bicuadraticos  
% por si interesan 
    a0(i)=Wpolo(i)^2;
    a1(i)=sqrt(a0(i))/Qpolo(i);

  end

poloreal=[];

end


% Presentaci�n de los resultados en pantalla

fprintf('          * 2) fp y Q de cada etapa:'),fprintf(' \n')
fprintf(' \n\n')

fpolo=elicero(Wpolo)*f0;
Qpolo=elicero(Qpolo);
for i=1:length(fpolo)
      
      fprintf('fp'),exi(fpolo(i)),fprintf('Hz'),fprintf('    Qp'),exi(Qpolo(i))
      fprintf(' \n\n')
end

fpreal=abs(poloreal)*f0; % La frecuencia del polo real que falta 
if rem(n,2)==0
fprintf('Filtro de orden par')
else
fprintf('Filtro de orden impar    ')
fprintf('fpreal'),exi(fpreal),fprintf('Hz'),fprintf(' \n\n')
end



fprintf('-------    Fin del c�lculo de fp y Q del Filtro Butterworth Activo Pasabajos    -------------------------------------------------------'),fprintf('\n')

  