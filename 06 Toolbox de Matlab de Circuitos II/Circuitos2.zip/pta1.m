% PTA1 es una funci�n que proporciona los valores de
% R de la etapa PasaTodo Activa bilineal de 1� orden 
% con un Amplificador Operacional
%
% cuando se le ingresa en este orden:         Ojo con las Unidades)
%                       1) wp de la etapa normalizada
%                       2) El tiempo de retardo T que va a
%                          proporcionar la etapa en us (microsegundos)
%                       3) Un valor de la Capacidad C en nF
%  Ejemplo:
%  1)  Datos: Si s + wp = s + 3.64674, el retardo de
%             la etapa es 100us  y se adopta C=1nF
%  2)  Se introduce: pta1(3.64674,100,1)
%  3)  Se obtiene:        
%                 Etapa Pasatodo Activa de 1� orden:
%                 R = 13.7 kohm.  Se adopt�: C = 1 nF
%
%  Ver tambi�n BICUA, KRCI, KRCK2, PBDA, PTA2, PTP1, PTP2, POLOSKRC, PRIMOR, 
%              PRIMORK, RANDTA, RANDTP, RANSL, RM, SK, SKPA, VAEI y VAENOI 
%
%                                       R
%                                +---/\/\/\-----+   
%                     	         |              |
%                         R      |    |`.       |       
%                  +---/\/\/\----*----|- `.     |       
%          V1 o----*                  |    >----*---o V2    
%                  +---/\/\/\----*----|+ ,'                     
%                         R      |    |,'                     
%                              __|__           
%                            C _____
%                                |
%                               _|_ 
%                                -
%  Introducir     pta1(wp,T[us],C[nF])

% � Copyright 2002. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenieria. Universidad Nacional de la Patagonia SJB
%   5 de Julio de 2002. Version 1.0

function y=pta1(a0,Tet,C)

Te=Tet/1e6;   % Retardo de la etapa bilineal en segundos
T=Te/2;       % Retardo de las transferencias de Bessel
Kf=1/T;       % El factor de frecuencia es la inversa del retardo

% C�lculo de wp de la transferencia 
wp=a0;
wpd=wp*Kf;

% C�lculo del valor de la resistencia
C=C*1e-9;
R=1/(wpd*C);


% Valores normalizados m�s cercanos

Rn=rnor(R,1);

% Presentacion de los resultados
fprintf('\n')
fprintf('     Etapa Pasatodo Activa de 1� orden:'),fprintf('\n')
fprintf('     R'),exi(Rn),fprintf('ohm.')
fprintf('  Se adopt�: C'),exi(C),fprintf('F')
fprintf('\n')
fprintf('\r')





