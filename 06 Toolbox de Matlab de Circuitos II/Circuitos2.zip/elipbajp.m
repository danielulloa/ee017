%	ELIPBAJP es un programa que permite obtener
%  por s�ntesis mediante el procedimiento de Darlington 
%  los componentes L Y C de
%  de filtros EL�pticos Pasivos pasaBAJos Prototipo
%  con la salida indicada como:
%
%           "L entre nodos y Ramas Resonantes LC Serie a masa"
%
%           pero que tambi�n proporciona la configuraci�n de
%
%           "C a masa y Ramas Resonantes LC Paralelo entre nodos"
%
%           si se toman los valores de L entre nodos como C a masa
%           y los valores de L en serie como Cpar y de C en serie como Lpar   
%          
%           Adem�s, antes de cada circuito resonante, indica el cero de 
%           transmisi�n que es igual a la pulsaci�n de resonancia en rad/s
%           
% 	ingresando: 
%       1) El orden n del filtro (S�lo ordenes impares)
%       2) La atenuaci�n m�xima en la banda de paso en dB
%       3) La atenuaci�n m�nima en la banda de atenuacion en dB  
%
%   A partir del filtro prototipo y utilizando las funciones
%   paalt, pabaj, paban y pasup del Toolbox de Circuitos II
%   se pueden obtener los filtros El�pticos 
%   pasaaltos, pasabajos, pasabanda y suprimebanda 
%   a la frecuencia de trabajo o filtros desnormalizados.

% Para determinar los componentes del filtro el�ptico se
% utiliza el m�todo de Darlington y la s�ntesis de Inmitancias
% para la formaci�n de ceros.
      
% � Copyright 2010. * Teor�a de Circuitos II * . Departamento de Electr�nica.
%   Facultad de Ingenier�a. Universidad Nacional de la Patagonia SJB
%   28 de Julio de 2010. �Versi�n todav�a en trabajo!

fprintf('******   Proyecto de Filtros PROTOTIPOS El�pticos Pasivos Pasabajos   ******'),fprintf('\n\n')

% Ingresos de los datos de frecuencia y atenuaci�n
n=input('Ingresar el orden del filtro:   ');

while (rem(n,2)==0),
       fprintf('S�lo calcula filtros de orden impar. ') 
       n=input('Ingresar un orden impar :   ');
end

Amax=input('Ingresar la Atenuaci�n m�xima en la banda de paso Amax en dB :  ');
Amin=input('Ingresar la Atenuaci�n m�nima en la banda de atenuaci�n Amin en dB:  ');


% Introducci�n de las resistencias del generador y de carga

R1=1;
R2=1;

fprintf('      Calculando .... '),fprintf('\n\n') 

% C�lculo de los polos del filtro el�ptico

[z,p,k]=ellipap(n,Amax,Amin);

% Datos del filtro prototipo
f0=1;
w0=1;
R0=1;

Kn=k;

NH=poly(z);
DH=poly(p);
NH=real(NH); % Polinomio de numerador
DH=real(DH); % Polinomio del denominador de la funcion de transferencia

K0=R2/(R1+R2);

K=4*(R1/R2)*(K0*Kn)^2;

NHneg=negativo(NH);
DHneg=negativo(DH);

Numc=K*conv(NH,NHneg);
Denc=conv(DH,DHneg);

Numroc=restapol(Denc,Numc);

%Numroc=real(Numroc); 
%Numroc=cero(Numroc);

Raicesroc=roots(Numroc);
Rroc=cplxpair(Raicesroc);
raic=raizcomp(Rroc);
polin=[];

% Formaci�n del polinomio numerador de ro  
% por elecci�n de la raices situadas en el semiplano negativo

if rem(n,2)~=0  % si el orden es impar

for i=1:length(raic)/2
  polin(i)=raic(i);
end

polino=poly(polin);
polc=real(polino);
rreal=raizrspi(Raicesroc);
polr=poly(rreal);
Numro=conv(polc,polr);

else
% Hay que arreglar aca
for i=1:length(raic)/2
  polin(i)=raic(i);
end

polino=poly(polin);
polc=real(polino);

Numro=polc;

end


% Numerador y denominador del Coeficiente de reflexion ro
Numro=real(Numro);
Denro=DH;

% Partes pares e impares del numerador y denominador de ro
Np=parpol(Numro);
Ni=impar(Numro);

Dp=parpol(Denro);
Di=impar(Denro);

% Numerador y denominador de la Impedancia Z11 a sintetizar

nz=restapol(Dp,Np);
nz=nocero(nz);
dz=sumapol(Di,Ni);

%nz=restapol(Di,Ni);
%nz=nocero(nz);
%dz=sumapol(Dp,Np);


ctedenz=dz(1)/nz(1);

if ctedenz < 0
fprintf(' Para las especificaciones ingresadas no se puede sintetizar la Impedancia  '),fprintf('\n') 
end
if ctedenz < 0,break
end

%nz=nz/nz(1);   % Coeficientes de la potencia
%dz=dz/dz(1);   % mas alta igual a 1
%dz=dz*ctedenz; 

roots(nz);
roots(dz);


% Se desarrolla la impedancia por extracci�n de ceros



z=abs(z);  % Ceros de la funci�n de transferencia

if length(z)~=2
z=zetaco(z); % Acomoda el orden de los ceros en la forma 1 3 4 5.. n 2
end

j=sqrt(-1);

for m=1:2:length(z)

CeroT=z(m)*j;

     
% C�lculo del residuo para remoci�n parcial de polo 

ny=dz;
dy=nz;

C1=resipar(ny,dy,CeroT);   % Residuo de remoci�n parcial del polo

if m==1 & C1> 2.4
fprintf(' Para las especificaciones ingresadas no se puede sintetizar el filtro  '),fprintf('\n') 
fprintf(' Variar la ligeramente la Amin e intentar de nuevo' ),fprintf('\n') 
end

if m==1 & C1> 2.4
break
end

if m==1
fprintf('  El filtro comienza con una L en serie con R1'),fprintf('\n\n')
compo=1;  % Variable que se usa para contar el n�mero de componentes
end

Lnodos=C1*R0/w0;
if Lnodos < 0
 fprintf(' Para las especificaciones ingresadas  '),fprintf('\n') 
 fprintf(' NO se puede sintetizar la Impedancia  '),fprintf('\n')
end

fprintf('  (Componente n� '),exi(compo),fprintf(')'),fprintf('\n')
fprintf('   * L entre nodos'),exi(Lnodos),fprintf('H'),fprintf('\n\n') 
compo=compo+1;

% C�lculo de la admitancia resultante despues de la remoci�n parcial

[ny2,dy2]=reuncomp(ny,dy,C1);
ny2;
dy2;

% C�lculo del residuo para remoci�n completa del polo
fprintf('  (Componentes n� '),exi(compo),fprintf(')'),fprintf('\n')
fprintf('    Cero en'),exi(abs(CeroT)*f0),fprintf('rad/s'),fprintf('\n') 
fprintf('  * Circuito LC serie a masa:'),fprintf('\n')

[residuo,Lpara,Cpara]=resitot(dy2,ny2,CeroT);
k2=residuo;

Lpara;
Cserie=Lpara/R0/w0;

Cpara;
Lserie=Cpara*R0/w0;

if Lserie < 0
fprintf(' Para las especificaciones ingresadas  '),fprintf('\n') 
fprintf(' NO se puede sintetizar la Impedancia  '),fprintf('\n')
end
if Lserie < 0,break
end

fprintf('    L '),exi(Lserie),fprintf('H'),fprintf('\n') 
fprintf('    C '),exi(Cserie),fprintf('F'),fprintf('\n\n') 
compo=compo+1;
% C�lculo de la impedancia resultante despues de la remoci�n total del polo
% Zresultante=Z - ZLC

nz2=dy2;
dz2=ny2;
[nz3,dz3]=restaimp(nz2,dz2,k2,CeroT);
nz=nz3;
dz=dz3;

end

Culti=dz(1)/nz(1);

Lulti=Culti*R0/w0;
fprintf('  (Componente n� '),exi(compo),fprintf(')'),fprintf('\n')

fprintf('  * �ltima L, en serie con R2,'),exi(Lulti),fprintf('H'),fprintf('\n\n')

if Lulti < 0 % Si es negativo
   
fprintf(' !!! ATENCI�N: El Filtro fue MAL sintetizado !!! '),fprintf('\n') 
fprintf(' Variar ligeramente la Amin de la banda de atenuaci�n e intentar de nuevo' ),fprintf('\n') 
end

if Lulti > 2 %  2.8 % El l�mite para el �ltimo valor de L hay que verificarlo 
   
fprintf(' !!! ATENCI�N: El Filtro fue MAL sintetizado !!! '),fprintf('\n') 
fprintf(' Variar ligeramente la Amin de la banda de atenuaci�n e intentar de nuevo' ),fprintf('\n') 
end